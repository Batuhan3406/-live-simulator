-- Live Simalotör Database Schema
-- Turkish Investment Simulation Game

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE,
    balance DECIMAL(15,2) DEFAULT 100000.00,
    total_investments DECIMAL(15,2) DEFAULT 0.00,
    total_gain_loss DECIMAL(15,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT true
);

-- Market data table
CREATE TABLE IF NOT EXISTS market_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    symbol VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    change_amount DECIMAL(15,4) DEFAULT 0,
    change_percent DECIMAL(8,4) DEFAULT 0,
    volume BIGINT DEFAULT 0,
    market_cap BIGINT,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(symbol, last_updated)
);

-- Investments table
CREATE TABLE IF NOT EXISTS investments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    asset VARCHAR(20) NOT NULL,
    type VARCHAR(10) CHECK (type IN ('buy', 'sell')) NOT NULL,
    amount DECIMAL(15,8) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    gain_loss DECIMAL(15,2),
    status VARCHAR(10) CHECK (status IN ('active', 'closed')) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI training sessions table
CREATE TABLE IF NOT EXISTS training_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    strategy TEXT NOT NULL,
    decision TEXT NOT NULL,
    outcome VARCHAR(10) CHECK (outcome IN ('success', 'failure', 'pending')),
    market_conditions JSONB,
    result JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI models table
CREATE TABLE IF NOT EXISTS ai_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    training_level INTEGER DEFAULT 0,
    total_sessions INTEGER DEFAULT 0,
    accuracy DECIMAL(5,2) DEFAULT 0.00,
    last_trained TIMESTAMP WITH TIME ZONE,
    strategies TEXT[],
    preferences JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI recommendations table
CREATE TABLE IF NOT EXISTS ai_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    model_id UUID REFERENCES ai_models(id) ON DELETE CASCADE,
    asset VARCHAR(20) NOT NULL,
    action VARCHAR(10) CHECK (action IN ('buy', 'sell', 'hold')) NOT NULL,
    confidence INTEGER CHECK (confidence >= 0 AND confidence <= 100),
    reasoning TEXT,
    expected_return DECIMAL(8,4),
    risk_level VARCHAR(10) CHECK (risk_level IN ('low', 'medium', 'high')),
    executed BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Economic events table
CREATE TABLE IF NOT EXISTS economic_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    time TIME,
    event VARCHAR(255) NOT NULL,
    importance VARCHAR(10) CHECK (importance IN ('high', 'medium', 'low')) NOT NULL,
    category VARCHAR(50),
    expected VARCHAR(100),
    actual VARCHAR(100),
    impact JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- News table
CREATE TABLE IF NOT EXISTS news (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    title VARCHAR(500) NOT NULL,
    content TEXT,
    impact VARCHAR(10) CHECK (impact IN ('positive', 'negative', 'neutral')) NOT NULL,
    category VARCHAR(50),
    affected_assets TEXT[],
    sentiment_score DECIMAL(3,2) CHECK (sentiment_score >= -1 AND sentiment_score <= 1),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Portfolios table
CREATE TABLE IF NOT EXISTS portfolios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    total_value DECIMAL(15,2) NOT NULL,
    cash DECIMAL(15,2) NOT NULL,
    investments JSONB,
    performance JSONB,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Game time table
CREATE TABLE IF NOT EXISTS game_time (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    current_date DATE NOT NULL,
    speed INTEGER DEFAULT 1,
    is_paused BOOLEAN DEFAULT false,
    total_days_simulated INTEGER DEFAULT 0,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Performance metrics table
CREATE TABLE IF NOT EXISTS performance_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    total_return DECIMAL(15,2),
    total_return_percent DECIMAL(8,4),
    sharpe_ratio DECIMAL(8,4),
    max_drawdown DECIMAL(8,4),
    win_rate DECIMAL(5,2),
    average_win DECIMAL(15,2),
    average_loss DECIMAL(15,2),
    total_trades INTEGER,
    profitable_trades INTEGER,
    period_start DATE,
    period_end DATE,
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_investments_user_id ON investments(user_id);
CREATE INDEX IF NOT EXISTS idx_investments_date ON investments(date);
CREATE INDEX IF NOT EXISTS idx_training_sessions_user_id ON training_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_recommendations_user_id ON ai_recommendations(user_id);
CREATE INDEX IF NOT EXISTS idx_market_data_symbol ON market_data(symbol);
CREATE INDEX IF NOT EXISTS idx_market_data_last_updated ON market_data(last_updated);
CREATE INDEX IF NOT EXISTS idx_news_date ON news(date);
CREATE INDEX IF NOT EXISTS idx_economic_events_date ON economic_events(date);
