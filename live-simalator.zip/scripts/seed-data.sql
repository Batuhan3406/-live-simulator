-- Seed data for Live Simalotör
-- Insert initial data for testing and demo purposes

-- Insert demo user
INSERT INTO users (id, email, password_hash, name, balance, total_investments, total_gain_loss) 
VALUES (
    '550e8400-e29b-41d4-a716-446655440000',
    'demo@livesimalator.com',
    '$2b$10$rQZ9QmjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKjKj', -- hashed 'demo123'
    'Demo Kullanıcı',
    100000.00,
    85000.00,
    12500.00
) ON CONFLICT (email) DO NOTHING;

-- Insert initial market data
INSERT INTO market_data (symbol, name, price, change_amount, change_percent, volume, market_cap) VALUES
('BIST100', 'Borsa İstanbul 100', 8542.30, 125.45, 1.49, 15420000, 2150000000000),
('BTC', 'Bitcoin', 43250.00, -850.30, -1.93, 28500000000, NULL),
('GOLD', 'Altın (Ons)', 2045.80, 12.40, 0.61, 125000000, NULL),
('USD/TRY', 'Dolar/TL', 29.85, 0.15, 0.50, 8500000000, NULL),
('EUR/TRY', 'Euro/TL', 32.45, -0.25, -0.76, 3200000000, NULL),
('THYAO', 'Türk Hava Yolları', 185.50, 8.20, 4.63, 2500000, 25600000000),
('AKBNK', 'Akbank', 52.75, 1.15, 2.23, 18500000, 274500000000),
('ASELS', 'Aselsan', 78.90, -2.10, -2.59, 1200000, 177500000000)
ON CONFLICT (symbol, last_updated) DO NOTHING;

-- Insert sample investments for demo user
INSERT INTO investments (user_id, date, asset, type, amount, price, total, gain_loss, status) VALUES
('550e8400-e29b-41d4-a716-446655440000', '2024-01-15', 'BIST100', 'buy', 100, 8400.00, 840000, 14230, 'active'),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-10', 'BTC', 'buy', 0.5, 44000.00, 22000, -375, 'active'),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-08', 'GOLD', 'buy', 10, 2020.00, 20200, 258, 'active'),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-05', 'THYAO', 'buy', 50, 175.00, 8750, 525, 'active'),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-03', 'AKBNK', 'buy', 200, 50.00, 10000, 550, 'active');

-- Insert AI model for demo user
INSERT INTO ai_models (id, user_id, name, training_level, total_sessions, accuracy, strategies, preferences) VALUES
('660e8400-e29b-41d4-a716-446655440000', '550e8400-e29b-41d4-a716-446655440000', 'Kişisel Yatırım Asistanı', 42, 15, 68.50, 
ARRAY['RSI tabanlı alım-satım', 'Trend takip stratejisi', 'Haber bazlı yatırım'],
'{"riskTolerance": "medium", "preferredAssets": ["BIST100", "GOLD", "USD/TRY"], "timeHorizon": "medium"}'::jsonb);

-- Insert training sessions
INSERT INTO training_sessions (user_id, date, strategy, decision, outcome, market_conditions, result) VALUES
('550e8400-e29b-41d4-a716-446655440000', '2024-01-15', 'RSI 30''un altında alım, 70''in üzerinde satım yap', 'BIST100 RSI 28, güçlü alım sinyali', 'success', 
'{"rsi": 28, "macd": "positive", "volume": "high"}'::jsonb, '{"profitLoss": 14230, "accuracy": 85}'::jsonb),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-14', 'Altın fiyatları yükselirken dolar güçlenirse sat', 'Altın pozisyonunu kapat, dolar güçleniyor', 'pending', 
'{"goldTrend": "up", "dollarIndex": "strengthening", "inflation": "high"}'::jsonb, NULL),
('550e8400-e29b-41d4-a716-446655440000', '2024-01-12', 'Teknoloji hisselerinde düşüş sonrası alım', 'ASELS teknik destek seviyesinde, alım fırsatı', 'success',
'{"sector": "technology", "support": "strong", "volume": "increasing"}'::jsonb, '{"profitLoss": 2100, "accuracy": 78}'::jsonb);

-- Insert AI recommendations
INSERT INTO ai_recommendations (user_id, model_id, asset, action, confidence, reasoning, expected_return, risk_level) VALUES
('550e8400-e29b-41d4-a716-446655440000', '660e8400-e29b-41d4-a716-446655440000', 'BIST100', 'buy', 78, 'Teknik analiz göstergelerine göre destek seviyesinde güçlü alım fırsatı. RSI oversold bölgesinde.', 8.5, 'medium'),
('550e8400-e29b-41d4-a716-446655440000', '660e8400-e29b-41d4-a716-446655440000', 'BTC', 'hold', 65, 'Piyasa belirsizliği yüksek. Mevcut pozisyonu korumak en mantıklı strateji.', NULL, 'high'),
('550e8400-e29b-41d4-a716-446655440000', '660e8400-e29b-41d4-a716-446655440000', 'GOLD', 'sell', 72, 'Altın fiyatları dirençte, kısa vadeli kar realizasyonu öneriliyor.', 3.2, 'low');

-- Insert economic events
INSERT INTO economic_events (date, time, event, importance, category, expected, impact) VALUES
('2024-01-17', '14:00', 'Enflasyon Verileri (TÜFE)', 'high', 'Ekonomik Veri', '%64.8', 
'{"assets": {"BIST100": -2.5, "USD/TRY": 1.8, "GOLD": 0.5, "BTC": -1.2}}'::jsonb),
('2024-01-18', '10:00', 'İşsizlik Oranı', 'medium', 'İstihdam', '%9.2',
'{"assets": {"BIST100": 1.2, "USD/TRY": -0.8}}'::jsonb),
('2024-01-19', '16:30', 'Fed Toplantı Tutanakları', 'high', 'Merkez Bankası', NULL,
'{"assets": {"BTC": 3.5, "GOLD": -1.8, "USD/TRY": 2.1}}'::jsonb),
('2024-01-22', '11:00', 'TCMB Faiz Kararı', 'high', 'Merkez Bankası', '%45',
'{"assets": {"BIST100": 4.2, "USD/TRY": -3.5, "GOLD": 1.8}}'::jsonb);

-- Insert news items
INSERT INTO news (date, title, content, impact, category, affected_assets, sentiment_score) VALUES
('2024-01-16', 'Merkez Bankası Faiz Kararı Açıklandı', 'TCMB, politika faizini %45 seviyesinde sabit tutma kararı aldı. Piyasalar bu kararı olumlu karşıladı ve Türk Lirası değer kazandı.', 'positive', 'Ekonomi', ARRAY['USD/TRY', 'BIST100'], 0.75),
('2024-01-16', 'Teknoloji Şirketlerinde Yükseliş Devam Ediyor', 'BIST Teknoloji endeksi %3.2 yükselişle günü tamamladı. Yapay zeka yatırımları ve dijital dönüşüm projeleri sektörü destekliyor.', 'positive', 'Teknoloji', ARRAY['BIST100', 'ASELS'], 0.82),
('2024-01-16', 'Petrol Fiyatlarında Düşüş Sürüyor', 'Brent petrol varil fiyatı $78 seviyesine geriledi. Küresel talep endişeleri ve artan stoklar fiyatları baskı altında tutuyor.', 'negative', 'Emtia', ARRAY['BIST100'], -0.65),
('2024-01-16', 'Bitcoin ETF Onayları Piyasayı Hareketlendirdi', 'ABD''de Bitcoin ETF onaylarının ardından kripto para piyasasında hareketlilik artıyor. Kurumsal yatırımcı ilgisi yükseliyor.', 'positive', 'Kripto', ARRAY['BTC'], 0.88),
('2024-01-15', 'Bankacılık Sektöründe Güçlü Performans', 'Türk bankacılık sektörü 2024''e güçlü başladı. Akbank ve diğer büyük bankalar pozitif görünüm sergiliyor.', 'positive', 'Bankacılık', ARRAY['AKBNK', 'BIST100'], 0.71);

-- Insert portfolio for demo user
INSERT INTO portfolios (user_id, total_value, cash, investments, performance) VALUES
('550e8400-e29b-41d4-a716-446655440000', 112500.00, 15000.00,
'[
  {"asset": "BIST100", "quantity": 100, "averagePrice": 8400.00, "currentValue": 85423, "gainLoss": 14230, "gainLossPercent": 16.94},
  {"asset": "BTC", "quantity": 0.5, "averagePrice": 44000.00, "currentValue": 21625, "gainLoss": -375, "gainLossPercent": -1.70},
  {"asset": "GOLD", "quantity": 10, "averagePrice": 2020.00, "currentValue": 20458, "gainLoss": 258, "gainLossPercent": 1.28},
  {"asset": "THYAO", "quantity": 50, "averagePrice": 175.00, "currentValue": 9275, "gainLoss": 525, "gainLossPercent": 6.00},
  {"asset": "AKBNK", "quantity": 200, "averagePrice": 50.00, "currentValue": 10550, "gainLoss": 550, "gainLossPercent": 5.50}
]'::jsonb,
'{"daily": 2.3, "weekly": 5.8, "monthly": 12.5, "yearly": 0}'::jsonb);

-- Insert game time for demo user
INSERT INTO game_time (user_id, current_date, speed, is_paused, total_days_simulated) VALUES
('550e8400-e29b-41d4-a716-446655440000', '2024-01-16', 1, false, 16);

-- Insert performance metrics for demo user
INSERT INTO performance_metrics (user_id, total_return, total_return_percent, sharpe_ratio, max_drawdown, win_rate, average_win, average_loss, total_trades, profitable_trades, period_start, period_end) VALUES
('550e8400-e29b-41d4-a716-446655440000', 14113.00, 14.11, 1.25, -5.2, 66.7, 8500.00, -2100.00, 12, 8, '2024-01-01', '2024-01-16');
