import type {
  User,
  Investment,
  MarketData,
  TrainingSession,
  AIModel,
  AIRecommendation,
  EconomicEvent,
  NewsItem,
  Portfolio,
  PerformanceMetrics,
} from "./types"

// Mock Users
export const mockUsers: User[] = [
  {
    id: "1",
    email: "demo@example.com",
    name: "Demo Kullanıcı",
    createdAt: "2024-01-01T00:00:00Z",
    lastLogin: "2024-01-16T09:00:00Z",
    balance: 100000,
    totalInvestments: 85000,
    totalGainLoss: 12500,
  },
]

// Mock Market Data
export const mockMarketData: MarketData[] = [
  {
    symbol: "BIST100",
    name: "Borsa İstanbul 100",
    price: 8542.3,
    change: 125.45,
    changePercent: 1.49,
    volume: 15420000,
    marketCap: 2150000000000,
    lastUpdated: "2024-01-16T16:00:00Z",
  },
  {
    symbol: "BTC",
    name: "Bitcoin",
    price: 43250.0,
    change: -850.3,
    changePercent: -1.93,
    volume: 28500000000,
    lastUpdated: "2024-01-16T16:00:00Z",
  },
  {
    symbol: "GOLD",
    name: "Altın (Ons)",
    price: 2045.8,
    change: 12.4,
    changePercent: 0.61,
    volume: 125000000,
    lastUpdated: "2024-01-16T16:00:00Z",
  },
  {
    symbol: "USD/TRY",
    name: "Dolar/TL",
    price: 29.85,
    change: 0.15,
    changePercent: 0.5,
    volume: 8500000000,
    lastUpdated: "2024-01-16T16:00:00Z",
  },
]

// Mock Investments
export const mockInvestments: Investment[] = [
  {
    id: "1",
    userId: "1",
    date: "2024-01-15",
    asset: "BIST100",
    type: "buy",
    amount: 100,
    price: 8400.0,
    total: 840000,
    gainLoss: 14230,
    status: "active",
  },
  {
    id: "2",
    userId: "1",
    date: "2024-01-10",
    asset: "BTC",
    type: "buy",
    amount: 0.5,
    price: 44000.0,
    total: 22000,
    gainLoss: -375,
    status: "active",
  },
  {
    id: "3",
    userId: "1",
    date: "2024-01-08",
    asset: "GOLD",
    type: "buy",
    amount: 10,
    price: 2020.0,
    total: 20200,
    gainLoss: 258,
    status: "active",
  },
]

// Mock Training Sessions
export const mockTrainingSessions: TrainingSession[] = [
  {
    id: "1",
    userId: "1",
    date: "2024-01-15",
    strategy: "RSI 30'un altında alım, 70'in üzerinde satım yap",
    decision: "BIST100 RSI 28, güçlü alım sinyali",
    outcome: "success",
    marketConditions: {
      rsi: 28,
      macd: "positive",
      volume: "high",
    },
    result: {
      profitLoss: 14230,
      accuracy: 85,
    },
  },
  {
    id: "2",
    userId: "1",
    date: "2024-01-14",
    strategy: "Altın fiyatları yükselirken dolar güçlenirse sat",
    decision: "Altın pozisyonunu kapat, dolar güçleniyor",
    outcome: "pending",
    marketConditions: {
      goldTrend: "up",
      dollarIndex: "strengthening",
      inflation: "high",
    },
  },
]

// Mock AI Model
export const mockAIModel: AIModel = {
  id: "1",
  userId: "1",
  name: "Kişisel Yatırım Asistanı",
  trainingLevel: 42,
  totalSessions: 15,
  accuracy: 68,
  lastTrained: "2024-01-16T10:00:00Z",
  strategies: ["RSI tabanlı alım-satım", "Trend takip stratejisi", "Haber bazlı yatırım"],
  preferences: {
    riskTolerance: "medium",
    preferredAssets: ["BIST100", "GOLD", "USD/TRY"],
    timeHorizon: "medium",
  },
}

// Mock AI Recommendations
export const mockAIRecommendations: AIRecommendation[] = [
  {
    id: "1",
    userId: "1",
    modelId: "1",
    asset: "BIST100",
    action: "buy",
    confidence: 78,
    reasoning: "Teknik analiz göstergelerine göre destek seviyesinde güçlü alım fırsatı. RSI oversold bölgesinde.",
    expectedReturn: 8.5,
    riskLevel: "medium",
    timestamp: "2024-01-16T09:30:00Z",
    executed: false,
  },
  {
    id: "2",
    userId: "1",
    modelId: "1",
    asset: "BTC",
    action: "hold",
    confidence: 65,
    reasoning: "Piyasa belirsizliği yüksek. Mevcut pozisyonu korumak en mantıklı strateji.",
    riskLevel: "high",
    timestamp: "2024-01-16T09:25:00Z",
    executed: false,
  },
]

// Mock Economic Events
export const mockEconomicEvents: EconomicEvent[] = [
  {
    id: "1",
    date: "2024-01-17",
    time: "14:00",
    event: "Enflasyon Verileri (TÜFE)",
    importance: "high",
    category: "Ekonomik Veri",
    expected: "%64.8",
    impact: {
      assets: {
        BIST100: -2.5,
        "USD/TRY": 1.8,
        GOLD: 0.5,
        BTC: -1.2,
      },
    },
  },
  {
    id: "2",
    date: "2024-01-18",
    time: "10:00",
    event: "İşsizlik Oranı",
    importance: "medium",
    category: "İstihdam",
    expected: "%9.2",
    impact: {
      assets: {
        BIST100: 1.2,
        "USD/TRY": -0.8,
      },
    },
  },
  {
    id: "3",
    date: "2024-01-19",
    time: "16:30",
    event: "Fed Toplantı Tutanakları",
    importance: "high",
    category: "Merkez Bankası",
    impact: {
      assets: {
        BTC: 3.5,
        GOLD: -1.8,
        "USD/TRY": 2.1,
      },
    },
  },
]

// Mock News Items
export const mockNewsItems: NewsItem[] = [
  {
    id: "1",
    date: "2024-01-16",
    title: "Merkez Bankası Faiz Kararı Açıklandı",
    content:
      "TCMB, politika faizini %45 seviyesinde sabit tutma kararı aldı. Piyasalar bu kararı olumlu karşıladı ve Türk Lirası değer kazandı.",
    impact: "positive",
    category: "Ekonomi",
    affectedAssets: ["USD/TRY", "BIST100"],
    sentimentScore: 0.75,
  },
  {
    id: "2",
    date: "2024-01-16",
    title: "Teknoloji Şirketlerinde Yükseliş Devam Ediyor",
    content:
      "BIST Teknoloji endeksi %3.2 yükselişle günü tamamladı. Yapay zeka yatırımları ve dijital dönüşüm projeleri sektörü destekliyor.",
    impact: "positive",
    category: "Teknoloji",
    affectedAssets: ["BIST100"],
    sentimentScore: 0.82,
  },
  {
    id: "3",
    date: "2024-01-16",
    title: "Petrol Fiyatlarında Düşüş Sürüyor",
    content:
      "Brent petrol varil fiyatı $78 seviyesine geriledi. Küresel talep endişeleri ve artan stoklar fiyatları baskı altında tutuyor.",
    impact: "negative",
    category: "Emtia",
    affectedAssets: ["BIST100"],
    sentimentScore: -0.65,
  },
  {
    id: "4",
    date: "2024-01-16",
    title: "Bitcoin ETF Onayları Piyasayı Hareketlendirdi",
    content:
      "ABD'de Bitcoin ETF onaylarının ardından kripto para piyasasında hareketlilik artıyor. Kurumsal yatırımcı ilgisi yükseliyor.",
    impact: "positive",
    category: "Kripto",
    affectedAssets: ["BTC"],
    sentimentScore: 0.88,
  },
]

// Mock Portfolio
export const mockPortfolio: Portfolio = {
  id: "1",
  userId: "1",
  totalValue: 112500,
  cash: 15000,
  investments: [
    {
      asset: "BIST100",
      quantity: 100,
      averagePrice: 8400.0,
      currentValue: 85423,
      gainLoss: 14230,
      gainLossPercent: 16.94,
    },
    {
      asset: "BTC",
      quantity: 0.5,
      averagePrice: 44000.0,
      currentValue: 21625,
      gainLoss: -375,
      gainLossPercent: -1.7,
    },
    {
      asset: "GOLD",
      quantity: 10,
      averagePrice: 2020.0,
      currentValue: 20458,
      gainLoss: 258,
      gainLossPercent: 1.28,
    },
  ],
  performance: {
    daily: 2.3,
    weekly: 5.8,
    monthly: 12.5,
    yearly: 0, // New portfolio
  },
  lastUpdated: "2024-01-16T16:00:00Z",
}

// Mock Performance Metrics
export const mockPerformanceMetrics: PerformanceMetrics = {
  userId: "1",
  totalReturn: 14113,
  totalReturnPercent: 14.11,
  sharpeRatio: 1.25,
  maxDrawdown: -5.2,
  winRate: 66.7,
  averageWin: 8500,
  averageLoss: -2100,
  totalTrades: 12,
  profitableTrades: 8,
  period: {
    start: "2024-01-01",
    end: "2024-01-16",
  },
}

// Utility functions for mock data
export const generateRandomMarketData = (baseData: MarketData): MarketData => {
  const volatility = 0.02 // 2% volatility
  const randomChange = (Math.random() - 0.5) * 2 * volatility
  const newPrice = baseData.price * (1 + randomChange)
  const change = newPrice - baseData.price
  const changePercent = (change / baseData.price) * 100

  return {
    ...baseData,
    price: newPrice,
    change,
    changePercent,
    lastUpdated: new Date().toISOString(),
  }
}

export const simulateTimeProgression = (days: number) => {
  // Simulate market events and news based on time progression
  const events = []
  const news = []

  for (let i = 0; i < days; i++) {
    // Generate random market events
    if (Math.random() < 0.3) {
      // 30% chance of significant event per day
      events.push({
        type: "market_event",
        impact: (Math.random() - 0.5) * 0.1, // ±5% impact
        assets: ["BIST100", "BTC", "GOLD", "USD/TRY"],
      })
    }

    // Generate news items
    if (Math.random() < 0.6) {
      // 60% chance of news per day
      news.push({
        title: `Günlük Piyasa Analizi - Gün ${i + 1}`,
        impact: Math.random() > 0.5 ? "positive" : "negative",
        sentiment: (Math.random() - 0.5) * 2,
      })
    }
  }

  return { events, news }
}
