// Commission-Based Monetization System
export interface TradeResult {
  id: string
  userId: string
  signalId: string
  symbol: string
  entryPrice: number
  exitPrice: number
  quantity: number
  tradeType: "BUY" | "SELL"
  profit: number
  profitPercent: number
  commissionRate: number
  commissionAmount: number
  executedAt: string
  closedAt: string
  status: "open" | "closed" | "cancelled"
}

export interface CommissionTier {
  name: string
  minProfit: number
  maxProfit: number
  rate: number
  features: string[]
}

export interface UserCommissionStats {
  userId: string
  totalTrades: number
  successfulTrades: number
  totalProfit: number
  totalCommissionPaid: number
  currentTier: string
  winRate: number
  averageProfit: number
  monthlyStats: {
    month: string
    trades: number
    profit: number
    commission: number
  }[]
}

class CommissionSystem {
  // Commission tier yapısı
  private commissionTiers: CommissionTier[] = [
    {
      name: "Başlangıç",
      minProfit: 0,
      maxProfit: 1000,
      rate: 0.15, // %15 komisyon
      features: ["Temel AI sinyalleri", "Günlük 5 sinyal", "Email desteği"],
    },
    {
      name: "Gelişmiş",
      minProfit: 1000,
      maxProfit: 5000,
      rate: 0.12, // %12 komisyon
      features: ["Gelişmiş AI sinyalleri", "Günlük 15 sinyal", "WhatsApp desteği", "Risk analizi"],
    },
    {
      name: "Profesyonel",
      minProfit: 5000,
      maxProfit: 20000,
      rate: 0.1, // %10 komisyon
      features: ["Premium AI sinyalleri", "Sınırsız sinyal", "1-1 danışmanlık", "Otomatik trading"],
    },
    {
      name: "VIP",
      minProfit: 20000,
      maxProfit: Number.POSITIVE_INFINITY,
      rate: 0.08, // %8 komisyon
      features: ["Özel AI modeli", "Kişisel analist", "Öncelikli destek", "Özel Telegram grubu"],
    },
  ]

  // Kullanıcının tier'ını belirle
  getUserTier(totalProfit: number): CommissionTier {
    return (
      this.commissionTiers.find((tier) => totalProfit >= tier.minProfit && totalProfit < tier.maxProfit) ||
      this.commissionTiers[0]
    )
  }

  // Komisyon hesapla
  calculateCommission(profit: number, userId: string, userStats: UserCommissionStats): number {
    if (profit <= 0) return 0 // Zarar durumunda komisyon yok

    const userTier = this.getUserTier(userStats.totalProfit)
    let commissionRate = userTier.rate

    // Başarı oranına göre indirim
    if (userStats.winRate > 0.8) {
      commissionRate *= 0.9 // %10 indirim
    } else if (userStats.winRate > 0.7) {
      commissionRate *= 0.95 // %5 indirim
    }

    // Aylık volume indirimi
    const currentMonth = new Date().toISOString().slice(0, 7)
    const monthlyStats = userStats.monthlyStats.find((m) => m.month === currentMonth)
    if (monthlyStats && monthlyStats.profit > 10000) {
      commissionRate *= 0.9 // Yüksek volume indirimi
    }

    return profit * commissionRate
  }

  // Trade sonucunu kaydet ve komisyon hesapla
  async recordTradeResult(
    tradeData: Omit<TradeResult, "id" | "commissionAmount" | "commissionRate">,
  ): Promise<TradeResult> {
    // Kullanıcı istatistiklerini al
    const userStats = await this.getUserStats(tradeData.userId)

    // Komisyon hesapla
    const commissionAmount = this.calculateCommission(tradeData.profit, tradeData.userId, userStats)
    const userTier = this.getUserTier(userStats.totalProfit)

    const tradeResult: TradeResult = {
      ...tradeData,
      id: `trade_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      commissionAmount,
      commissionRate: userTier.rate,
    }

    // Veritabanına kaydet (mock)
    await this.saveTradeResult(tradeResult)

    // Kullanıcı istatistiklerini güncelle
    await this.updateUserStats(tradeData.userId, tradeResult)

    return tradeResult
  }

  // Kullanıcı istatistiklerini al
  private async getUserStats(userId: string): Promise<UserCommissionStats> {
    // Mock data - gerçek uygulamada veritabanından gelecek
    return {
      userId,
      totalTrades: 45,
      successfulTrades: 32,
      totalProfit: 3500,
      totalCommissionPaid: 420,
      currentTier: "Gelişmiş",
      winRate: 0.71,
      averageProfit: 77.8,
      monthlyStats: [
        { month: "2024-01", trades: 15, profit: 1200, commission: 144 },
        { month: "2024-02", trades: 18, profit: 1450, commission: 174 },
        { month: "2024-03", trades: 12, profit: 850, commission: 102 },
      ],
    }
  }

  private async saveTradeResult(tradeResult: TradeResult): Promise<void> {
    // Veritabanı kayıt işlemi
    console.log("Trade kaydedildi:", tradeResult)
  }

  private async updateUserStats(userId: string, tradeResult: TradeResult): Promise<void> {
    // Kullanıcı istatistiklerini güncelle
    console.log("Kullanıcı istatistikleri güncellendi:", userId)
  }

  // Aylık komisyon raporu
  async getMonthlyCommissionReport(userId: string, month: string) {
    const userStats = await this.getUserStats(userId)
    const monthlyData = userStats.monthlyStats.find((m) => m.month === month)

    if (!monthlyData) {
      return {
        month,
        totalTrades: 0,
        totalProfit: 0,
        totalCommission: 0,
        averageCommissionRate: 0,
      }
    }

    return {
      month,
      totalTrades: monthlyData.trades,
      totalProfit: monthlyData.profit,
      totalCommission: monthlyData.commission,
      averageCommissionRate: monthlyData.commission / monthlyData.profit,
    }
  }
}

export const commissionSystem = new CommissionSystem()
