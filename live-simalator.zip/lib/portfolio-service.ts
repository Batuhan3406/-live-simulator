import type { YatirimEnstrumani, PortfoyOzeti, AIAnalizi, GrafikVerisi } from "./portfolio-types"

export class PortfoyService {
  // Mock portfolio data
  static async getPortfoyVerileri(userId: string): Promise<YatirimEnstrumani[]> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    return [
      {
        id: "1",
        sembol: "BTC",
        ad: "Bitcoin",
        kategori: "kripto",
        guncelFiyat: 98750,
        yatirimTutari: 50000,
        miktar: 0.506,
        guncelDeger: 49970,
        karZarar: -30,
        karZararYuzde: -0.06,
        gunlukDegisim: 2.3,
        haftalikDegisim: -1.2,
        sonGuncelleme: new Date().toISOString(),
      },
      {
        id: "2",
        sembol: "ETH",
        ad: "Ethereum",
        kategori: "kripto",
        guncelFiyat: 3850,
        yatirimTutari: 30000,
        miktar: 7.79,
        guncelDeger: 29992,
        karZarar: -8,
        karZararYuzde: -0.03,
        gunlukDegisim: 1.8,
        haftalikDegisim: 4.2,
        sonGuncelleme: new Date().toISOString(),
      },
      {
        id: "3",
        sembol: "GOLD",
        ad: "Altın (Ons)",
        kategori: "altin",
        guncelFiyat: 2650,
        yatirimTutari: 25000,
        miktar: 9.43,
        guncelDeger: 24990,
        karZarar: -10,
        karZararYuzde: -0.04,
        gunlukDegisim: -0.5,
        haftalikDegisim: 2.1,
        sonGuncelleme: new Date().toISOString(),
      },
      {
        id: "4",
        sembol: "BIST100",
        ad: "BIST 100 Endeksi",
        kategori: "borsa",
        guncelFiyat: 11250,
        yatirimTutari: 40000,
        miktar: 3.56,
        guncelDeger: 40050,
        karZarar: 50,
        karZararYuzde: 0.125,
        gunlukDegisim: 0.8,
        haftalikDegisim: -2.3,
        sonGuncelleme: new Date().toISOString(),
      },
      {
        id: "5",
        sembol: "USD/TRY",
        ad: "Dolar/TL",
        kategori: "doviz",
        guncelFiyat: 34.25,
        yatirimTutari: 20000,
        miktar: 584.8,
        guncelDeger: 20030,
        karZarar: 30,
        karZararYuzde: 0.15,
        gunlukDegisim: 0.3,
        haftalikDegisim: 1.8,
        sonGuncelleme: new Date().toISOString(),
      },
    ]
  }

  static async getPortfoyOzeti(userId: string): Promise<PortfoyOzeti> {
    const varliklar = await this.getPortfoyVerileri(userId)

    const toplamYatirim = varliklar.reduce((sum, v) => sum + v.yatirimTutari, 0)
    const guncelDeger = varliklar.reduce((sum, v) => sum + v.guncelDeger, 0)
    const toplamKarZarar = guncelDeger - toplamYatirim
    const toplamKarZararYuzde = (toplamKarZarar / toplamYatirim) * 100

    return {
      toplamYatirim,
      guncelDeger,
      toplamKarZarar,
      toplamKarZararYuzde,
      gunlukDegisim: 1.2,
      haftalikDegisim: 0.8,
      aylikDegisim: 3.5,
    }
  }

  static async getAIAnalizleri(userId: string): Promise<AIAnalizi[]> {
    await new Promise((resolve) => setTimeout(resolve, 300))

    return [
      {
        id: "1",
        tarih: new Date().toISOString(),
        baslik: "Bitcoin Pozisyonu Değerlendirmesi",
        aciklama:
          "Bitcoin 98K seviyesinde güçlü destek buldu. Kısa vadede 102K hedefi mümkün. Pozisyonunuzu %10 artırmanızı öneriyorum.",
        oneri: "artir",
        guvenSeviyesi: 85,
        etkilenenVarliklar: ["BTC"],
        oncelik: "yuksek",
      },
      {
        id: "2",
        tarih: new Date(Date.now() - 3600000).toISOString(),
        baslik: "Altın Piyasası Uyarısı",
        aciklama:
          "Fed faiz kararı öncesi altında volatilite artabilir. Risk yönetimi için pozisyon boyutunu %20 azaltın.",
        oneri: "azalt",
        guvenSeviyesi: 78,
        etkilenenVarliklar: ["GOLD"],
        oncelik: "orta",
      },
      {
        id: "3",
        tarih: new Date(Date.now() - 7200000).toISOString(),
        baslik: "BIST 100 Fırsat Analizi",
        aciklama: "BIST 100 teknik olarak güçlü görünüyor. 11.500 direncini kırması halinde %5-8 yükseliş bekleniyor.",
        oneri: "bekle",
        guvenSeviyesi: 72,
        etkilenenVarliklar: ["BIST100"],
        oncelik: "dusuk",
      },
    ]
  }

  static async getGrafikVerileri(userId: string): Promise<GrafikVerisi[]> {
    const bugün = new Date()
    const veriler: GrafikVerisi[] = []

    for (let i = 29; i >= 0; i--) {
      const tarih = new Date(bugün)
      tarih.setDate(tarih.getDate() - i)

      const baseValue = 165000
      const randomChange = (Math.random() - 0.5) * 5000
      const deger = baseValue + randomChange + i * 100

      veriler.push({
        tarih: tarih.toISOString().split("T")[0],
        deger: Math.round(deger),
        karZarar: Math.round(deger - 165000),
      })
    }

    return veriler
  }
}
