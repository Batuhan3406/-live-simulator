// AI Destekli Canlı Veri Servisi - 2025+
export interface LiveMarketData {
  symbol: string
  name: string
  price: number
  change24h: number
  change7d: number
  change30d: number
  changeYTD: number
  volume24h: number
  marketCap: number
  trend: "YUKSELIS" | "DUSUS" | "YATAY"
  aiPrediction: "AL" | "SAT" | "BEKLE"
  aiConfidence: number
  nextTarget: number
  riskLevel: number
  lastUpdate: string
  yearlyData: YearlyData[]
}

export interface YearlyData {
  year: number
  startPrice: number
  endPrice: number
  highPrice: number
  lowPrice: number
  totalReturn: number
  volatility: number
  bestMonth: string
  worstMonth: string
}

export interface AIAnalysis {
  marketSentiment: "AŞIRI_KORKU" | "KORKU" | "NÖTR" | "AÇGÖZLÜLÜK" | "AŞIRI_AÇGÖZLÜLÜK"
  trendDirection: "YUKARI" | "ASAGI" | "YATAY"
  timeframe: "KISA_VADE" | "ORTA_VADE" | "UZUN_VADE"
  confidence: number
  reasoning: string
  keyFactors: string[]
  riskFactors: string[]
  opportunities: string[]
}

export interface DailyTrend {
  date: string
  openPrice: number
  closePrice: number
  highPrice: number
  lowPrice: number
  volume: number
  change: number
  aiScore: number
  events: string[]
}

class AILiveDataService {
  private wsConnections: Map<string, WebSocket> = new Map()
  private liveData: Map<string, LiveMarketData> = new Map()
  private dailyTrends: Map<string, DailyTrend[]> = new Map()
  private aiAnalysis: Map<string, AIAnalysis> = new Map()
  private subscribers: Map<string, ((data: LiveMarketData) => void)[]> = new Map()
  private isRunning = false

  // 2025+ Başlangıç verileri
  private initialData: LiveMarketData[] = [
    {
      symbol: "BTC",
      name: "Bitcoin",
      price: 98750,
      change24h: 3.7,
      change7d: 12.4,
      change30d: 28.5,
      changeYTD: 145.2,
      volume24h: 45200000000,
      marketCap: 1950000000000,
      trend: "YUKSELIS",
      aiPrediction: "AL",
      aiConfidence: 87,
      nextTarget: 105000,
      riskLevel: 6,
      lastUpdate: new Date().toISOString(),
      yearlyData: [
        {
          year: 2024,
          startPrice: 42000,
          endPrice: 68000,
          highPrice: 73000,
          lowPrice: 38000,
          totalReturn: 61.9,
          volatility: 4.2,
          bestMonth: "Kasım",
          worstMonth: "Haziran",
        },
        {
          year: 2025,
          startPrice: 68000,
          endPrice: 98750,
          highPrice: 102000,
          lowPrice: 65000,
          totalReturn: 45.2,
          volatility: 3.8,
          bestMonth: "Mart",
          worstMonth: "Şubat",
        },
      ],
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      price: 3850,
      change24h: 5.2,
      change7d: 18.7,
      change30d: 32.1,
      changeYTD: 89.4,
      volume24h: 18500000000,
      marketCap: 462000000000,
      trend: "YUKSELIS",
      aiPrediction: "AL",
      aiConfidence: 82,
      nextTarget: 4200,
      riskLevel: 5,
      lastUpdate: new Date().toISOString(),
      yearlyData: [
        {
          year: 2024,
          startPrice: 2300,
          endPrice: 2850,
          highPrice: 4100,
          lowPrice: 1800,
          totalReturn: 23.9,
          volatility: 5.1,
          bestMonth: "Mart",
          worstMonth: "Ağustos",
        },
        {
          year: 2025,
          startPrice: 2850,
          endPrice: 3850,
          highPrice: 4000,
          lowPrice: 2600,
          totalReturn: 35.1,
          volatility: 4.3,
          bestMonth: "Mayıs",
          worstMonth: "Ocak",
        },
      ],
    },
    {
      symbol: "SOL",
      name: "Solana",
      price: 245,
      change24h: 8.9,
      change7d: 25.3,
      change30d: 45.7,
      changeYTD: 234.5,
      volume24h: 4200000000,
      marketCap: 115000000000,
      trend: "YUKSELIS",
      aiPrediction: "AL",
      aiConfidence: 91,
      nextTarget: 280,
      riskLevel: 8,
      lastUpdate: new Date().toISOString(),
      yearlyData: [
        {
          year: 2024,
          startPrice: 65,
          endPrice: 95,
          highPrice: 210,
          lowPrice: 45,
          totalReturn: 46.2,
          volatility: 8.7,
          bestMonth: "Kasım",
          worstMonth: "Eylül",
        },
        {
          year: 2025,
          startPrice: 95,
          endPrice: 245,
          highPrice: 260,
          lowPrice: 85,
          totalReturn: 157.9,
          volatility: 7.2,
          bestMonth: "Haziran",
          worstMonth: "Şubat",
        },
      ],
    },
  ]

  constructor() {
    this.initializeData()
  }

  private initializeData() {
    this.initialData.forEach((data) => {
      this.liveData.set(data.symbol, data)
      this.generateDailyTrends(data.symbol)
      this.generateAIAnalysis(data.symbol, data)
    })
  }

  // Canlı veri akışını başlat
  async startLiveDataStream() {
    if (this.isRunning) return

    this.isRunning = true
    console.log("🤖 AI Canlı Veri Akışı Başlatıldı - 2025+")

    // Her 2 saniyede bir veri güncelle
    const updateInterval = setInterval(() => {
      if (!this.isRunning) {
        clearInterval(updateInterval)
        return
      }

      this.updateAllMarketData()
    }, 2000)

    // Her gün yeni trend verisi ekle
    const dailyInterval = setInterval(
      () => {
        if (!this.isRunning) {
          clearInterval(dailyInterval)
          return
        }

        this.addDailyTrendData()
      },
      24 * 60 * 60 * 1000,
    ) // 24 saat

    // Her yıl yıllık veri güncelle
    const yearlyInterval = setInterval(
      () => {
        if (!this.isRunning) {
          clearInterval(yearlyInterval)
          return
        }

        this.updateYearlyData()
      },
      365 * 24 * 60 * 60 * 1000,
    ) // 365 gün
  }

  // Canlı veri akışını durdur
  stopLiveDataStream() {
    this.isRunning = false
    console.log("🛑 AI Canlı Veri Akışı Durduruldu")
  }

  // Tüm piyasa verilerini güncelle
  private updateAllMarketData() {
    this.liveData.forEach((data, symbol) => {
      const updatedData = this.simulateMarketMovement(data)
      this.liveData.set(symbol, updatedData)
      this.generateAIAnalysis(symbol, updatedData)
      this.notifySubscribers(symbol, updatedData)
    })
  }

  // Piyasa hareketini simüle et
  private simulateMarketMovement(data: LiveMarketData): LiveMarketData {
    // AI destekli gerçekçi fiyat hareketi
    const volatility = this.calculateVolatility(data.symbol)
    const trendStrength = this.calculateTrendStrength(data)
    const marketSentiment = this.getMarketSentiment()

    // Fiyat değişimi hesapla
    let priceChange = (Math.random() - 0.5) * volatility

    // Trend yönüne göre bias ekle
    if (data.trend === "YUKSELIS") {
      priceChange += trendStrength * 0.3
    } else if (data.trend === "DUSUS") {
      priceChange -= trendStrength * 0.3
    }

    // Market sentiment etkisi
    if (marketSentiment === "AÇGÖZLÜLÜK") {
      priceChange += 0.2
    } else if (marketSentiment === "KORKU") {
      priceChange -= 0.2
    }

    const newPrice = data.price * (1 + priceChange / 100)
    const change24h = data.change24h + (Math.random() - 0.5) * 2

    // Trend yönünü güncelle
    const newTrend = this.determineTrend(change24h, data.change7d)

    // AI prediction güncelle
    const aiPrediction = this.generateAIPrediction(newPrice, change24h, data.change7d)

    return {
      ...data,
      price: Math.max(0.01, newPrice),
      change24h: change24h,
      change7d: data.change7d + (Math.random() - 0.5) * 1,
      change30d: data.change30d + (Math.random() - 0.5) * 0.5,
      volume24h: data.volume24h * (1 + (Math.random() - 0.5) * 0.1),
      trend: newTrend,
      aiPrediction: aiPrediction.signal,
      aiConfidence: aiPrediction.confidence,
      nextTarget: this.calculateNextTarget(newPrice, newTrend),
      riskLevel: this.calculateRiskLevel(change24h, volatility),
      lastUpdate: new Date().toISOString(),
    }
  }

  // Volatilite hesapla
  private calculateVolatility(symbol: string): number {
    const baseVolatility = {
      BTC: 3.5,
      ETH: 4.2,
      SOL: 7.8,
      ADA: 5.1,
      DOT: 6.3,
      LINK: 5.7,
    }
    return baseVolatility[symbol as keyof typeof baseVolatility] || 5.0
  }

  // Trend gücünü hesapla
  private calculateTrendStrength(data: LiveMarketData): number {
    const change7d = Math.abs(data.change7d)
    if (change7d > 20) return 0.8
    if (change7d > 10) return 0.5
    if (change7d > 5) return 0.3
    return 0.1
  }

  // Market sentiment al
  private getMarketSentiment(): string {
    const sentiments = ["AŞIRI_KORKU", "KORKU", "NÖTR", "AÇGÖZLÜLÜK", "AŞIRI_AÇGÖZLÜLÜK"]
    const weights = [0.1, 0.2, 0.4, 0.2, 0.1] // Nötr daha olası

    const random = Math.random()
    let cumulative = 0

    for (let i = 0; i < sentiments.length; i++) {
      cumulative += weights[i]
      if (random <= cumulative) {
        return sentiments[i]
      }
    }

    return "NÖTR"
  }

  // Trend yönünü belirle
  private determineTrend(change24h: number, change7d: number): "YUKSELIS" | "DUSUS" | "YATAY" {
    if (change24h > 2 && change7d > 5) return "YUKSELIS"
    if (change24h < -2 && change7d < -5) return "DUSUS"
    return "YATAY"
  }

  // AI prediction üret
  private generateAIPrediction(
    price: number,
    change24h: number,
    change7d: number,
  ): { signal: "AL" | "SAT" | "BEKLE"; confidence: number } {
    let signal: "AL" | "SAT" | "BEKLE" = "BEKLE"
    let confidence = 50

    if (change24h > 3 && change7d > 10) {
      signal = "AL"
      confidence = Math.min(95, 70 + change7d)
    } else if (change24h < -3 && change7d < -10) {
      signal = "SAT"
      confidence = Math.min(95, 70 + Math.abs(change7d))
    } else {
      confidence = 60 + Math.random() * 20
    }

    return { signal, confidence: Math.round(confidence) }
  }

  // Sonraki hedefi hesapla
  private calculateNextTarget(currentPrice: number, trend: string): number {
    const multiplier = trend === "YUKSELIS" ? 1.05 : trend === "DUSUS" ? 0.95 : 1.02
    return currentPrice * multiplier
  }

  // Risk seviyesini hesapla
  private calculateRiskLevel(change24h: number, volatility: number): number {
    const riskScore = (Math.abs(change24h) + volatility) / 2
    return Math.min(10, Math.max(1, Math.round(riskScore)))
  }

  // Günlük trend verisi ekle
  private addDailyTrendData() {
    this.liveData.forEach((data, symbol) => {
      const dailyTrend: DailyTrend = {
        date: new Date().toISOString().split("T")[0],
        openPrice: data.price * 0.99,
        closePrice: data.price,
        highPrice: data.price * 1.02,
        lowPrice: data.price * 0.98,
        volume: data.volume24h,
        change: data.change24h,
        aiScore: data.aiConfidence,
        events: this.generateDailyEvents(data),
      }

      if (!this.dailyTrends.has(symbol)) {
        this.dailyTrends.set(symbol, [])
      }

      const trends = this.dailyTrends.get(symbol)!
      trends.push(dailyTrend)

      // Son 365 günü tut
      if (trends.length > 365) {
        trends.shift()
      }
    })
  }

  // Günlük olayları üret
  private generateDailyEvents(data: LiveMarketData): string[] {
    const events = []

    if (data.change24h > 5) {
      events.push("Güçlü yükseliş trendi")
    }
    if (data.change24h < -5) {
      events.push("Düşüş baskısı")
    }
    if (data.volume24h > data.marketCap * 0.1) {
      events.push("Yüksek işlem hacmi")
    }
    if (data.aiConfidence > 85) {
      events.push("AI güven seviyesi yüksek")
    }

    return events
  }

  // Yıllık verileri güncelle
  private updateYearlyData() {
    const currentYear = new Date().getFullYear()

    this.liveData.forEach((data, symbol) => {
      const yearlyData = data.yearlyData
      const currentYearData = yearlyData.find((y) => y.year === currentYear)

      if (currentYearData) {
        // Mevcut yılı güncelle
        currentYearData.endPrice = data.price
        currentYearData.totalReturn = ((data.price - currentYearData.startPrice) / currentYearData.startPrice) * 100
      } else {
        // Yeni yıl ekle
        const newYearData: YearlyData = {
          year: currentYear,
          startPrice: data.price,
          endPrice: data.price,
          highPrice: data.price,
          lowPrice: data.price,
          totalReturn: 0,
          volatility: this.calculateVolatility(symbol),
          bestMonth: "Ocak",
          worstMonth: "Ocak",
        }
        yearlyData.push(newYearData)
      }

      // Son 10 yılı tut
      if (yearlyData.length > 10) {
        yearlyData.shift()
      }
    })
  }

  // AI analizi üret
  private generateAIAnalysis(symbol: string, data: LiveMarketData) {
    const analysis: AIAnalysis = {
      marketSentiment: this.getMarketSentiment() as any,
      trendDirection: data.trend === "YUKSELIS" ? "YUKARI" : data.trend === "DUSUS" ? "ASAGI" : "YATAY",
      timeframe: this.determineTimeframe(data.change7d),
      confidence: data.aiConfidence,
      reasoning: this.generateReasoning(data),
      keyFactors: this.generateKeyFactors(data),
      riskFactors: this.generateRiskFactors(data),
      opportunities: this.generateOpportunities(data),
    }

    this.aiAnalysis.set(symbol, analysis)
  }

  private determineTimeframe(change7d: number): "KISA_VADE" | "ORTA_VADE" | "UZUN_VADE" {
    if (Math.abs(change7d) > 15) return "KISA_VADE"
    if (Math.abs(change7d) > 5) return "ORTA_VADE"
    return "UZUN_VADE"
  }

  private generateReasoning(data: LiveMarketData): string {
    if (data.trend === "YUKSELIS") {
      return `${data.name} güçlü yükseliş trendinde. %${data.change7d.toFixed(1)} haftalık artış ile momentum devam ediyor.`
    } else if (data.trend === "DUSUS") {
      return `${data.name} düşüş baskısı altında. %${Math.abs(data.change7d).toFixed(1)} haftalık düşüş ile satış baskısı görülüyor.`
    }
    return `${data.name} konsolidasyon aşamasında. Yön belirsizliği devam ediyor.`
  }

  private generateKeyFactors(data: LiveMarketData): string[] {
    const factors = []

    if (data.change24h > 5) factors.push("Güçlü günlük performans")
    if (data.volume24h > 1000000000) factors.push("Yüksek işlem hacmi")
    if (data.aiConfidence > 80) factors.push("AI güven seviyesi yüksek")
    if (data.changeYTD > 50) factors.push("Yıllık performans güçlü")

    return factors.length > 0 ? factors : ["Standart piyasa koşulları"]
  }

  private generateRiskFactors(data: LiveMarketData): string[] {
    const risks = []

    if (data.riskLevel > 7) risks.push("Yüksek volatilite riski")
    if (data.change24h < -5) risks.push("Düşüş momentum riski")
    if (data.changeYTD > 200) risks.push("Aşırı değerlenme riski")

    return risks.length > 0 ? risks : ["Düşük risk profili"]
  }

  private generateOpportunities(data: LiveMarketData): string[] {
    const opportunities = []

    if (data.trend === "YUKSELIS" && data.aiConfidence > 80) {
      opportunities.push("Trend takip fırsatı")
    }
    if (data.change24h < -3 && data.change7d > 0) {
      opportunities.push("Düşüş alım fırsatı")
    }
    if (data.volume24h > data.marketCap * 0.05) {
      opportunities.push("Likidite avantajı")
    }

    return opportunities.length > 0 ? opportunities : ["Standart fırsatlar"]
  }

  // Abonelik sistemi
  subscribe(symbol: string, callback: (data: LiveMarketData) => void) {
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, [])
    }
    this.subscribers.get(symbol)!.push(callback)
  }

  private notifySubscribers(symbol: string, data: LiveMarketData) {
    const subscribers = this.subscribers.get(symbol) || []
    subscribers.forEach((callback) => callback(data))
  }

  // Veri getirme metodları
  getLiveData(symbol: string): LiveMarketData | null {
    return this.liveData.get(symbol) || null
  }

  getAllLiveData(): LiveMarketData[] {
    return Array.from(this.liveData.values())
  }

  getAIAnalysis(symbol: string): AIAnalysis | null {
    return this.aiAnalysis.get(symbol) || null
  }

  getDailyTrends(symbol: string): DailyTrend[] {
    return this.dailyTrends.get(symbol) || []
  }
}

export const aiLiveDataService = new AILiveDataService()
