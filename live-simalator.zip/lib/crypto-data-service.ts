// Gerçek Zamanlı Kripto Veri Servisi
export interface CryptoPrice {
  symbol: string
  price: number
  change24h: number
  changePercent24h: number
  volume24h: number
  marketCap: number
  lastUpdated: string
  high24h: number
  low24h: number
}

export interface CryptoCandle {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface MarketSentiment {
  fearGreedIndex: number
  trendingCoins: string[]
  marketDominance: {
    btc: number
    eth: number
    others: number
  }
}

class CryptoDataService {
  private wsConnections: Map<string, WebSocket> = new Map()
  private priceCache: Map<string, CryptoPrice> = new Map()
  private subscribers: Map<string, ((data: CryptoPrice) => void)[]> = new Map()

  // Binance WebSocket bağlantısı
  async connectToBinance(symbols: string[]) {
    const streamNames = symbols.map((symbol) => `${symbol.toLowerCase()}@ticker`).join("/")
    const wsUrl = `wss://stream.binance.com:9443/ws/${streamNames}`

    const ws = new WebSocket(wsUrl)

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      const cryptoPrice: CryptoPrice = {
        symbol: data.s,
        price: Number.parseFloat(data.c),
        change24h: Number.parseFloat(data.P),
        changePercent24h: Number.parseFloat(data.P),
        volume24h: Number.parseFloat(data.v),
        marketCap: 0, // Ayrı API'den alınacak
        lastUpdated: new Date().toISOString(),
        high24h: Number.parseFloat(data.h),
        low24h: Number.parseFloat(data.l),
      }

      this.updatePrice(cryptoPrice)
    }

    this.wsConnections.set("binance", ws)
  }

  // CoinGecko API entegrasyonu
  async fetchFromCoinGecko(coinIds: string[]): Promise<CryptoPrice[]> {
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${coinIds.join(",")}&vs_currencies=usd,try&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true`,
    )

    const data = await response.json()

    return Object.entries(data).map(([id, priceData]: [string, any]) => ({
      symbol: id.toUpperCase(),
      price: priceData.usd,
      change24h: priceData.usd_24h_change || 0,
      changePercent24h: priceData.usd_24h_change || 0,
      volume24h: priceData.usd_24h_vol || 0,
      marketCap: priceData.market_cap || 0,
      lastUpdated: new Date().toISOString(),
      high24h: 0, // WebSocket'ten alınacak
      low24h: 0,
    }))
  }

  // Fiyat güncelleme ve abonelere bildirim
  private updatePrice(cryptoPrice: CryptoPrice) {
    this.priceCache.set(cryptoPrice.symbol, cryptoPrice)

    const subscribers = this.subscribers.get(cryptoPrice.symbol) || []
    subscribers.forEach((callback) => callback(cryptoPrice))
  }

  // Fiyat değişikliklerine abone olma
  subscribe(symbol: string, callback: (data: CryptoPrice) => void) {
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, [])
    }
    this.subscribers.get(symbol)!.push(callback)
  }

  // Mevcut fiyatı getir
  getCurrentPrice(symbol: string): CryptoPrice | null {
    return this.priceCache.get(symbol) || null
  }

  // Market sentiment analizi
  async getMarketSentiment(): Promise<MarketSentiment> {
    // Fear & Greed Index
    const fearGreedResponse = await fetch("https://api.alternative.me/fng/")
    const fearGreedData = await fearGreedResponse.json()

    // Trending coins
    const trendingResponse = await fetch("https://api.coingecko.com/api/v3/search/trending")
    const trendingData = await trendingResponse.json()

    return {
      fearGreedIndex: Number.parseInt(fearGreedData.data[0].value),
      trendingCoins: trendingData.coins.slice(0, 10).map((coin: any) => coin.item.symbol),
      marketDominance: {
        btc: 45.2, // API'den alınacak
        eth: 18.7,
        others: 36.1,
      },
    }
  }

  // Bağlantıları kapat
  disconnect() {
    this.wsConnections.forEach((ws) => ws.close())
    this.wsConnections.clear()
  }
}

export const cryptoDataService = new CryptoDataService()
