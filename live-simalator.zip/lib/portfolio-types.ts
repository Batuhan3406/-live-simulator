export interface YatirimEnstrumani {
  id: string
  sembol: string
  ad: string
  kategori: "kripto" | "altin" | "borsa" | "doviz" | "emtia"
  guncelFiyat: number
  yatirimTutari: number
  miktar: number
  guncelDeger: number
  karZarar: number
  karZararYuzde: number
  gunlukDegisim: number
  haftalikDegisim: number
  sonGuncelleme: string
}

export interface PortfoyOzeti {
  toplamYatirim: number
  guncelDeger: number
  toplamKarZarar: number
  toplamKarZararYuzde: number
  gunlukDegisim: number
  haftalikDegisim: number
  aylikDegisim: number
}

export interface AIAnalizi {
  id: string
  tarih: string
  baslik: string
  aciklama: string
  oneri: "al" | "sat" | "bekle" | "artir" | "azalt"
  guvenSeviyesi: number
  etkilenenVarliklar: string[]
  oncelik: "yuksek" | "orta" | "dusuk"
}

export interface GrafikVerisi {
  tarih: string
  deger: number
  karZarar: number
}
