// User Management Types
export interface User {
  id: string
  email: string
  name?: string
  createdAt: string
  lastLogin: string
  balance: number
  totalInvestments: number
  totalGainLoss: number
}

// Investment Types
export interface Investment {
  id: string
  userId: string
  date: string
  asset: string
  type: "buy" | "sell"
  amount: number
  price: number
  total: number
  gainLoss?: number
  status: "active" | "closed"
}

export interface MarketData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume: number
  marketCap?: number
  lastUpdated: string
}

// AI Training Types
export interface TrainingSession {
  id: string
  userId: string
  date: string
  strategy: string
  decision: string
  outcome?: "success" | "failure" | "pending"
  marketConditions: Record<string, any>
  result?: {
    profitLoss: number
    accuracy: number
  }
}

export interface AIModel {
  id: string
  userId: string
  name: string
  trainingLevel: number
  totalSessions: number
  accuracy: number
  lastTrained: string
  strategies: string[]
  preferences: {
    riskTolerance: "low" | "medium" | "high"
    preferredAssets: string[]
    timeHorizon: "short" | "medium" | "long"
  }
}

export interface AIRecommendation {
  id: string
  userId: string
  modelId: string
  asset: string
  action: "buy" | "sell" | "hold"
  confidence: number
  reasoning: string
  expectedReturn?: number
  riskLevel: "low" | "medium" | "high"
  timestamp: string
  executed?: boolean
}

// Time System Types
export interface GameTime {
  id: string
  userId: string
  currentDate: string
  speed: number
  isPaused: boolean
  totalDaysSimulated: number
}

export interface EconomicEvent {
  id: string
  date: string
  time: string
  event: string
  importance: "high" | "medium" | "low"
  category: string
  expected?: string
  actual?: string
  impact: {
    assets: Record<string, number> // asset -> impact percentage
  }
}

export interface NewsItem {
  id: string
  date: string
  title: string
  content: string
  impact: "positive" | "negative" | "neutral"
  category: string
  affectedAssets: string[]
  sentimentScore: number
}

// Portfolio Types
export interface Portfolio {
  id: string
  userId: string
  totalValue: number
  cash: number
  investments: {
    asset: string
    quantity: number
    averagePrice: number
    currentValue: number
    gainLoss: number
    gainLossPercent: number
  }[]
  performance: {
    daily: number
    weekly: number
    monthly: number
    yearly: number
  }
  lastUpdated: string
}

// Analytics Types
export interface PerformanceMetrics {
  userId: string
  totalReturn: number
  totalReturnPercent: number
  sharpeRatio: number
  maxDrawdown: number
  winRate: number
  averageWin: number
  averageLoss: number
  totalTrades: number
  profitableTrades: number
  period: {
    start: string
    end: string
  }
}

// Database Schema Types (for backend implementation)
export interface DatabaseSchema {
  users: User[]
  investments: Investment[]
  training_sessions: TrainingSession[]
  ai_models: AIModel[]
  ai_recommendations: AIRecommendation[]
  market_data: MarketData[]
  economic_events: EconomicEvent[]
  news: NewsItem[]
  portfolios: Portfolio[]
  game_time: GameTime[]
  performance_metrics: PerformanceMetrics[]
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  hasNext: boolean
  hasPrev: boolean
}
