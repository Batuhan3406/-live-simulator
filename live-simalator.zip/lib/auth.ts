export interface User {
  id: string
  name: string
  email: string
}

export class AuthService {
  private static readonly STORAGE_KEY = "portfolio_user"

  static async login(email: string, password: string): Promise<User | null> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Demo credentials
    if (email === "demo@example.com" && password === "demo123") {
      const user: User = {
        id: "1",
        name: "Demo Kullanıcı",
        email: "demo@example.com",
      }

      // Store in localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(user))
      }

      return user
    }

    // Additional demo users
    if (email === "test@test.com" && password === "test123") {
      const user: User = {
        id: "2",
        name: "Test Kullanıcı",
        email: "test@test.com",
      }

      if (typeof window !== "undefined") {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(user))
      }

      return user
    }

    return null
  }

  static async getCurrentUser(): Promise<User | null> {
    if (typeof window === "undefined") return null

    try {
      const stored = localStorage.getItem(this.STORAGE_KEY)
      if (stored) {
        return JSON.parse(stored)
      }
    } catch (error) {
      console.error("Auth error:", error)
    }

    return null
  }

  static logout(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem(this.STORAGE_KEY)
    }
  }
}
