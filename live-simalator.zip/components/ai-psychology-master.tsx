"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, Shield, Target, Zap, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react"

interface PsychologyMetric {
  name: string
  aiScore: number
  humanScore: number
  description: string
  icon: React.ReactNode
  color: string
}

interface EmotionalState {
  emotion: string
  level: number
  impact: "positive" | "negative" | "neutral"
  aiResponse: string
}

interface TradingScenario {
  id: string
  scenario: string
  humanReaction: string
  aiReaction: string
  outcome: "ai_wins" | "human_wins" | "tie"
  explanation: string
}

export default function AIPsychologyMaster() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [currentEmotion, setCurrentEmotion] = useState<EmotionalState | null>(null)
  const [aiThoughts, setAiThoughts] = useState<string[]>([])
  const [scenarioIndex, setScenarioIndex] = useState(0)

  const psychologyMetrics: PsychologyMetric[] = [
    {
      name: "Duygusal Kontrol",
      aiScore: 95,
      humanScore: 25,
      description: "Korku, açgözlülük, FOMO kontrolü",
      icon: <Brain className="h-5 w-5" />,
      color: "text-purple-600",
    },
    {
      name: "Disiplin Seviyesi",
      aiScore: 98,
      humanScore: 30,
      description: "Plan ve stratejiye sadakat",
      icon: <Shield className="h-5 w-5" />,
      color: "text-blue-600",
    },
    {
      name: "FOMO Direnci",
      aiScore: 92,
      humanScore: 15,
      description: "Kaçırma korkusuna karşı direnç",
      icon: <Target className="h-5 w-5" />,
      color: "text-green-600",
    },
    {
      name: "Sabır Skoru",
      aiScore: 96,
      humanScore: 20,
      description: "Mükemmel setup için bekleme",
      icon: <Zap className="h-5 w-5" />,
      color: "text-yellow-600",
    },
    {
      name: "Objektiflik",
      aiScore: 99,
      humanScore: 35,
      description: "Data odaklı karar verme",
      icon: <TrendingUp className="h-5 w-5" />,
      color: "text-indigo-600",
    },
    {
      name: "Stress Yönetimi",
      aiScore: 94,
      humanScore: 40,
      description: "Yüksek volatilitede sakinlik",
      icon: <AlertTriangle className="h-5 w-5" />,
      color: "text-red-600",
    },
  ]

  const tradingScenarios: TradingScenario[] = [
    {
      id: "fomo_scenario",
      scenario: "Bitcoin %15 yükseldi, herkes alım yapıyor",
      humanReaction: "Panik halinde FOMO ile yüksek fiyattan alım",
      aiReaction: "Teknik analiz: RSI 85, aşırı alım bölgesi. BEKLE.",
      outcome: "ai_wins",
      explanation: "AI FOMO'ya kapılmadı, düzeltme sonrası daha iyi fiyattan aldı",
    },
    {
      id: "loss_scenario",
      scenario: "Pozisyon %20 zarar ediyor",
      humanReaction: "Panik, duygusal karar, stop-loss'u kaldırma",
      aiReaction: "Risk yönetimi planına sadık kal, stop-loss'u koru",
      outcome: "ai_wins",
      explanation: "AI disiplinli davrandı, daha büyük kayıpları önledi",
    },
    {
      id: "profit_scenario",
      scenario: "Pozisyon %50 kar ediyor",
      humanReaction: "Açgözlülük, daha fazla kar için bekleme",
      aiReaction: "Hedef kar seviyesi: %45. Pozisyonu kapat.",
      outcome: "ai_wins",
      explanation: "AI planına sadık kaldı, piyasa düştüğünde karı korudu",
    },
    {
      id: "volatility_scenario",
      scenario: "Piyasa çok volatil, %5 iniş çıkış",
      humanReaction: "Stress, sürekli pozisyon değiştirme",
      aiReaction: "Volatilite normal, plan değişmez. Sakin kal.",
      outcome: "ai_wins",
      explanation: "AI sakin kaldı, gereksiz işlem maliyetlerinden kaçındı",
    },
  ]

  const emotionalStates: EmotionalState[] = [
    {
      emotion: "FOMO (Kaçırma Korkusu)",
      level: 0,
      impact: "negative",
      aiResponse: "FOMO tespit edildi. Objektif analiz yapılıyor...",
    },
    {
      emotion: "Korku",
      level: 0,
      impact: "negative",
      aiResponse: "Korku faktörü sıfır. Risk matematiksel olarak hesaplanıyor.",
    },
    {
      emotion: "Açgözlülük",
      level: 0,
      impact: "negative",
      aiResponse: "Kar hedefi net. Açgözlülük algoritması devre dışı.",
    },
    {
      emotion: "Sabırsızlık",
      level: 0,
      impact: "negative",
      aiResponse: "Sınırsız sabır modu aktif. Mükemmel setup bekleniyor.",
    },
  ]

  // Gerçek zamanlı psikoloji analizi
  useEffect(() => {
    if (!isAnalyzing) return

    const interval = setInterval(() => {
      // Rastgele duygusal durum simülasyonu
      const randomEmotion = emotionalStates[Math.floor(Math.random() * emotionalStates.length)]
      setCurrentEmotion(randomEmotion)

      // AI düşünce süreci
      const thoughts = [
        "Piyasa volatil, AI sakin kalıyor...",
        "FOMO sinyali tespit edildi, AI bekliyor...",
        "Mükemmel setup bulundu, AI pozisyon açıyor...",
        "Risk limiti yaklaşıyor, AI pozisyon küçültüyor...",
        "Duygusal trader'lar panik yapıyor, AI objektif...",
        "Kar hedefi %45, AI disiplinli şekilde bekliyor...",
        "Stop-loss seviyesi net, AI planına sadık...",
        "Piyasa sentiment negatif, AI data odaklı analiz yapıyor...",
      ]

      const randomThought = thoughts[Math.floor(Math.random() * thoughts.length)]
      setAiThoughts((prev) => [randomThought, ...prev.slice(0, 9)])

      // Senaryo değiştirme
      setScenarioIndex((prev) => (prev + 1) % tradingScenarios.length)
    }, 3000)

    return () => clearInterval(interval)
  }, [isAnalyzing])

  const startAnalysis = () => {
    setIsAnalyzing(true)
  }

  const stopAnalysis = () => {
    setIsAnalyzing(false)
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 70) return "text-blue-600"
    if (score >= 50) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="space-y-6">
      {/* Ana Kontrol Paneli */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-600" />
            AI Psikoloji Üstünlüğü Analizi
          </CardTitle>
          <CardDescription>YouTube'dan öğrenilen psikoloji dersleri ile duygusuz trading</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <Button
              onClick={isAnalyzing ? stopAnalysis : startAnalysis}
              className={isAnalyzing ? "bg-red-600 hover:bg-red-700" : "bg-purple-600 hover:bg-purple-700"}
            >
              {isAnalyzing ? "Analizi Durdur" : "AI Psikoloji Analizi Başlat"}
            </Button>
            {isAnalyzing && (
              <Badge className="bg-purple-100 text-purple-800 animate-pulse">🧠 AI Psikoloji Aktif</Badge>
            )}
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">%0</p>
              <p className="text-sm text-gray-600">Duygusal Karar</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">%100</p>
              <p className="text-sm text-gray-600">Objektiflik</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">∞</p>
              <p className="text-sm text-gray-600">Sabır Süresi</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">%400</p>
              <p className="text-sm text-gray-600">İnsan Üstünlüğü</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Psikoloji Metrikleri */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>AI vs İnsan Psikoloji Karşılaştırması</CardTitle>
              <CardDescription>YouTube videosundan öğrenilen psikoloji dersleri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {psychologyMetrics.map((metric, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`${metric.color}`}>{metric.icon}</div>
                        <div>
                          <h4 className="font-semibold">{metric.name}</h4>
                          <p className="text-sm text-gray-600">{metric.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          AI: <span className={getScoreColor(metric.aiScore)}>%{metric.aiScore}</span>
                        </p>
                        <p className="text-sm font-medium">
                          İnsan: <span className={getScoreColor(metric.humanScore)}>%{metric.humanScore}</span>
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>AI Skoru</span>
                          <span>%{metric.aiScore}</span>
                        </div>
                        <Progress value={metric.aiScore} className="h-2 bg-green-100" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>İnsan Skoru</span>
                          <span>%{metric.humanScore}</span>
                        </div>
                        <Progress value={metric.humanScore} className="h-2 bg-red-100" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gerçek Zamanlı Duygusal Durum */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" />
                Duygusal Durum Monitörü
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentEmotion ? (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="font-semibold text-lg">{currentEmotion.emotion}</h4>
                    <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mt-2">
                      <span className="text-2xl font-bold text-green-600">{currentEmotion.level}%</span>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm font-medium text-blue-800">AI Tepkisi:</p>
                    <p className="text-sm text-blue-700 mt-1">{currentEmotion.aiResponse}</p>
                  </div>
                </div>
              ) : (
                <p className="text-center text-gray-500 py-8">Analizi başlatın...</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-600" />
                AI Düşünce Akışı
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {aiThoughts.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">AI düşünceleri burada görünecek...</p>
                ) : (
                  aiThoughts.map((thought, index) => (
                    <div key={index} className="p-2 bg-gray-50 rounded text-sm">
                      <span className="text-purple-600 font-medium">AI: </span>
                      {thought}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Trading Senaryoları */}
      <Card>
        <CardHeader>
          <CardTitle>Gerçek Trading Senaryoları</CardTitle>
          <CardDescription>AI vs İnsan tepkileri karşılaştırması</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {tradingScenarios.map((scenario, index) => (
              <div key={scenario.id} className="border rounded-lg p-4">
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">📊 Senaryo:</h4>
                  <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">{scenario.scenario}</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <h5 className="font-medium text-red-600 mb-1">👤 İnsan Tepkisi:</h5>
                    <p className="text-sm text-gray-700 bg-red-50 p-2 rounded">{scenario.humanReaction}</p>
                  </div>

                  <div>
                    <h5 className="font-medium text-green-600 mb-1">🤖 AI Tepkisi:</h5>
                    <p className="text-sm text-gray-700 bg-green-50 p-2 rounded">{scenario.aiReaction}</p>
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between">
                      <Badge
                        className={
                          scenario.outcome === "ai_wins"
                            ? "bg-green-100 text-green-800"
                            : scenario.outcome === "human_wins"
                              ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800"
                        }
                      >
                        {scenario.outcome === "ai_wins"
                          ? "🏆 AI Kazandı"
                          : scenario.outcome === "human_wins"
                            ? "👤 İnsan Kazandı"
                            : "🤝 Berabere"}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mt-2">{scenario.explanation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* YouTube Öğrenme Sonuçları */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardHeader>
          <CardTitle>YouTube'dan Öğrenilen Psikoloji Dersleri</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 text-green-800">Coin Engineer'den Öğrenilenler:</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                  <span>
                    <strong>"En büyük düşman kendi duygularınız"</strong> - AI: Duygum yok! ✅
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                  <span>
                    <strong>"Plan olmadan trading kumar"</strong> - AI: Her işlem planlanır! ✅
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                  <span>
                    <strong>"Kayıplar trading'in doğal parçası"</strong> - AI: Objektif kabul! ✅
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                  <span>
                    <strong>"Tutarlılık büyük karlardan önemli"</strong> - AI: Her gün aynı disiplin! ✅
                  </span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-3 text-blue-800">AI'nın Psikolojik Süper Güçleri:</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                  <span>
                    <strong>%0 FOMO:</strong> Hiçbir zaman "kaçırma korkusu" yaşamaz
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                  <span>
                    <strong>Sınırsız Sabır:</strong> Mükemmel setup için günlerce bekler
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                  <span>
                    <strong>Matematiksel Objektiflik:</strong> Sadece data ile karar verir
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Brain className="h-4 w-4 text-blue-600 mt-0.5" />
                  <span>
                    <strong>%100 Disiplin:</strong> Plana %100 sadık kalır
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
