"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Zap, Activity, Target, Brain } from "lucide-react"
import { cryptoDataService, type CryptoPrice, type MarketSentiment } from "@/lib/crypto-data-service"

interface TradingSignal {
  symbol: string
  signal: "BUY" | "SELL" | "HOLD"
  confidence: number
  reason: string
  targetPrice: number
  stopLoss: number
}

export default function RealTimeCryptoDashboard() {
  const [cryptoPrices, setCryptoPrices] = useState<Map<string, CryptoPrice>>(new Map())
  const [marketSentiment, setMarketSentiment] = useState<MarketSentiment | null>(null)
  const [tradingSignals, setTradingSignals] = useState<TradingSignal[]>([])
  const [isConnected, setIsConnected] = useState(false)
  const [selectedTimeframe, setSelectedTimeframe] = useState<"1m" | "5m" | "15m" | "1h">("5m")

  // İzlenecek kripto paralar
  const watchedCoins = [
    { symbol: "BTCUSDT", name: "Bitcoin", icon: "₿" },
    { symbol: "ETHUSDT", name: "Ethereum", icon: "Ξ" },
    { symbol: "ADAUSDT", name: "Cardano", icon: "₳" },
    { symbol: "DOTUSDT", name: "Polkadot", icon: "●" },
    { symbol: "LINKUSDT", name: "Chainlink", icon: "⬢" },
    { symbol: "SOLUSDT", name: "Solana", icon: "◎" },
  ]

  useEffect(() => {
    // WebSocket bağlantısını başlat
    const initializeConnection = async () => {
      try {
        await cryptoDataService.connectToBinance(watchedCoins.map((coin) => coin.symbol))

        // Her coin için abone ol
        watchedCoins.forEach((coin) => {
          cryptoDataService.subscribe(coin.symbol, (priceData) => {
            setCryptoPrices((prev) => new Map(prev.set(coin.symbol, priceData)))

            // Trading sinyali üret
            generateTradingSignal(priceData)
          })
        })

        setIsConnected(true)

        // Market sentiment'i al
        const sentiment = await cryptoDataService.getMarketSentiment()
        setMarketSentiment(sentiment)
      } catch (error) {
        console.error("Kripto veri bağlantısı başarısız:", error)
        setIsConnected(false)
      }
    }

    initializeConnection()

    // Cleanup
    return () => {
      cryptoDataService.disconnect()
    }
  }, [])

  // AI destekli trading sinyali üretimi
  const generateTradingSignal = (priceData: CryptoPrice) => {
    const { symbol, price, changePercent24h, volume24h } = priceData

    let signal: "BUY" | "SELL" | "HOLD" = "HOLD"
    let confidence = 50
    let reason = "Piyasa analizi devam ediyor"

    // Basit AI logic (gerçek uygulamada daha karmaşık olacak)
    if (changePercent24h > 5 && volume24h > 1000000) {
      signal = "BUY"
      confidence = Math.min(85, 60 + changePercent24h)
      reason = "Güçlü yükseliş trendi ve yüksek volume"
    } else if (changePercent24h < -5 && volume24h > 1000000) {
      signal = "SELL"
      confidence = Math.min(85, 60 + Math.abs(changePercent24h))
      reason = "Düşüş trendi ve yüksek satış baskısı"
    } else if (Math.abs(changePercent24h) < 2) {
      signal = "HOLD"
      confidence = 70
      reason = "Konsolidasyon aşaması, beklemek mantıklı"
    }

    const newSignal: TradingSignal = {
      symbol,
      signal,
      confidence,
      reason,
      targetPrice: signal === "BUY" ? price * 1.05 : price * 0.95,
      stopLoss: signal === "BUY" ? price * 0.98 : price * 1.02,
    }

    setTradingSignals((prev) => {
      const filtered = prev.filter((s) => s.symbol !== symbol)
      return [newSignal, ...filtered].slice(0, 10) // Son 10 sinyal
    })
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 6,
    }).format(price)
  }

  const formatChange = (change: number) => {
    const formatted = change.toFixed(2)
    return change >= 0 ? `+${formatted}%` : `${formatted}%`
  }

  const getFearGreedColor = (index: number) => {
    if (index <= 25) return "bg-red-500"
    if (index <= 45) return "bg-orange-500"
    if (index <= 55) return "bg-yellow-500"
    if (index <= 75) return "bg-green-400"
    return "bg-green-600"
  }

  const getFearGreedText = (index: number) => {
    if (index <= 25) return "Aşırı Korku"
    if (index <= 45) return "Korku"
    if (index <= 55) return "Nötr"
    if (index <= 75) return "Açgözlülük"
    return "Aşırı Açgözlülük"
  }

  return (
    <div className="space-y-6">
      {/* Bağlantı Durumu */}
      <Card className={`border-l-4 ${isConnected ? "border-l-green-500 bg-green-50" : "border-l-red-500 bg-red-50"}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${isConnected ? "bg-green-500 animate-pulse" : "bg-red-500"}`}
              ></div>
              <span className="font-semibold">{isConnected ? "Gerçek Zamanlı Veri Aktif" : "Bağlantı Sorunu"}</span>
            </div>
            <Badge variant={isConnected ? "default" : "destructive"}>{isConnected ? "CANLI" : "OFFLINE"}</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Market Sentiment */}
      {marketSentiment && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-600" />
              Piyasa Duygu Analizi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Korku & Açgözlülük Endeksi</span>
                  <span className="text-lg font-bold">{marketSentiment.fearGreedIndex}</span>
                </div>
                <Progress value={marketSentiment.fearGreedIndex} className="h-2 mb-1" />
                <p className="text-xs text-gray-600">{getFearGreedText(marketSentiment.fearGreedIndex)}</p>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Piyasa Dominansı</p>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Bitcoin</span>
                    <span>{marketSentiment.marketDominance.btc}%</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span>Ethereum</span>
                    <span>{marketSentiment.marketDominance.eth}%</span>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Trend Coinler</p>
                <div className="flex flex-wrap gap-1">
                  {marketSentiment.trendingCoins.slice(0, 6).map((coin) => (
                    <Badge key={coin} variant="outline" className="text-xs">
                      {coin}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Kripto Fiyatları */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            Gerçek Zamanlı Kripto Fiyatları
          </CardTitle>
          <CardDescription>Binance WebSocket üzerinden canlı veriler</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {watchedCoins.map((coin) => {
              const priceData = cryptoPrices.get(coin.symbol)
              if (!priceData)
                return (
                  <div key={coin.symbol} className="border rounded-lg p-4 animate-pulse">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-6 bg-gray-200 rounded"></div>
                  </div>
                )

              const isPositive = priceData.changePercent24h >= 0

              return (
                <div key={coin.symbol} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{coin.icon}</span>
                      <div>
                        <p className="font-semibold text-sm">{coin.name}</p>
                        <p className="text-xs text-gray-500">{coin.symbol}</p>
                      </div>
                    </div>
                    {isPositive ? (
                      <TrendingUp className="h-4 w-4 text-green-600" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-600" />
                    )}
                  </div>

                  <div className="space-y-1">
                    <p className="text-xl font-bold">{formatPrice(priceData.price)}</p>
                    <p className={`text-sm font-medium ${isPositive ? "text-green-600" : "text-red-600"}`}>
                      {formatChange(priceData.changePercent24h)}
                    </p>
                    <p className="text-xs text-gray-500">Volume: ${(priceData.volume24h / 1000000).toFixed(1)}M</p>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* AI Trading Sinyalleri */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-orange-600" />
            AI Trading Sinyalleri
          </CardTitle>
          <CardDescription>Gerçek zamanlı verilerle üretilen akıllı öneriler</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {tradingSignals.length === 0 ? (
              <p className="text-center text-gray-500 py-8">Sinyaller analiz ediliyor...</p>
            ) : (
              tradingSignals.map((signal, index) => (
                <div key={`${signal.symbol}-${index}`} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <Badge
                        className={
                          signal.signal === "BUY"
                            ? "bg-green-100 text-green-800"
                            : signal.signal === "SELL"
                              ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800"
                        }
                      >
                        {signal.signal}
                      </Badge>
                      <span className="font-semibold">{signal.symbol}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-yellow-600" />
                      <span className="text-sm font-medium">{signal.confidence}%</span>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 mb-2">{signal.reason}</p>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-gray-500">Hedef: </span>
                      <span className="font-medium">{formatPrice(signal.targetPrice)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Stop Loss: </span>
                      <span className="font-medium">{formatPrice(signal.stopLoss)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Zaman Dilimi Seçici */}
      <Card>
        <CardHeader>
          <CardTitle>Analiz Zaman Dilimi</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            {(["1m", "5m", "15m", "1h"] as const).map((timeframe) => (
              <Button
                key={timeframe}
                variant={selectedTimeframe === timeframe ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTimeframe(timeframe)}
              >
                {timeframe}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
