"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import {
  Brain,
  Eye,
  Zap,
  Activity,
  TrendingUp,
  MessageSquare,
  Cpu,
  BarChart3,
  Target,
  Lightbulb,
  Search,
  CheckCircle,
} from "lucide-react"

interface AIThought {
  id: string
  timestamp: string
  type: "analysis" | "decision" | "learning" | "prediction"
  content: string
  confidence: number
  data: any
  status: "thinking" | "completed" | "executing"
}

interface AIPersonality {
  name: string
  avatar: string
  specialty: string
  experience: string
  currentMood: "confident" | "cautious" | "aggressive" | "analytical"
  learningProgress: number
}

export default function VisibleAIBrain() {
  const [aiPersonality, setAiPersonality] = useState<AIPersonality>({
    name: "ARIA",
    avatar: "🤖",
    specialty: "Crypto Trading & Risk Analysis",
    experience: "2847 işlem, %73.2 başarı oranı",
    currentMood: "analytical",
    learningProgress: 78.5,
  })

  const [aiThoughts, setAiThoughts] = useState<AIThought[]>([])
  const [isThinking, setIsThinking] = useState(false)
  const [userMessage, setUserMessage] = useState("")
  const [currentAnalysis, setCurrentAnalysis] = useState<any>(null)

  // AI düşünce simülasyonu
  useEffect(() => {
    const thinkingInterval = setInterval(() => {
      generateAIThought()
    }, 3000)

    return () => clearInterval(thinkingInterval)
  }, [])

  const generateAIThought = () => {
    const thoughtTypes = [
      {
        type: "analysis" as const,
        thoughts: [
          "Bitcoin'de RSI 32 seviyesinde, oversold bölgesine yaklaşıyor...",
          "Ethereum'da volume artışı gözlemliyorum, potansiel breakout sinyali...",
          "Market sentiment %68 fear seviyesinde, contrarian yaklaşım düşünüyorum...",
          "DXY güçleniyor, crypto'lar üzerinde baskı oluşturabilir...",
          "Fibonacci retracement seviyelerini analiz ediyorum...",
        ],
      },
      {
        type: "decision" as const,
        thoughts: [
          "BTCUSDT için BUY sinyali üretiyorum, %87 güven seviyesi...",
          "Risk/reward oranı 1:3, pozisyon boyutu %2 olarak hesaplıyorum...",
          "Stop-loss seviyesini $42,800 olarak belirliyorum...",
          "Portföy çeşitlendirmesi için ETHUSDT eklemeyi öneriyorum...",
          "Mevcut pozisyonları koruma moduna geçiyorum...",
        ],
      },
      {
        type: "learning" as const,
        thoughts: [
          "Son 10 işlemden 8'i başarılı, stratejiyi güncelliyorum...",
          "Haber etkilerini daha iyi analiz etmeyi öğreniyorum...",
          "Kullanıcı davranış kalıplarını neural network'e ekliyorum...",
          "Yeni pattern recognition algoritması entegre ediliyor...",
          "Risk toleransı profilini güncelledim...",
        ],
      },
      {
        type: "prediction" as const,
        thoughts: [
          "Sonraki 4 saatte %2.3 yükseliş bekliyorum...",
          "Fed toplantısı sonrası volatilite artacak, hazırlık yapıyorum...",
          "Altcoin season yaklaşıyor, portföy ağırlığını ayarlıyorum...",
          "Hafta sonu düşük volume beklentisi, pozisyon azaltıyorum...",
          "Teknik analiz %78 bull sinyali veriyor...",
        ],
      },
    ]

    const randomType = thoughtTypes[Math.floor(Math.random() * thoughtTypes.length)]
    const randomThought = randomType.thoughts[Math.floor(Math.random() * randomType.thoughts.length)]

    const newThought: AIThought = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString("tr-TR"),
      type: randomType.type,
      content: randomThought,
      confidence: Math.floor(Math.random() * 30) + 70,
      data: {
        marketData: "BTC: $43,250, ETH: $3,180",
        indicators: "RSI: 32, MACD: Bullish",
      },
      status: "thinking",
    }

    setAiThoughts((prev) => [newThought, ...prev.slice(0, 9)])

    // Düşünce tamamlanma simülasyonu
    setTimeout(() => {
      setAiThoughts((prev) =>
        prev.map((thought) => (thought.id === newThought.id ? { ...thought, status: "completed" } : thought)),
      )
    }, 2000)
  }

  const handleUserMessage = () => {
    if (!userMessage.trim()) return

    setIsThinking(true)

    // AI cevap simülasyonu
    setTimeout(() => {
      const aiResponse: AIThought = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleTimeString("tr-TR"),
        type: "analysis",
        content: `"${userMessage}" sorunuzu analiz ettim. Mevcut piyasa koşullarına göre şu önerilerde bulunuyorum: Risk seviyenizi %15'e çıkarabilir, stop-loss kullanmayı unutmayın. Detaylı analiz için teknik göstergeleri inceliyorum...`,
        confidence: 89,
        data: { userQuestion: userMessage },
        status: "completed",
      }

      setAiThoughts((prev) => [aiResponse, ...prev.slice(0, 9)])
      setUserMessage("")
      setIsThinking(false)
    }, 3000)
  }

  const getThoughtIcon = (type: string) => {
    switch (type) {
      case "analysis":
        return <Search className="h-4 w-4" />
      case "decision":
        return <Target className="h-4 w-4" />
      case "learning":
        return <Brain className="h-4 w-4" />
      case "prediction":
        return <TrendingUp className="h-4 w-4" />
      default:
        return <Lightbulb className="h-4 w-4" />
    }
  }

  const getThoughtColor = (type: string) => {
    switch (type) {
      case "analysis":
        return "bg-blue-100 text-blue-800"
      case "decision":
        return "bg-green-100 text-green-800"
      case "learning":
        return "bg-purple-100 text-purple-800"
      case "prediction":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "confident":
        return "😎"
      case "cautious":
        return "🤔"
      case "aggressive":
        return "🚀"
      case "analytical":
        return "🧠"
      default:
        return "🤖"
    }
  }

  return (
    <div className="space-y-6">
      {/* AI Kişiliği ve Durumu */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl">
              {aiPersonality.avatar}
            </div>
            <div>
              <span className="text-xl font-bold">{aiPersonality.name}</span>
              <p className="text-sm text-gray-600">{aiPersonality.specialty}</p>
            </div>
            <div className="ml-auto text-2xl">{getMoodEmoji(aiPersonality.currentMood)}</div>
          </CardTitle>
          <CardDescription>{aiPersonality.experience}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Öğrenme İlerlemesi</span>
                <span>{aiPersonality.learningProgress}%</span>
              </div>
              <Progress value={aiPersonality.learningProgress} className="h-2" />
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-blue-600">AKTIF</p>
              <p className="text-xs text-gray-600">Durum</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-green-600">%89</p>
              <p className="text-xs text-gray-600">Güven Seviyesi</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* AI Düşünce Akışı */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-600 animate-pulse" />
                AI Düşünce Akışı (Gerçek Zamanlı)
              </CardTitle>
              <CardDescription>ARIA'nın analiz sürecini canlı olarak izleyin</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {aiThoughts.map((thought) => (
                  <div
                    key={thought.id}
                    className={`border rounded-lg p-4 ${
                      thought.status === "thinking" ? "border-blue-300 bg-blue-50" : "border-gray-200"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className={getThoughtColor(thought.type)}>
                          {getThoughtIcon(thought.type)}
                          <span className="ml-1 capitalize">{thought.type}</span>
                        </Badge>
                        <span className="text-xs text-gray-500">{thought.timestamp}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {thought.status === "thinking" ? (
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-100"></div>
                            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-200"></div>
                          </div>
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        )}
                        <Badge variant="outline">{thought.confidence}%</Badge>
                      </div>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{thought.content}</p>
                    {thought.data && (
                      <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                        <strong>Veri:</strong> {JSON.stringify(thought.data, null, 2)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI ile Konuşma */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-green-600" />
                AI ile Konuş
              </CardTitle>
              <CardDescription>ARIA'ya doğrudan soru sorun</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={userMessage}
                onChange={(e) => setUserMessage(e.target.value)}
                placeholder="Örnek: Bitcoin'e yatırım yapmalı mıyım? Risk seviyem nasıl olmalı?"
                rows={3}
              />
              <Button
                onClick={handleUserMessage}
                disabled={!userMessage.trim() || isThinking}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {isThinking ? (
                  <>
                    <Brain className="h-4 w-4 mr-2 animate-spin" />
                    AI Düşünüyor...
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 mr-2" />
                    AI'ya Sor
                  </>
                )}
              </Button>

              {/* Hızlı Sorular */}
              <div className="space-y-2">
                <p className="text-sm font-medium">Hızlı Sorular:</p>
                {[
                  "Şu anda hangi coin'e yatırım önerirsin?",
                  "Risk seviyemi nasıl ayarlamalıyım?",
                  "Portföyümü nasıl çeşitlendirmeliyim?",
                  "Stop-loss nerede olmalı?",
                ].map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full text-left justify-start h-auto p-2 text-xs bg-transparent"
                    onClick={() => setUserMessage(question)}
                  >
                    {question}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI Beyin Aktivitesi */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5 text-orange-600" />
                Beyin Aktivitesi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Analiz Gücü</span>
                    <span>94%</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Öğrenme Hızı</span>
                    <span>87%</span>
                  </div>
                  <Progress value={87} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Karar Verme</span>
                    <span>91%</span>
                  </div>
                  <Progress value={91} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Risk Analizi</span>
                    <span>96%</span>
                  </div>
                  <Progress value={96} className="h-2" />
                </div>
              </div>

              <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="h-4 w-4 text-orange-600" />
                  <span className="text-sm font-medium">Şu anda:</span>
                </div>
                <p className="text-xs text-orange-700">
                  15 farklı kripto para analiz ediliyor, 3 yeni pattern öğreniliyor, risk matrisi güncelleniyor...
                </p>
              </div>
            </CardContent>
          </Card>

          {/* AI İstatistikleri */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Performans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-lg font-bold text-green-600">2,847</p>
                  <p className="text-xs text-gray-600">Toplam İşlem</p>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-lg font-bold text-blue-600">%73.2</p>
                  <p className="text-xs text-gray-600">Başarı Oranı</p>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <p className="text-lg font-bold text-purple-600">$127K</p>
                  <p className="text-xs text-gray-600">Toplam Kar</p>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <p className="text-lg font-bold text-orange-600">1.8s</p>
                  <p className="text-xs text-gray-600">Analiz Süresi</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Öğrenme Süreci */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            AI Öğrenme Süreci (Canlı)
          </CardTitle>
          <CardDescription>ARIA'nın nasıl öğrendiğini ve geliştiğini izleyin</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Eye className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-sm">Veri Toplama</h3>
              <p className="text-xs text-gray-600">Piyasa verilerini sürekli analiz ediyor</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Brain className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-sm">Pattern Tanıma</h3>
              <p className="text-xs text-gray-600">Yeni kalıpları öğreniyor ve kaydediyor</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Target className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold text-sm">Karar Optimizasyonu</h3>
              <p className="text-xs text-gray-600">Başarılı stratejileri güçlendiriyor</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Zap className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="font-semibold text-sm">Hızlı Adaptasyon</h3>
              <p className="text-xs text-gray-600">Piyasa değişikliklerine anında uyum</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
