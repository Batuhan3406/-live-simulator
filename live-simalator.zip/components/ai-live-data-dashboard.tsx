"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Brain,
  Zap,
  Target,
  Calendar,
  BarChart3,
  LineChart,
  AlertTriangle,
} from "lucide-react"
import { aiLiveDataService, type LiveMarketData, type AIAnalysis, type DailyTrend } from "@/lib/ai-live-data-service"

export default function AILiveDataDashboard() {
  const [isLiveMode, setIsLiveMode] = useState(false)
  const [liveData, setLiveData] = useState<LiveMarketData[]>([])
  const [selectedSymbol, setSelectedSymbol] = useState<string>("BTC")
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null)
  const [dailyTrends, setDailyTrends] = useState<DailyTrend[]>([])
  const [selectedTimeframe, setSelectedTimeframe] = useState<"24h" | "7d" | "30d" | "1y">("24h")

  // Canlı veri akışını başlat/durdur
  const toggleLiveMode = async () => {
    if (isLiveMode) {
      aiLiveDataService.stopLiveDataStream()
      setIsLiveMode(false)
    } else {
      await aiLiveDataService.startLiveDataStream()
      setIsLiveMode(true)

      // İlk veriyi yükle
      updateData()[
        // Abonelikleri başlat
        ("BTC", "ETH", "SOL")
      ].forEach((symbol) => {
        aiLiveDataService.subscribe(symbol, (data) => {
          setLiveData((prev) => {
            const updated = prev.filter((item) => item.symbol !== symbol)
            return [...updated, data].sort((a, b) => b.marketCap - a.marketCap)
          })

          if (symbol === selectedSymbol) {
            setAiAnalysis(aiLiveDataService.getAIAnalysis(symbol))
            setDailyTrends(aiLiveDataService.getDailyTrends(symbol))
          }
        })
      })
    }
  }

  // Veri güncelleme
  const updateData = () => {
    const allData = aiLiveDataService.getAllLiveData()
    setLiveData(allData)

    if (selectedSymbol) {
      setAiAnalysis(aiLiveDataService.getAIAnalysis(selectedSymbol))
      setDailyTrends(aiLiveDataService.getDailyTrends(selectedSymbol))
    }
  }

  // Seçili sembol değiştiğinde
  useEffect(() => {
    if (selectedSymbol) {
      setAiAnalysis(aiLiveDataService.getAIAnalysis(selectedSymbol))
      setDailyTrends(aiLiveDataService.getDailyTrends(selectedSymbol))
    }
  }, [selectedSymbol])

  // İlk yükleme
  useEffect(() => {
    updateData()
  }, [])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 6,
    }).format(price)
  }

  const formatLargeNumber = (num: number) => {
    return new Intl.NumberFormat("tr-TR", {
      notation: "compact",
      compactDisplay: "short",
    }).format(num)
  }

  const getChangeColor = (change: number) => {
    return change >= 0 ? "text-green-600" : "text-red-600"
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "YUKSELIS":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "DUSUS":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  const getPredictionColor = (prediction: string) => {
    switch (prediction) {
      case "AL":
        return "bg-green-100 text-green-800"
      case "SAT":
        return "bg-red-100 text-red-800"
      case "BEKLE":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "AŞIRI_AÇGÖZLÜLÜK":
        return "bg-red-500"
      case "AÇGÖZLÜLÜK":
        return "bg-orange-500"
      case "NÖTR":
        return "bg-yellow-500"
      case "KORKU":
        return "bg-blue-500"
      case "AŞIRI_KORKU":
        return "bg-purple-500"
      default:
        return "bg-gray-500"
    }
  }

  const getChangeValue = (data: LiveMarketData, timeframe: string) => {
    switch (timeframe) {
      case "24h":
        return data.change24h
      case "7d":
        return data.change7d
      case "30d":
        return data.change30d
      case "1y":
        return data.changeYTD
      default:
        return data.change24h
    }
  }

  return (
    <div className="space-y-6">
      {/* AI Canlı Veri Kontrol Paneli */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-600" />
            AI Destekli Canlı Veri Merkezi - 2025+
          </CardTitle>
          <CardDescription>Yapay zeka ile sürekli güncellenen piyasa verileri ve analiz sistemi</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <Button
              onClick={toggleLiveMode}
              className={isLiveMode ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
              size="lg"
            >
              {isLiveMode ? "🛑 Canlı Veriyi Durdur" : "🚀 Canlı Veriyi Başlat"}
            </Button>

            {isLiveMode && (
              <div className="flex items-center gap-4">
                <Badge className="bg-green-100 text-green-800 animate-pulse">🔴 CANLI VERİ AKTİF</Badge>
                <Badge variant="outline">Son Güncelleme: {new Date().toLocaleTimeString("tr-TR")}</Badge>
              </div>
            )}
          </div>

          {/* Zaman Dilimi Seçici */}
          <div className="flex gap-2 mb-4">
            {(["24h", "7d", "30d", "1y"] as const).map((timeframe) => (
              <Button
                key={timeframe}
                variant={selectedTimeframe === timeframe ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTimeframe(timeframe)}
              >
                {timeframe}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="live-table" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="live-table">Canlı Tablo</TabsTrigger>
          <TabsTrigger value="ai-analysis">AI Analizi</TabsTrigger>
          <TabsTrigger value="daily-trends">Günlük Trendler</TabsTrigger>
          <TabsTrigger value="yearly-data">Yıllık Veriler</TabsTrigger>
        </TabsList>

        <TabsContent value="live-table" className="space-y-6">
          {/* Canlı Veri Tablosu */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Canlı Piyasa Verileri - Her Gün Güncellenen
              </CardTitle>
              <CardDescription>AI tarafından sürekli analiz edilen ve güncellenen piyasa verileri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Varlık</th>
                      <th className="text-left p-3 font-semibold">Fiyat</th>
                      <th className="text-left p-3 font-semibold">Değişim ({selectedTimeframe})</th>
                      <th className="text-left p-3 font-semibold">Hacim</th>
                      <th className="text-left p-3 font-semibold">Market Cap</th>
                      <th className="text-left p-3 font-semibold">Trend</th>
                      <th className="text-left p-3 font-semibold">AI Önerisi</th>
                      <th className="text-left p-3 font-semibold">Güven</th>
                      <th className="text-left p-3 font-semibold">Risk</th>
                      <th className="text-left p-3 font-semibold">Hedef</th>
                    </tr>
                  </thead>
                  <tbody>
                    {liveData.map((data) => (
                      <tr
                        key={data.symbol}
                        className={`border-b hover:bg-gray-50 cursor-pointer ${selectedSymbol === data.symbol ? "bg-blue-50" : ""}`}
                        onClick={() => setSelectedSymbol(data.symbol)}
                      >
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <div>
                              <p className="font-medium">{data.name}</p>
                              <p className="text-sm text-gray-600">{data.symbol}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3 font-medium">{formatPrice(data.price)}</td>
                        <td className="p-3">
                          <span className={`font-medium ${getChangeColor(getChangeValue(data, selectedTimeframe))}`}>
                            {getChangeValue(data, selectedTimeframe) >= 0 ? "+" : ""}
                            {getChangeValue(data, selectedTimeframe).toFixed(2)}%
                          </span>
                        </td>
                        <td className="p-3">${formatLargeNumber(data.volume24h)}</td>
                        <td className="p-3">${formatLargeNumber(data.marketCap)}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-1">
                            {getTrendIcon(data.trend)}
                            <span className="text-sm">{data.trend}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <Badge className={getPredictionColor(data.aiPrediction)}>{data.aiPrediction}</Badge>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">%{data.aiConfidence}</span>
                            <div className="w-12">
                              <Progress value={data.aiConfidence} className="h-1" />
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <span
                            className={`font-medium ${
                              data.riskLevel <= 3
                                ? "text-green-600"
                                : data.riskLevel <= 6
                                  ? "text-yellow-600"
                                  : "text-red-600"
                            }`}
                          >
                            {data.riskLevel}/10
                          </span>
                        </td>
                        <td className="p-3 text-sm">{formatPrice(data.nextTarget)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai-analysis" className="space-y-6">
          {/* AI Analizi */}
          {aiAnalysis && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-600" />
                  {selectedSymbol} AI Analizi
                </CardTitle>
                <CardDescription>Yapay zeka tarafından üretilen detaylı piyasa analizi</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Piyasa Duygusu</h4>
                      <div className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded-full ${getSentimentColor(aiAnalysis.marketSentiment)}`}></div>
                        <span className="font-medium">{aiAnalysis.marketSentiment.replace("_", " ")}</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Trend Yönü</h4>
                      <div className="flex items-center gap-2">
                        {aiAnalysis.trendDirection === "YUKARI" && <TrendingUp className="h-4 w-4 text-green-600" />}
                        {aiAnalysis.trendDirection === "ASAGI" && <TrendingDown className="h-4 w-4 text-red-600" />}
                        {aiAnalysis.trendDirection === "YATAY" && <Activity className="h-4 w-4 text-gray-600" />}
                        <span className="font-medium">{aiAnalysis.trendDirection}</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Zaman Dilimi</h4>
                      <Badge variant="outline">{aiAnalysis.timeframe.replace("_", " ")}</Badge>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">AI Güven Seviyesi</h4>
                      <div className="flex items-center gap-2">
                        <Progress value={aiAnalysis.confidence} className="flex-1" />
                        <span className="font-medium">%{aiAnalysis.confidence}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">AI Gerekçesi</h4>
                      <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-lg">{aiAnalysis.reasoning}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Anahtar Faktörler</h4>
                      <div className="space-y-1">
                        {aiAnalysis.keyFactors.map((factor, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <Zap className="h-3 w-3 text-yellow-600" />
                            <span className="text-sm">{factor}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Risk Faktörleri</h4>
                      <div className="space-y-1">
                        {aiAnalysis.riskFactors.map((risk, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <AlertTriangle className="h-3 w-3 text-red-600" />
                            <span className="text-sm">{risk}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Fırsatlar</h4>
                      <div className="space-y-1">
                        {aiAnalysis.opportunities.map((opportunity, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <Target className="h-3 w-3 text-green-600" />
                            <span className="text-sm">{opportunity}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="daily-trends" className="space-y-6">
          {/* Günlük Trendler */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                {selectedSymbol} Günlük Trend Analizi
              </CardTitle>
              <CardDescription>Her gün otomatik olarak kaydedilen trend verileri</CardDescription>
            </CardHeader>
            <CardContent>
              {dailyTrends.length > 0 ? (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-4 gap-4 mb-6">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">{dailyTrends.length}</p>
                      <p className="text-sm text-gray-600">Toplam Gün</p>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">
                        {dailyTrends.filter((t) => t.change > 0).length}
                      </p>
                      <p className="text-sm text-gray-600">Pozitif Gün</p>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <p className="text-2xl font-bold text-red-600">
                        {dailyTrends.filter((t) => t.change < 0).length}
                      </p>
                      <p className="text-sm text-gray-600">Negatif Gün</p>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <p className="text-2xl font-bold text-purple-600">
                        {dailyTrends.length > 0
                          ? Math.round(dailyTrends.reduce((sum, t) => sum + t.aiScore, 0) / dailyTrends.length)
                          : 0}
                      </p>
                      <p className="text-sm text-gray-600">Ort. AI Skoru</p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-3 font-semibold">Tarih</th>
                          <th className="text-left p-3 font-semibold">Açılış</th>
                          <th className="text-left p-3 font-semibold">Kapanış</th>
                          <th className="text-left p-3 font-semibold">Yüksek</th>
                          <th className="text-left p-3 font-semibold">Düşük</th>
                          <th className="text-left p-3 font-semibold">Değişim</th>
                          <th className="text-left p-3 font-semibold">Hacim</th>
                          <th className="text-left p-3 font-semibold">AI Skoru</th>
                          <th className="text-left p-3 font-semibold">Olaylar</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dailyTrends
                          .slice(-10)
                          .reverse()
                          .map((trend, index) => (
                            <tr key={index} className="border-b hover:bg-gray-50">
                              <td className="p-3 font-medium">{trend.date}</td>
                              <td className="p-3">{formatPrice(trend.openPrice)}</td>
                              <td className="p-3">{formatPrice(trend.closePrice)}</td>
                              <td className="p-3 text-green-600">{formatPrice(trend.highPrice)}</td>
                              <td className="p-3 text-red-600">{formatPrice(trend.lowPrice)}</td>
                              <td className="p-3">
                                <span className={`font-medium ${getChangeColor(trend.change)}`}>
                                  {trend.change >= 0 ? "+" : ""}
                                  {trend.change.toFixed(2)}%
                                </span>
                              </td>
                              <td className="p-3">${formatLargeNumber(trend.volume)}</td>
                              <td className="p-3">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{trend.aiScore}</span>
                                  <div className="w-12">
                                    <Progress value={trend.aiScore} className="h-1" />
                                  </div>
                                </div>
                              </td>
                              <td className="p-3">
                                <div className="space-y-1">
                                  {trend.events.map((event, eventIndex) => (
                                    <Badge key={eventIndex} variant="outline" className="text-xs">
                                      {event}
                                    </Badge>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Henüz günlük trend verisi bulunmuyor.</p>
                  <p className="text-sm text-gray-400">Canlı veri akışını başlatın.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="yearly-data" className="space-y-6">
          {/* Yıllık Veriler */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-5 w-5 text-orange-600" />
                {selectedSymbol} Yıllık Performans Verileri
              </CardTitle>
              <CardDescription>Her yıl otomatik olarak güncellenen performans metrikleri</CardDescription>
            </CardHeader>
            <CardContent>
              {liveData.find((d) => d.symbol === selectedSymbol)?.yearlyData && (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-semibold">Yıl</th>
                        <th className="text-left p-3 font-semibold">Başlangıç</th>
                        <th className="text-left p-3 font-semibold">Bitiş</th>
                        <th className="text-left p-3 font-semibold">En Yüksek</th>
                        <th className="text-left p-3 font-semibold">En Düşük</th>
                        <th className="text-left p-3 font-semibold">Toplam Getiri</th>
                        <th className="text-left p-3 font-semibold">Volatilite</th>
                        <th className="text-left p-3 font-semibold">En İyi Ay</th>
                        <th className="text-left p-3 font-semibold">En Kötü Ay</th>
                      </tr>
                    </thead>
                    <tbody>
                      {liveData
                        .find((d) => d.symbol === selectedSymbol)
                        ?.yearlyData.map((yearData, index) => (
                          <tr key={index} className="border-b hover:bg-gray-50">
                            <td className="p-3 font-medium">{yearData.year}</td>
                            <td className="p-3">{formatPrice(yearData.startPrice)}</td>
                            <td className="p-3">{formatPrice(yearData.endPrice)}</td>
                            <td className="p-3 text-green-600">{formatPrice(yearData.highPrice)}</td>
                            <td className="p-3 text-red-600">{formatPrice(yearData.lowPrice)}</td>
                            <td className="p-3">
                              <span className={`font-medium ${getChangeColor(yearData.totalReturn)}`}>
                                {yearData.totalReturn >= 0 ? "+" : ""}
                                {yearData.totalReturn.toFixed(1)}%
                              </span>
                            </td>
                            <td className="p-3">{yearData.volatility.toFixed(1)}%</td>
                            <td className="p-3 text-green-600">{yearData.bestMonth}</td>
                            <td className="p-3 text-red-600">{yearData.worstMonth}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Sistem Durumu */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-green-600" />
            AI Sistem Durumu
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <div
                className={`w-4 h-4 rounded-full mx-auto mb-2 ${isLiveMode ? "bg-green-500 animate-pulse" : "bg-gray-400"}`}
              ></div>
              <p className="font-medium">{isLiveMode ? "Aktif" : "Pasif"}</p>
              <p className="text-sm text-gray-600">Canlı Veri</p>
            </div>
            <div className="text-center">
              <div className="w-4 h-4 rounded-full bg-blue-500 mx-auto mb-2 animate-pulse"></div>
              <p className="font-medium">Çalışıyor</p>
              <p className="text-sm text-gray-600">AI Analizi</p>
            </div>
            <div className="text-center">
              <div className="w-4 h-4 rounded-full bg-purple-500 mx-auto mb-2 animate-pulse"></div>
              <p className="font-medium">Güncel</p>
              <p className="text-sm text-gray-600">Trend Takibi</p>
            </div>
            <div className="text-center">
              <div className="w-4 h-4 rounded-full bg-orange-500 mx-auto mb-2 animate-pulse"></div>
              <p className="font-medium">Hazır</p>
              <p className="text-sm text-gray-600">Yıllık Güncelleme</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
