"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Brain,
  Clock,
  DollarSign,
  CheckCircle,
  Star,
  Target,
  BookOpen,
  TrendingUp,
  Zap,
  MessageSquare,
} from "lucide-react"

interface UserProfile {
  availableHours: number
  hasPhone: boolean
  hasComputer: boolean
  usesSocialMedia: boolean
  platforms: string[]
  experience: string
  goals: string
}

interface Task {
  id: string
  title: string
  description: string
  estimatedTime: number
  difficulty: "kolay" | "orta" | "zor"
  potentialEarning: string
  category: string
  completed: boolean
  steps: string[]
  ceoAdvice?: string
}

interface AIAdvice {
  id: string
  message: string
  type: "motivation" | "strategy" | "warning" | "celebration"
  timestamp: string
}

export default function EnhancedMoneyAIAssistant() {
  const [currentView, setCurrentView] = useState<
    "welcome" | "questions" | "dashboard" | "tasks" | "courses" | "profile"
  >("welcome")
  const [questionStep, setQuestionStep] = useState(0)
  const [userProfile, setUserProfile] = useState<UserProfile>({
    availableHours: 0,
    hasPhone: false,
    hasComputer: false,
    usesSocialMedia: false,
    platforms: [],
    experience: "",
    goals: "",
  })
  const [dailyTasks, setDailyTasks] = useState<Task[]>([])
  const [completedTasks, setCompletedTasks] = useState<string[]>([])
  const [dailyGoal] = useState(25) // TL
  const [currentEarnings, setCurrentEarnings] = useState(0)
  const [aiAdviceHistory, setAiAdviceHistory] = useState<AIAdvice[]>([])
  const [userQuestion, setUserQuestion] = useState("")

  const questions = [
    {
      question: "Bugün kaç saatin boş?",
      type: "hours",
      options: ["1 saat", "2-3 saat", "4-6 saat", "6+ saat"],
    },
    {
      question: "Hangi cihazların var?",
      type: "devices",
      options: ["Sadece telefon", "Sadece bilgisayar", "Her ikisi de", "Hiçbiri"],
    },
    {
      question: "Sosyal medyayı aktif kullanıyor musun?",
      type: "social",
      options: ["Evet, çok aktifim", "Bazen kullanırım", "Nadiren", "Hiç kullanmam"],
    },
    {
      question: "Hangi platformları biliyorsun?",
      type: "platforms",
      options: ["Instagram", "TikTok", "YouTube", "Canva", "Hiçbiri"],
    },
    {
      question: "Online para kazanma deneyimin nasıl?",
      type: "experience",
      options: ["Hiç deneyimim yok", "Biraz denedim", "Orta seviye", "Deneyimliyim"],
    },
  ]

  // Enhanced AI with CEO personality
  const generateCEOTaskAdvice = (task: Task, userProfile: UserProfile): string => {
    const adviceTemplates = {
      "tiktok-video": `**CEO Tavsiyesi:** TikTok'ta viral olmak için 3 altın kural var:

1. **İlk 3 saniye kritik** - Hemen dikkat çekin
2. **Trend'leri takip edin** - Ama kendi tarzınızı katın  
3. **Tutarlı olun** - Günde 1 video, ayda 30 video = büyük fark

**Strateji:** ${userProfile.availableHours} saatiniz var, bu mükemmel! 30 dakikada kaliteli içerik üretebilirsiniz. Başarı = Kalite × Tutarlılık.`,

      "fiverr-gig": `**CEO Perspektifi:** Fiverr'da başarı, **doğru positioning** ile gelir.

**Analiz:** Deneyim seviyeniz "${userProfile.experience}" - bu gerçekçi fiyatlandırma yapmanızı sağlar.

**Strateji:**
- İlk 5 siparişi düşük fiyatla alın (review için)
- Sonra fiyatları kademeli artırın
- Uzmanlık alanınızı daraltın, genel olmayın

**CEO Sırrı:** "Herkes için her şey" olmaya çalışan, "kimse için hiçbir şey" olur.`,

      "canva-design": `**Tasarım CEO'su Yaklaşımı:** Canva ile para kazanmak, **sistem kurma** işidir.

**Verimlilik Stratejisi:**
- Şablon kütüphanesi oluşturun
- Renk paletlerinizi standartlaştırın  
- Batch processing yapın (5 tasarım birden)

**Pazar Analizi:** Sosyal medya tasarımı ${userProfile.usesSocialMedia ? "avantajınız" : "öğrenme fırsatınız"}. ${userProfile.availableHours} saatte 5-10 tasarım yapabilirsiniz.`,
    }

    return (
      adviceTemplates[task.id as keyof typeof adviceTemplates] ||
      `**CEO Tavsiyesi:** Bu görevi tamamlarken, **kalite ve hız** dengesini koruyun. Hedef: maksimum verimlilik, minimum zaman kaybı.`
    )
  }

  const generateAIAdvice = (context: string): AIAdvice => {
    const adviceTypes = {
      task_completed: {
        type: "celebration" as const,
        messages: [
          "Mükemmel! Bir CEO gibi hareket ediyorsunuz. Tutarlılık başarının anahtarıdır! 🎉",
          "Harika iş! Bu momentum'u koruyun. Büyük başarılar küçük adımlarla gelir. 💪",
          "Tebrikler! Disiplinli yaklaşımınız gerçek bir girişimci ruhu gösteriyor. 🚀",
        ],
      },
      daily_goal_reached: {
        type: "celebration" as const,
        messages: [
          "WOW! Günlük hedefinize ulaştınız! Bu performans, Fortune 500 CEO'larını andırıyor! 🏆",
          "İnanılmaz! Hedef odaklı yaklaşımınız mükemmel. Yarın için yeni hedefler belirleyelim! ⭐",
          "Başarı! Bu kararlılık sizi çok uzaklara götürecek. Devam edin! 🎯",
        ],
      },
      motivation_needed: {
        type: "motivation" as const,
        messages: [
          "Her büyük CEO zor günler yaşar. Önemli olan devam etmek. Siz yapabilirsiniz! 💪",
          "Başarı yolunda engeller normal. Bu zorluklar sizi daha güçlü yapacak. İlerleyin! 🚀",
          "Motivasyon geçici, disiplin kalıcıdır. Bugün küçük bir adım atın yeter. 🎯",
        ],
      },
      strategy_advice: {
        type: "strategy" as const,
        messages: [
          "Strateji güncellemesi: Mevcut performansınızı analiz edin ve sonraki adımları planlayın. 📊",
          "CEO tavsiyesi: Çeşitlendirme zamanı. Farklı gelir kanallarını değerlendirin. 💡",
          "Büyüme stratejisi: Başarılı görevlerinizi tekrarlayın, verimsizleri optimize edin. 📈",
        ],
      },
    }

    const contextType = context.includes("completed")
      ? "task_completed"
      : context.includes("goal")
        ? "daily_goal_reached"
        : context.includes("motivation")
          ? "motivation_needed"
          : "strategy_advice"

    const selectedType = adviceTypes[contextType]
    const randomMessage = selectedType.messages[Math.floor(Math.random() * selectedType.messages.length)]

    return {
      id: Date.now().toString(),
      message: randomMessage,
      type: selectedType.type,
      timestamp: new Date().toLocaleString("tr-TR"),
    }
  }

  const handleQuestionAnswer = (answer: string) => {
    const currentQuestion = questions[questionStep]
    const newProfile = { ...userProfile }

    switch (currentQuestion.type) {
      case "hours":
        newProfile.availableHours = answer.includes("1 saat")
          ? 1
          : answer.includes("2-3")
            ? 2.5
            : answer.includes("4-6")
              ? 5
              : 8
        break
      case "devices":
        newProfile.hasPhone = answer.includes("telefon") || answer.includes("Her ikisi")
        newProfile.hasComputer = answer.includes("bilgisayar") || answer.includes("Her ikisi")
        break
      case "social":
        newProfile.usesSocialMedia = !answer.includes("Hiç")
        break
      case "platforms":
        if (!newProfile.platforms.includes(answer)) {
          newProfile.platforms.push(answer)
        }
        break
      case "experience":
        newProfile.experience = answer
        break
    }

    setUserProfile(newProfile)

    if (questionStep < questions.length - 1) {
      setQuestionStep(questionStep + 1)
    } else {
      // Generate tasks with CEO advice
      const tasks = generateTasksWithCEOAdvice(newProfile)
      setDailyTasks(tasks)

      // Welcome advice
      const welcomeAdvice = generateAIAdvice("welcome")
      setAiAdviceHistory([welcomeAdvice])

      setCurrentView("dashboard")
    }
  }

  const generateTasksWithCEOAdvice = (profile: UserProfile): Task[] => {
    const baseTasks = generateTasks(profile)

    return baseTasks.map((task) => ({
      ...task,
      ceoAdvice: generateCEOTaskAdvice(task, profile),
    }))
  }

  const generateTasks = (profile: UserProfile): Task[] => {
    const tasks: Task[] = []

    if (profile.hasPhone && profile.usesSocialMedia) {
      tasks.push({
        id: "tiktok-video",
        title: "TikTok Trend Video Çek",
        description: "Güncel trend ses kullanarak 15-30 saniyelik video çek ve paylaş",
        estimatedTime: 30,
        difficulty: "kolay",
        potentialEarning: "5-15 TL",
        category: "Sosyal Medya",
        completed: false,
        steps: [
          "TikTok'ta trend sesleri keşfet",
          "Yaratıcı bir konsept düşün",
          "Video çek (15-30 saniye)",
          "Trend hashtag'ler ekle",
          "Paylaş ve etkileşim bekle",
        ],
      })
    }

    if (profile.hasComputer) {
      tasks.push({
        id: "fiverr-gig",
        title: "Fiverr'da Hizmet Teklifi",
        description: "Fiverr'da yeni bir gig oluştur veya mevcut profilini güncelle",
        estimatedTime: 60,
        difficulty: "orta",
        potentialEarning: "50-200 TL",
        category: "Freelance",
        completed: false,
        steps: [
          "Fiverr hesabını kontrol et",
          "Yeteneklerini analiz et",
          "Yeni gig oluştur",
          "Çekici başlık ve açıklama yaz",
          "Portföy örnekleri ekle",
        ],
      })

      tasks.push({
        id: "canva-design",
        title: "Canva ile Tasarım Yap",
        description: "Sosyal medya için 5 farklı tasarım oluştur",
        estimatedTime: 45,
        difficulty: "kolay",
        potentialEarning: "10-25 TL",
        category: "Tasarım",
        completed: false,
        steps: [
          "Canva'ya giriş yap",
          "Instagram post şablonu seç",
          "5 farklı tasarım oluştur",
          "Yüksek kalitede indir",
          "Sosyal medyada paylaş",
        ],
      })
    }

    return tasks.slice(0, 3)
  }

  const completeTask = (taskId: string) => {
    if (!completedTasks.includes(taskId)) {
      setCompletedTasks([...completedTasks, taskId])
      const task = dailyTasks.find((t) => t.id === taskId)
      if (task) {
        const earning = Math.floor(Math.random() * 10) + 5
        setCurrentEarnings(currentEarnings + earning)

        // Generate celebration advice
        const celebrationAdvice = generateAIAdvice("task_completed")
        setAiAdviceHistory([celebrationAdvice, ...aiAdviceHistory])

        // Check if daily goal reached
        if (currentEarnings + earning >= dailyGoal) {
          const goalAdvice = generateAIAdvice("daily_goal_reached")
          setAiAdviceHistory([goalAdvice, ...aiAdviceHistory])
        }
      }
    }
  }

  const handleAIQuestion = () => {
    if (!userQuestion.trim()) return

    // Generate contextual advice based on user question
    const advice = generateAIAdvice(userQuestion)
    setAiAdviceHistory([advice, ...aiAdviceHistory])
    setUserQuestion("")
  }

  if (currentView === "welcome") {
    return (
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        <Card className="text-center bg-gradient-to-br from-green-50 to-blue-50">
          <CardHeader>
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Brain className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-gray-900">CEO AI Para Kazanma Asistanı</CardTitle>
            <CardDescription className="text-lg">
              Sıfır sermaye ile günlük para kazanmanın yollarını CEO perspektifiyle öğren
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4">
                <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <h3 className="font-semibold">CEO Stratejileri</h3>
                <p className="text-sm text-gray-600">Profesyonel iş yaklaşımları</p>
              </div>
              <div className="text-center p-4">
                <BookOpen className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <h3 className="font-semibold">Akıllı Görevler</h3>
                <p className="text-sm text-gray-600">AI destekli kişisel öneriler</p>
              </div>
              <div className="text-center p-4">
                <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold">Sürekli Koçluk</h3>
                <p className="text-sm text-gray-600">7/24 motivasyon ve rehberlik</p>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Star className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-yellow-800">Bugünkü CEO Hedefin</span>
              </div>
              <p className="text-2xl font-bold text-yellow-800">{dailyGoal} TL kazanmak</p>
              <p className="text-sm text-yellow-700">Stratejik yaklaşımla başlayalım! 🚀</p>
            </div>

            <Button
              onClick={() => setCurrentView("questions")}
              size="lg"
              className="w-full bg-green-600 hover:bg-green-700"
            >
              CEO Asistanını Başlat! 🎯
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (currentView === "dashboard") {
    const completionRate = (completedTasks.length / dailyTasks.length) * 100

    return (
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* AI Advice Section */}
        {aiAdviceHistory.length > 0 && (
          <Card className="border-l-4 border-l-blue-600 bg-gradient-to-r from-blue-50 to-purple-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Avatar className="w-10 h-10 bg-blue-600">
                  <AvatarFallback className="text-white text-sm font-bold">AI</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge
                      className={
                        aiAdviceHistory[0].type === "celebration"
                          ? "bg-green-100 text-green-800"
                          : aiAdviceHistory[0].type === "motivation"
                            ? "bg-yellow-100 text-yellow-800"
                            : aiAdviceHistory[0].type === "strategy"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-gray-100 text-gray-800"
                      }
                    >
                      {aiAdviceHistory[0].type === "celebration"
                        ? "🎉 Tebrik"
                        : aiAdviceHistory[0].type === "motivation"
                          ? "💪 Motivasyon"
                          : aiAdviceHistory[0].type === "strategy"
                            ? "📊 Strateji"
                            : "💡 Tavsiye"}
                    </Badge>
                    <span className="text-xs text-gray-500">{aiAdviceHistory[0].timestamp}</span>
                  </div>
                  <p className="text-gray-700 font-medium">{aiAdviceHistory[0].message}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ask AI Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              CEO AI'ya Soru Sor
            </CardTitle>
            <CardDescription>Motivasyon, strateji, görev optimizasyonu - her konuda danışabilirsiniz</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={userQuestion}
              onChange={(e) => setUserQuestion(e.target.value)}
              placeholder="Örnek: Motivasyonum düştü, ne yapmalıyım? Görevlerimi nasıl optimize edebilirim?"
              rows={2}
            />
            <Button
              onClick={handleAIQuestion}
              disabled={!userQuestion.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Brain className="h-4 w-4 mr-2" />
              AI Tavsiyesi Al
            </Button>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600">Bugünkü Kazanç</p>
                  <p className="text-xl font-bold text-green-600">{currentEarnings} TL</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">CEO Hedefi</p>
                  <p className="text-xl font-bold text-blue-600">{dailyGoal} TL</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Tamamlanan</p>
                  <p className="text-xl font-bold text-purple-600">
                    {completedTasks.length}/{dailyTasks.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm text-gray-600">Boş Zaman</p>
                  <p className="text-xl font-bold text-orange-600">{userProfile.availableHours}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Daily Tasks with CEO Advice */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-blue-600" />
              CEO Onaylı Günlük Görevler
            </CardTitle>
            <CardDescription>Stratejik yaklaşımla hazırlanmış kişisel görevleriniz</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6">
              {dailyTasks.map((task) => (
                <div
                  key={task.id}
                  className={`border rounded-lg p-4 ${completedTasks.includes(task.id) ? "bg-green-50 border-green-200" : ""}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold">{task.title}</h3>
                        <Badge
                          variant={
                            task.difficulty === "kolay"
                              ? "default"
                              : task.difficulty === "orta"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {task.difficulty}
                        </Badge>
                        <Badge variant="outline">{task.category}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {task.estimatedTime} dk
                        </span>
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-3 w-3" />
                          {task.potentialEarning}
                        </span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={completedTasks.includes(task.id) ? "default" : "outline"}
                      onClick={() => completeTask(task.id)}
                      disabled={completedTasks.includes(task.id)}
                    >
                      {completedTasks.includes(task.id) ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Tamamlandı
                        </>
                      ) : (
                        "Başla"
                      )}
                    </Button>
                  </div>

                  {/* CEO Advice for Task */}
                  {task.ceoAdvice && (
                    <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Avatar className="w-6 h-6 bg-blue-600">
                          <AvatarFallback className="text-white text-xs">CEO</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-semibold text-blue-800">CEO Stratejik Tavsiyesi:</span>
                      </div>
                      <div className="text-sm text-blue-700 whitespace-pre-line">{task.ceoAdvice}</div>
                    </div>
                  )}

                  {/* Task Steps */}
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-sm font-medium mb-2">Adım Adım Rehber:</p>
                    <ol className="text-sm text-gray-600 space-y-1">
                      {task.steps.map((step, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-blue-600 font-medium">{index + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AI Advice History */}
        {aiAdviceHistory.length > 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-600" />
                AI Danışmanlık Geçmişi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {aiAdviceHistory.slice(1).map((advice) => (
                  <div key={advice.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <Avatar className="w-8 h-8 bg-purple-600">
                      <AvatarFallback className="text-white text-xs">AI</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs">
                          {advice.type === "celebration"
                            ? "🎉"
                            : advice.type === "motivation"
                              ? "💪"
                              : advice.type === "strategy"
                                ? "📊"
                                : "💡"}
                        </Badge>
                        <span className="text-xs text-gray-500">{advice.timestamp}</span>
                      </div>
                      <p className="text-sm text-gray-700">{advice.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    )
  }

  // Return other views (questions, courses, profile) - keeping original logic
  if (currentView === "questions") {
    const currentQuestion = questions[questionStep]

    return (
      <div className="max-w-2xl mx-auto p-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline">
                {questionStep + 1} / {questions.length}
              </Badge>
              <Progress value={((questionStep + 1) / questions.length) * 100} className="w-32" />
            </div>
            <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
            <CardDescription>CEO AI'nız size en uygun stratejileri belirlemek için birkaç soru soracak</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="justify-start h-auto p-4 text-left bg-transparent"
                  onClick={() => handleQuestionAnswer(option)}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return null
}
