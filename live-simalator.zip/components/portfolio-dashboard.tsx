"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, TrendingDown, RefreshCw, Brain, AlertTriangle, CheckCircle, Clock, LogOut } from "lucide-react"
import { PortfoyService } from "@/lib/portfolio-service"
import type { YatirimEnstrumani, PortfoyOzeti, AIAnalizi, GrafikVerisi } from "@/lib/portfolio-types"
import { AuthService } from "@/lib/auth"

interface PortfolioDashboardProps {
  user: any
  onLogout: () => void
}

export function PortfolioDashboard({ user, onLogout }: PortfolioDashboardProps) {
  const [varliklar, setVarliklar] = useState<YatirimEnstrumani[]>([])
  const [ozet, setOzet] = useState<PortfoyOzeti | null>(null)
  const [aiAnalizleri, setAiAnalizleri] = useState<AIAnalizi[]>([])
  const [grafikVerileri, setGrafikVerileri] = useState<GrafikVerisi[]>([])
  const [loading, setLoading] = useState(true)
  const [sonGuncelleme, setSonGuncelleme] = useState<Date>(new Date())

  const loadData = async () => {
    try {
      const [varliklarData, ozetData, aiData, grafikData] = await Promise.all([
        PortfoyService.getPortfoyVerileri(user.id),
        PortfoyService.getPortfoyOzeti(user.id),
        PortfoyService.getAIAnalizleri(user.id),
        PortfoyService.getGrafikVerileri(user.id),
      ])

      setVarliklar(varliklarData)
      setOzet(ozetData)
      setAiAnalizleri(aiData)
      setGrafikVerileri(grafikData)
      setSonGuncelleme(new Date())
    } catch (error) {
      console.error("Veri yükleme hatası:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()

    // Her 5 dakikada bir otomatik güncelleme
    const interval = setInterval(loadData, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [user.id])

  const handleLogout = () => {
    AuthService.logout()
    onLogout()
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "TRY",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatPercent = (percent: number) => {
    return `${percent >= 0 ? "+" : ""}${percent.toFixed(2)}%`
  }

  const getKategoriRengi = (kategori: string) => {
    const renkler = {
      kripto: "#f59e0b",
      altin: "#eab308",
      borsa: "#3b82f6",
      doviz: "#10b981",
      emtia: "#8b5cf6",
    }
    return renkler[kategori as keyof typeof renkler] || "#6b7280"
  }

  const getOneriRengi = (oneri: string) => {
    const renkler = {
      al: "bg-green-500",
      sat: "bg-red-500",
      bekle: "bg-yellow-500",
      artir: "bg-blue-500",
      azalt: "bg-orange-500",
    }
    return renkler[oneri as keyof typeof renkler] || "bg-gray-500"
  }

  const getOneriMetni = (oneri: string) => {
    const metinler = {
      al: "ALIN",
      sat: "SATIN",
      bekle: "BEKLEYİN",
      artir: "ARTIRIN",
      azalt: "AZALTIN",
    }
    return metinler[oneri as keyof typeof metinler] || oneri.toUpperCase()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-500 mx-auto mb-4" />
          <p className="text-white">Portföy verileri yükleniyor...</p>
        </div>
      </div>
    )
  }

  const pieData = varliklar.map((v) => ({
    name: v.ad,
    value: v.guncelDeger,
    color: getKategoriRengi(v.kategori),
  }))

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <TrendingUp className="h-8 w-8 text-green-400" />
            <div>
              <h1 className="text-2xl font-bold">Portföyüm</h1>
              <p className="text-gray-400">Hoş geldin, {user.name}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right text-sm text-gray-400">
              <p>Son Güncelleme</p>
              <p>{sonGuncelleme.toLocaleTimeString("tr-TR")}</p>
            </div>
            <Button
              onClick={loadData}
              variant="outline"
              size="sm"
              className="border-slate-600 text-white hover:bg-slate-700 bg-transparent"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Yenile
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white bg-transparent"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Çıkış
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Portföy Özeti */}
        {ozet && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Toplam Yatırım</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{formatCurrency(ozet.toplamYatirim)}</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Güncel Değer</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{formatCurrency(ozet.guncelDeger)}</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Toplam Kar/Zarar</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold flex items-center ${
                    ozet.toplamKarZarar >= 0 ? "text-green-400" : "text-red-400"
                  }`}
                >
                  {ozet.toplamKarZarar >= 0 ? (
                    <TrendingUp className="h-5 w-5 mr-2" />
                  ) : (
                    <TrendingDown className="h-5 w-5 mr-2" />
                  )}
                  {formatCurrency(ozet.toplamKarZarar)}
                </div>
                <p className={`text-sm ${ozet.toplamKarZararYuzde >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {formatPercent(ozet.toplamKarZararYuzde)}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Günlük Değişim</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold flex items-center ${
                    ozet.gunlukDegisim >= 0 ? "text-green-400" : "text-red-400"
                  }`}
                >
                  {ozet.gunlukDegisim >= 0 ? (
                    <TrendingUp className="h-5 w-5 mr-2" />
                  ) : (
                    <TrendingDown className="h-5 w-5 mr-2" />
                  )}
                  {formatPercent(ozet.gunlukDegisim)}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Portföy Grafiği */}
          <Card className="lg:col-span-2 bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Portföy Performansı (30 Gün)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={grafikVerileri}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis
                    dataKey="tarih"
                    stroke="#9ca3af"
                    fontSize={12}
                    tickFormatter={(value) =>
                      new Date(value).toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit" })
                    }
                  />
                  <YAxis stroke="#9ca3af" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1f2937",
                      border: "1px solid #374151",
                      borderRadius: "8px",
                      color: "#fff",
                    }}
                    formatter={(value: any) => [formatCurrency(value), "Değer"]}
                    labelFormatter={(label) => new Date(label).toLocaleDateString("tr-TR")}
                  />
                  <Line type="monotone" dataKey="deger" stroke="#10b981" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Varlık Dağılımı */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Varlık Dağılımı</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1f2937",
                      border: "1px solid #374151",
                      borderRadius: "8px",
                      color: "#fff",
                    }}
                    formatter={(value: any) => [formatCurrency(value), "Değer"]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {pieData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }} />
                      <span className="text-gray-300">{item.name}</span>
                    </div>
                    <span className="text-white font-medium">
                      {((item.value / ozet!.guncelDeger) * 100).toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Analizleri */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Brain className="h-5 w-5 mr-2 text-purple-400" />
              AI Analiz ve Önerileri
            </CardTitle>
            <CardDescription className="text-gray-400">
              Yapay zeka asistanınızın portföyünüz için önerileri
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {aiAnalizleri.map((analiz) => (
                <div key={analiz.id} className="bg-slate-700 rounded-lg p-4 border border-slate-600">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-white mb-1">{analiz.baslik}</h3>
                      <p className="text-gray-300 text-sm leading-relaxed">{analiz.aciklama}</p>
                    </div>
                    <div className="flex flex-col items-end space-y-2 ml-4">
                      <Badge className={`${getOneriRengi(analiz.oneri)} text-white font-medium`}>
                        {getOneriMetni(analiz.oneri)}
                      </Badge>
                      <div className="flex items-center text-xs text-gray-400">
                        <CheckCircle className="h-3 w-3 mr-1" />%{analiz.guvenSeviyesi} güven
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {new Date(analiz.tarih).toLocaleString("tr-TR")}
                    </div>
                    <div className="flex items-center space-x-2">
                      {analiz.oncelik === "yuksek" && <AlertTriangle className="h-3 w-3 text-red-400" />}
                      <span className="capitalize">{analiz.oncelik} öncelik</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Yatırım Enstrümanları */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Yatırım Enstrümanları</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-600">
                    <th className="text-left py-3 px-2 text-gray-400 font-medium">Varlık</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Yatırım</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Güncel Değer</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Kar/Zarar</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Günlük</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Haftalık</th>
                  </tr>
                </thead>
                <tbody>
                  {varliklar.map((varlik) => (
                    <tr key={varlik.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                      <td className="py-4 px-2">
                        <div className="flex items-center">
                          <div
                            className="w-3 h-3 rounded-full mr-3"
                            style={{ backgroundColor: getKategoriRengi(varlik.kategori) }}
                          />
                          <div>
                            <div className="font-medium text-white">{varlik.ad}</div>
                            <div className="text-sm text-gray-400">{varlik.sembol}</div>
                          </div>
                        </div>
                      </td>
                      <td className="text-right py-4 px-2 text-white">{formatCurrency(varlik.yatirimTutari)}</td>
                      <td className="text-right py-4 px-2 text-white">{formatCurrency(varlik.guncelDeger)}</td>
                      <td
                        className={`text-right py-4 px-2 ${varlik.karZarar >= 0 ? "text-green-400" : "text-red-400"}`}
                      >
                        <div>{formatCurrency(varlik.karZarar)}</div>
                        <div className="text-sm">{formatPercent(varlik.karZararYuzde)}</div>
                      </td>
                      <td
                        className={`text-right py-4 px-2 ${
                          varlik.gunlukDegisim >= 0 ? "text-green-400" : "text-red-400"
                        }`}
                      >
                        {formatPercent(varlik.gunlukDegisim)}
                      </td>
                      <td
                        className={`text-right py-4 px-2 ${
                          varlik.haftalikDegisim >= 0 ? "text-green-400" : "text-red-400"
                        }`}
                      >
                        {formatPercent(varlik.haftalikDegisim)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
