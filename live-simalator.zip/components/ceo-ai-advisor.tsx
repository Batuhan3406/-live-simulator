"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Brain,
  TrendingUp,
  Target,
  Lightbulb,
  MessageSquare,
  Star,
  Zap,
  Award,
  ChevronRight,
  Clock,
} from "lucide-react"

interface CEOAdvice {
  id: string
  question: string
  advice: string
  actionItems: string[]
  priority: "high" | "medium" | "low"
  category: "strategy" | "investment" | "income" | "leadership" | "growth"
  timestamp: string
}

interface UserContext {
  currentEarnings: number
  investmentLevel: number
  completedTasks: number
  mainChallenge: string
  goals: string[]
}

export default function CEOAIAdvisor() {
  const [isActive, setIsActive] = useState(false)
  const [userQuestion, setUserQuestion] = useState("")
  const [conversationHistory, setConversationHistory] = useState<CEOAdvice[]>([])
  const [isThinking, setIsThinking] = useState(false)
  const [userContext, setUserContext] = useState<UserContext>({
    currentEarnings: 0,
    investmentLevel: 1,
    completedTasks: 0,
    mainChallenge: "",
    goals: [],
  })

  // CEO AI Personality and Knowledge Base
  const ceoPersonality = {
    traits: [
      "Stratejik düşünce",
      "Pratik çözümler",
      "Motivasyonel liderlik",
      "Sonuç odaklılık",
      "Empati ile güçlendirme",
    ],
    expertise: [
      "İş stratejisi geliştirme",
      "Yatırım analizi",
      "Gelir diversifikasyonu",
      "Risk yönetimi",
      "Kişisel gelişim",
    ],
  }

  const generateCEOAdvice = (question: string, context: UserContext): CEOAdvice => {
    // CEO AI Logic - Simulated advanced reasoning
    const adviceTemplates = {
      investment: {
        low_earnings: {
          advice: `Merhaba! CEO perspektifinden bakıldığında, şu anda ${context.currentEarnings} TL kazancınız var. Bu başlangıç için mükemmel! 

**Stratejik Analiz:** Düşük sermaye ile başlarken, en önemli şey **risk yönetimi** ve **öğrenme hızı**. Büyük yatırımcılar da böyle başladı.

**Önerim:** Şimdilik %70'ini güvenli yatırımlarda (altın, döviz), %30'unu öğrenme amaçlı riskli yatırımlarda değerlendirin. Her kaybınız bir ders, her kazancınız bir adım olsun.

**CEO Sırrı:** Warren Buffett'ın dediği gibi, "Risk, ne yaptığınızı bilmemekten gelir." Önce öğrenin, sonra yatırım yapın.`,
          actionItems: [
            "Günlük 15 dakika piyasa analizi yapın",
            "İlk yatırımınızı maksimum 50 TL ile sınırlayın",
            "Her işlem sonrası not tutun - ne öğrendiniz?",
            "Haftalık performans değerlendirmesi yapın",
          ],
          priority: "high" as const,
          category: "investment" as const,
        },
        strategy_question: {
          advice: `Harika bir soru! Bir CEO olarak size şunu söyleyebilirim: **En iyi strateji, kendi durumunuza uygun olandır.**

**Mevcut Durumunuz:** ${context.completedTasks} görev tamamlamışsınız, bu disiplin gösteriyor. 

**Stratejik Yaklaşım:**
1. **Kısa vadeli (1-3 ay):** Günlük kazanç görevleriyle sermaye biriktirin
2. **Orta vadeli (3-12 ay):** Birikimlerinizi düşük riskli yatırımlarda değerlendirin  
3. **Uzun vadeli (1+ yıl):** Portföy çeşitlendirmesi ve pasif gelir kaynakları

**CEO Tavsiyesi:** "Acele eden CEO, şirketi batırır." Sabırlı olun, ama kararlı hareket edin.`,
          actionItems: [
            "3 aylık finansal hedef belirleyin",
            "Haftalık yatırım bütçesi oluşturun",
            "Risk toleransınızı test edin",
            "Başarı metriklerinizi tanımlayın",
          ],
          priority: "high" as const,
          category: "strategy" as const,
        },
      },
      income: {
        task_optimization: {
          advice: `Mükemmel! Görev optimizasyonu konusunda konuşalım. Bir CEO olarak, **verimlilik** benim en büyük tutkum.

**Analiz:** ${context.completedTasks} görev tamamlamışsınız. Bu iyi bir başlangıç, ama **sistematik yaklaşım** ile 3x daha verimli olabilirsiniz.

**CEO Stratejisi:**
- **80/20 Kuralı:** Zamanınızın %20'si, kazancınızın %80'ini getirmeli
- **Batch Processing:** Benzer görevleri gruplandırın
- **Automation:** Tekrarlayan işleri otomatikleştirin

**Gerçek Hayat Örneği:** Apple'da Steve Jobs, günde sadece 3 önemli karara odaklanırdı. Siz de günde 3 yüksek değerli göreve odaklanın.`,
          actionItems: [
            "En karlı 3 görev türünü belirleyin",
            "Günlük rutin oluşturun (sabah-öğlen-akşam)",
            "Zaman takip uygulaması kullanın",
            "Haftalık verimlilik analizi yapın",
          ],
          priority: "medium" as const,
          category: "income" as const,
        },
      },
      motivation: {
        encouragement: {
          advice: `Dinleyin, başarılı CEO'ların ortak özelliği nedir biliyor musunuz? **Zorluklarla karşılaştıklarında pes etmezler.**

**Sizin Durumunuz:** Şu ana kadar gösterdiğiniz performans, gerçek bir girişimci ruhu gösteriyor. ${context.currentEarnings} TL kazanç ve ${context.completedTasks} tamamlanan görev - bu rakamlar tesadüf değil, **kararlılığınızın** sonucu.

**CEO Perspektifi:** Her büyük şirket, küçük adımlarla başladı. Amazon, Jeff Bezos'un garajında başladı. Siz de kendi "garajınızda" çalışıyorsunuz.

**Motivasyon Formülü:** Başarı = (Küçük Adımlar × Tutarlılık) × Zaman

Devam edin, doğru yoldasınız! 🚀`,
          actionItems: [
            "Günlük başarılarınızı kaydedin",
            "Haftalık ilerleme fotoğrafı çekin",
            "Bir başarı hikayenizi paylaşın",
            "Sonraki hedefi belirleyin",
          ],
          priority: "medium" as const,
          category: "leadership" as const,
        },
      },
    }

    // Simple AI logic to determine response type
    const questionLower = question.toLowerCase()
    let selectedAdvice

    if (questionLower.includes("yatırım") || questionLower.includes("invest")) {
      selectedAdvice =
        context.currentEarnings < 100
          ? adviceTemplates.investment.low_earnings
          : adviceTemplates.investment.strategy_question
    } else if (questionLower.includes("görev") || questionLower.includes("task") || questionLower.includes("verim")) {
      selectedAdvice = adviceTemplates.income.task_optimization
    } else {
      selectedAdvice = adviceTemplates.motivation.encouragement
    }

    return {
      id: Date.now().toString(),
      question,
      advice: selectedAdvice.advice,
      actionItems: selectedAdvice.actionItems,
      priority: selectedAdvice.priority,
      category: selectedAdvice.category,
      timestamp: new Date().toLocaleString("tr-TR"),
    }
  }

  const handleAskCEO = async () => {
    if (!userQuestion.trim()) return

    setIsThinking(true)

    // Simulate AI thinking time
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const advice = generateCEOAdvice(userQuestion, userContext)
    setConversationHistory([advice, ...conversationHistory])
    setUserQuestion("")
    setIsThinking(false)
  }

  const quickQuestions = [
    "Yatırım stratejim nasıl olmalı?",
    "Görevlerimi nasıl optimize edebilirim?",
    "Risk yönetimi nasıl yapılır?",
    "Motivasyonum düştü, ne yapmalıyım?",
    "Uzun vadeli hedeflerimi nasıl belirlerim?",
  ]

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "strategy":
        return <Target className="h-4 w-4" />
      case "investment":
        return <TrendingUp className="h-4 w-4" />
      case "income":
        return <Zap className="h-4 w-4" />
      case "leadership":
        return <Award className="h-4 w-4" />
      default:
        return <Lightbulb className="h-4 w-4" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  if (!isActive) {
    return (
      <Card className="border-2 border-dashed border-blue-200 bg-gradient-to-br from-blue-50 to-purple-50">
        <CardContent className="p-6 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="h-8 w-8 text-blue-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">CEO AI Danışmanı</h3>
          <p className="text-gray-600 mb-4">20+ yıl deneyimli sanal CEO'nuzdan stratejik tavsiye alın</p>
          <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
            <div className="flex items-center gap-2 text-gray-600">
              <Star className="h-3 w-3 text-yellow-500" />
              Stratejik Planlama
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <TrendingUp className="h-3 w-3 text-green-500" />
              Yatırım Analizi
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <Target className="h-3 w-3 text-blue-500" />
              Hedef Belirleme
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <Award className="h-3 w-3 text-purple-500" />
              Liderlik Koçluğu
            </div>
          </div>
          <Button onClick={() => setIsActive(true)} className="bg-blue-600 hover:bg-blue-700">
            <MessageSquare className="h-4 w-4 mr-2" />
            CEO Danışmanını Aktifleştir
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* CEO Introduction */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 bg-white/20">
              <AvatarFallback className="text-white text-xl font-bold">CEO</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-2xl font-bold">Sanal CEO Danışmanınız</h2>
              <p className="text-blue-100">
                Merhaba! Ben sizin kişisel CEO danışmanınızım. Stratejik düşünce, pratik çözümler ve motivasyonel
                liderlik konularında size rehberlik edeceğim.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Questions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-600" />
            Hızlı Sorular
          </CardTitle>
          <CardDescription>Popüler CEO danışmanlık konuları</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            {quickQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start h-auto p-3 text-left bg-transparent"
                onClick={() => setUserQuestion(question)}
              >
                <ChevronRight className="h-4 w-4 mr-2 text-blue-600" />
                {question}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Ask CEO */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-blue-600" />
            CEO'ya Sorun
          </CardTitle>
          <CardDescription>İş stratejisi, yatırım kararları, motivasyon - her konuda danışabilirsiniz</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={userQuestion}
            onChange={(e) => setUserQuestion(e.target.value)}
            placeholder="Örnek: Yatırım stratejim nasıl olmalı? Risk yönetimi konusunda tavsiyeniz nedir?"
            rows={3}
          />
          <Button
            onClick={handleAskCEO}
            disabled={!userQuestion.trim() || isThinking}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isThinking ? (
              <>
                <Clock className="h-4 w-4 mr-2 animate-spin" />
                CEO Düşünüyor...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4 mr-2" />
                CEO Tavsiyesi Al
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-blue-600" />
            CEO Danışmanlık Geçmişi
          </h3>

          {conversationHistory.map((advice) => (
            <Card key={advice.id} className="border-l-4 border-l-blue-600">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getCategoryIcon(advice.category)}
                      <Badge className={getPriorityColor(advice.priority)}>
                        {advice.priority === "high"
                          ? "Yüksek Öncelik"
                          : advice.priority === "medium"
                            ? "Orta Öncelik"
                            : "Düşük Öncelik"}
                      </Badge>
                      <span className="text-sm text-gray-500">{advice.timestamp}</span>
                    </div>
                    <CardTitle className="text-lg text-blue-800">"Soru: {advice.question}"</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Avatar className="w-8 h-8 bg-blue-600">
                      <AvatarFallback className="text-white text-sm">CEO</AvatarFallback>
                    </Avatar>
                    <span className="font-semibold text-blue-800">CEO Tavsiyesi:</span>
                  </div>
                  <div className="text-gray-700 whitespace-pre-line leading-relaxed">{advice.advice}</div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    Eylem Planı:
                  </h4>
                  <ul className="space-y-2">
                    {advice.actionItems.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-xs font-bold text-green-600">{index + 1}</span>
                        </div>
                        <span className="text-green-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* CEO Personality Traits */}
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-purple-600" />
            CEO Danışmanınızın Özellikleri
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 text-purple-800">Kişilik Özellikleri:</h4>
              <div className="space-y-2">
                {ceoPersonality.traits.map((trait, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                    <span className="text-sm text-gray-700">{trait}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-blue-800">Uzmanlık Alanları:</h4>
              <div className="space-y-2">
                {ceoPersonality.expertise.map((skill, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                    <span className="text-sm text-gray-700">{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
