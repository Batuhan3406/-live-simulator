"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  Play,
  AlertTriangle,
  Target,
  Calculator,
  CheckCircle,
  Youtube,
  TrendingUp,
  Zap,
  DollarSign,
} from "lucide-react"

interface FuturesLesson {
  id: string
  title: string
  content: string[]
  keyPoints: string[]
  riskLevel: "low" | "medium" | "high" | "extreme"
  difficulty: "beginner" | "intermediate" | "advanced" | "expert"
  practicalExample: string
  aiInsight: string
  profitPotential: string
  timeframe: string
}

interface AILearningProgress {
  videoId: string
  videoTitle: string
  channelName: string
  totalLessons: number
  completedLessons: number
  learningProgress: number
  keyConceptsLearned: string[]
  practicalSkills: string[]
  riskAwareness: number
  profitStrategies: string[]
  advancedTechniques: string[]
}

export default function FuturesAILearning() {
  const [learningProgress, setLearningProgress] = useState<AILearningProgress>({
    videoId: "QUjXwG7BmFE",
    videoTitle: "How To Use Binance Futures How I made my money x2 in 1 Week. Binance Futures Training.",
    channelName: "Coin Engineer",
    totalLessons: 12,
    completedLessons: 0,
    learningProgress: 0,
    keyConceptsLearned: [],
    practicalSkills: [],
    riskAwareness: 0,
    profitStrategies: [],
    advancedTechniques: [],
  })

  const [currentLesson, setCurrentLesson] = useState(0)
  const [isLearning, setIsLearning] = useState(false)
  const [aiQuestions, setAiQuestions] = useState<string[]>([])
  const [profitSimulation, setProfitSimulation] = useState({
    initialCapital: 1000,
    currentValue: 1000,
    totalProfit: 0,
    profitPercentage: 0,
    trades: 0,
    winRate: 0,
  })

  // Yeni Gelişmiş Binance Futures Eğitim İçeriği
  const futuresLessons: FuturesLesson[] = [
    {
      id: "advanced_setup",
      title: "Gelişmiş Binance Futures Kurulumu",
      content: [
        "Binance Futures hesap optimizasyonu ve güvenlik ayarları",
        "API anahtarları ve otomatik trading hazırlığı",
        "Margin modu seçimi: Cross vs Isolated margin",
        "Position mode ayarları: Hedge vs One-way",
        "Risk yönetimi için ön ayarlar ve limitler",
        "Gelişmiş emir türleri ve koşullu emirler",
      ],
      keyPoints: [
        "Isolated margin daha güvenli, Cross margin daha esnek",
        "Hedge mode aynı anda long/short pozisyon açabilir",
        "API güvenliği için IP kısıtlaması şart",
        "Günlük/haftalık loss limitleri belirle",
      ],
      riskLevel: "medium",
      difficulty: "advanced",
      practicalExample: "1000$ sermaye ile Isolated margin, 5x max leverage, günlük %5 loss limit",
      aiInsight:
        "AI önerisi: Başlangıçta Isolated margin + One-way mode ile başlayın, deneyim kazandıkça Hedge mode'a geçin.",
      profitPotential: "Doğru kurulum ile %15-25 aylık getiri",
      timeframe: "Kurulum: 1 gün, Optimizasyon: 1 hafta",
    },
    {
      id: "double_money_strategy",
      title: "1 Haftada 2x Para Stratejisi",
      content: [
        "Yüksek volatilite dönemlerini tespit etme teknikleri",
        "Momentum trading ile hızlı kar alma stratejileri",
        "Scalping ve swing trading kombinasyonu",
        "Leverage ladder tekniği (kademeli kaldıraç artırma)",
        "Compound interest ile kar biriktirme",
        "Risk/reward oranını 1:3 ve üzerine çıkarma",
        "Market maker vs market taker stratejileri",
      ],
      keyPoints: [
        "2x hedefi için günlük %10-12 kar gerekli (compound ile)",
        "Yüksek volatilite = Yüksek fırsat ama yüksek risk",
        "Her trade'de maksimum %2-3 risk al",
        "Kar aldıktan sonra position size'ı artır",
        "Stop-loss kullanmak zorunlu, take-profit otomatik",
      ],
      riskLevel: "extreme",
      difficulty: "expert",
      practicalExample: "1000$ başlangıç, günlük %10 kar ile 7 günde 1948$ (yaklaşık 2x)",
      aiInsight: "AI uyarısı: 2x hedefi çok agresif. Gerçekçi hedef 1 ayda %50-70 kar. Sabırlı ol.",
      profitPotential: "Teorik: 1 haftada %100, Gerçekçi: 1 ayda %50-70",
      timeframe: "Hedef: 1 hafta, Gerçekçi: 2-4 hafta",
    },
    {
      id: "advanced_leverage",
      title: "İleri Seviye Kaldıraç Teknikleri",
      content: [
        "Dynamic leverage adjustment (dinamik kaldıraç ayarlama)",
        "Volatility-based leverage selection",
        "Multi-timeframe leverage strategy",
        "Leverage ladder ile risk dağıtımı",
        "Cross-margin ile portföy optimizasyonu",
        "Funding rate arbitrajı ile ek gelir",
        "Liquidation price hesaplama ve korunma",
      ],
      keyPoints: [
        "Düşük volatilite = Yüksek leverage (10-20x)",
        "Yüksek volatilite = Düşük leverage (2-5x)",
        "Trend başlangıcında düşük, devamında yüksek leverage",
        "Liquidation price'ı asla %15'ten yakın tutma",
      ],
      riskLevel: "high",
      difficulty: "expert",
      practicalExample: "BTC volatilite %2 iken 15x, %5 iken 5x leverage kullan",
      aiInsight: "AI stratejisi: Volatilite ile ters orantılı leverage kullan. Risk sabit kal, leverage değişsin.",
      profitPotential: "Optimum leverage ile %20-40 aylık getiri",
      timeframe: "Öğrenme: 2 hafta, Uygulama: sürekli",
    },
    {
      id: "scalping_mastery",
      title: "Futures Scalping Ustalığı",
      content: [
        "1-5 dakikalık timeframe'lerde scalping teknikleri",
        "Order book analizi ve market depth okuma",
        "Bid-ask spread'den faydalanma",
        "High-frequency trading benzeri stratejiler",
        "Funding rate dönemlerinde scalping",
        "News-based scalping (haber bazlı)",
        "Automated scalping bot kurulumu",
      ],
      keyPoints: [
        "Scalping için minimum 10x leverage gerekli",
        "İşlem başına %0.1-0.3 kar hedefle",
        "Günde 20-50 işlem yapabilirsin",
        "Stop-loss çok sıkı: %0.2-0.5 maksimum",
        "Yüksek hacimli coinlerde scalping yap",
      ],
      riskLevel: "extreme",
      difficulty: "expert",
      practicalExample: "BTC'de 20x leverage, %0.2 kar hedefi, %0.3 stop-loss",
      aiInsight: "AI analizi: Scalping yüksek stres ve konsantrasyon gerektirir. Günde 2-3 saat maksimum.",
      profitPotential: "Günlük %5-15, aylık %100-300 (çok riskli)",
      timeframe: "Öğrenme: 1 ay, Ustalaşma: 6 ay",
    },
    {
      id: "swing_trading_futures",
      title: "Futures Swing Trading",
      content: [
        "4H-1D timeframe'lerde swing trading",
        "Fibonacci retracement ile entry/exit noktaları",
        "Support/resistance seviyelerinde pozisyon alma",
        "Trend following ile büyük hareketleri yakalama",
        "Multiple position management",
        "Partial profit taking stratejileri",
        "Weekend gap trading teknikleri",
      ],
      keyPoints: [
        "Swing trading için 3-10x leverage ideal",
        "Pozisyon süresi: 1-7 gün",
        "Trend yönünde trade al, counter-trend riskli",
        "Partial profit: %50'sini %5 karda, %50'sini trend sonunda",
      ],
      riskLevel: "medium",
      difficulty: "advanced",
      practicalExample: "ETH'de 5x leverage, 4H trend takibi, %3 kar hedefi",
      aiInsight: "AI önerisi: Swing trading scalping'den daha sürdürülebilir. Sabır gerektirir ama daha güvenli.",
      profitPotential: "Haftalık %10-25, aylık %40-100",
      timeframe: "Pozisyon süresi: 1-7 gün",
    },
    {
      id: "risk_management_advanced",
      title: "İleri Seviye Risk Yönetimi",
      content: [
        "Kelly Criterion ile optimal position sizing",
        "Value at Risk (VaR) hesaplamaları",
        "Maximum drawdown kontrolü",
        "Correlation risk yönetimi (birden fazla coin)",
        "Black swan event'lere karşı korunma",
        "Emergency exit stratejileri",
        "Psychological risk management",
      ],
      keyPoints: [
        "Hiçbir zaman portföyün %5'inden fazlasını riske atma",
        "Maximum 3 pozisyon aynı anda aç",
        "Günlük loss %10'u geçerse trading'i durdur",
        "Aylık hedef: %20-30, daha fazlası açgözlülük",
      ],
      riskLevel: "low",
      difficulty: "advanced",
      practicalExample: "10,000$ portföy, maksimum 500$ risk per trade, 3 pozisyon limit",
      aiInsight: "AI uyarısı: Risk yönetimi kar etmekten daha önemli. Sermayeyi koru, kar kendiliğinden gelir.",
      profitPotential: "Sürdürülebilir %15-30 aylık getiri",
      timeframe: "Sürekli uygulama gerekli",
    },
    {
      id: "market_psychology",
      title: "Piyasa Psikolojisi ve Sentiment Analizi",
      content: [
        "Fear & Greed Index kullanımı",
        "Social media sentiment tracking",
        "Whale movement analysis",
        "Funding rate psychology",
        "Open interest analizi",
        "Market maker vs retail trader psychology",
        "FOMO ve FUD'dan faydalanma",
      ],
      keyPoints: [
        "Extreme fear = Alım fırsatı (contrarian)",
        "Extreme greed = Satış zamanı",
        "Whale hareketlerini takip et, onlarla aynı yönde git",
        "Funding rate extremes'leri ters sinyal olarak kullan",
      ],
      riskLevel: "medium",
      difficulty: "advanced",
      practicalExample: "Fear index 20'nin altında long, 80'in üstünde short pozisyon",
      aiInsight: "AI analizi: Piyasa psikolojisi teknik analizden daha güçlü olabilir. Sentiment'i takip et.",
      profitPotential: "Doğru timing ile %30-50 aylık getiri",
      timeframe: "Sürekli monitoring gerekli",
    },
    {
      id: "automated_trading",
      title: "Otomatik Trading Bot Kurulumu",
      content: [
        "TradingView alerts ile otomatik trading",
        "Python ile basit trading bot yazma",
        "3Commas, Pionex gibi bot platformları",
        "Grid trading bot stratejileri",
        "DCA (Dollar Cost Averaging) bot kurulumu",
        "Backtesting ve forward testing",
        "Bot performance monitoring",
      ],
      keyPoints: [
        "Bot'lar 24/7 çalışır, duygusal karar vermez",
        "Basit stratejiler daha iyi çalışır",
        "Mutlaka backtesting yap, canlıya geçmeden önce",
        "Bot'u sürekli monitor et, piyasa değişebilir",
      ],
      riskLevel: "medium",
      difficulty: "expert",
      practicalExample: "Grid bot: BTC 40k-50k arası, %1 grid aralığı",
      aiInsight: "AI önerisi: Bot'lar yardımcı araç, tamamen güvenme. Manuel müdahale gerekebilir.",
      profitPotential: "Pasif gelir: %10-20 aylık",
      timeframe: "Kurulum: 1 hafta, Optimizasyon: sürekli",
    },
    {
      id: "advanced_indicators",
      title: "İleri Seviye Teknik İndikatörler",
      content: [
        "Volume Profile ve VPVR analizi",
        "Market Profile ile value area tespiti",
        "Order Flow analysis",
        "Cumulative Volume Delta (CVD)",
        "On-chain metrics ile futures correlation",
        "Intermarket analysis (DXY, Gold, Stock correlation)",
        "Custom indicator development",
      ],
      keyPoints: [
        "Volume Profile en güçlü destek/direnç göstergesi",
        "CVD ile smart money hareketlerini takip et",
        "On-chain data futures'ı 1-2 gün önceden tahmin edebilir",
        "Correlation analysis ile risk diversification yap",
      ],
      riskLevel: "low",
      difficulty: "expert",
      practicalExample: "BTC Volume Profile'da high volume node'larda destek/direnç bekle",
      aiInsight: "AI analizi: Gelişmiş indikatörler edge sağlar ama basit stratejiler de etkili olabilir.",
      profitPotential: "Doğru analiz ile %25-40 aylık getiri",
      timeframe: "Öğrenme: 2 ay, Ustalaşma: 6 ay",
    },
    {
      id: "portfolio_management",
      title: "Futures Portföy Yönetimi",
      content: [
        "Multi-asset futures portfolio construction",
        "Correlation-based position sizing",
        "Sector rotation strategies",
        "Hedging strategies (long spot, short futures)",
        "Cash flow management",
        "Tax optimization for futures trading",
        "Performance measurement and attribution",
      ],
      keyPoints: [
        "Farklı sektörlerden coinlere yatırım yap",
        "Correlation 0.7'den yüksek coinlerde aynı anda pozisyon alma",
        "Portföyün %20'si cash olarak tut",
        "Aylık performance review yap",
      ],
      riskLevel: "low",
      difficulty: "advanced",
      practicalExample: "BTC %40, ETH %30, SOL %20, AVAX %10 ağırlıklı portföy",
      aiInsight: "AI önerisi: Diversification risk azaltır ama aşırı diversification getiriyi de azaltır.",
      profitPotential: "Dengeli portföy ile %20-35 aylık getiri",
      timeframe: "Sürekli rebalancing gerekli",
    },
    {
      id: "tax_legal",
      title: "Vergi ve Yasal Konular",
      content: [
        "Türkiye'de kripto futures vergi durumu",
        "Kar/zarar hesaplama yöntemleri",
        "FIFO vs LIFO accounting methods",
        "Vergi optimizasyonu stratejileri",
        "Yasal risk yönetimi",
        "KYC/AML compliance",
        "Record keeping best practices",
      ],
      keyPoints: [
        "Tüm işlemleri kayıt altına al",
        "Vergi danışmanı ile çalış",
        "Büyük karlar için vergi ayır",
        "Yasal değişiklikleri takip et",
      ],
      riskLevel: "low",
      difficulty: "intermediate",
      practicalExample: "100,000 TL kar için yaklaşık 20,000 TL vergi ayır",
      aiInsight: "AI uyarısı: Vergi planlaması kar planlaması kadar önemli. Yasal sorun yaşama.",
      profitPotential: "Vergi optimizasyonu ile %5-10 ek getiri",
      timeframe: "Yıllık vergi planlaması",
    },
    {
      id: "psychology_discipline",
      title: "Trading Psikolojisi ve Disiplin - AI'nın En Güçlü Alanı",
      content: [
        "FOMO (Fear of Missing Out) ile başa çıkma teknikleri",
        "Revenge trading'den kaçınma stratejileri",
        "Kar/zarar sonrası duygusal kontrol mekanizmaları",
        "Trading planı oluşturma ve uygulama disiplini",
        "Günlük/haftalık performans değerlendirmesi",
        "Stress yönetimi ve karar verme süreçleri",
        "Overtrading'den korunma yöntemleri",
        "Kayıp serileri ile başa çıkma",
        "Başarı sonrası ego kontrolü",
        "Piyasa manipülasyonlarına karşı mental dayanıklılık",
        "2x kar hedefi psikolojisi ve gerçekçi beklentiler",
      ],
      keyPoints: [
        "En büyük düşman kendi duygularınız - AI bu konuda objektif kalır",
        "2x kar hedefi çok agresif, %50-70 daha gerçekçi",
        "Plan olmadan trading kumar oynamaktır - AI her zaman planlı hareket eder",
        "Kayıplar trading'in doğal parçasıdır - AI bunu kabul eder ve devam eder",
        "Tutarlılık büyük karlardan daha önemli - AI uzun vadeli düşünür",
        "Duygusal kararlar %90 kayıpla sonuçlanır - AI duygusuz analiz yapar",
        "Sabır en büyük sermayedir - AI beklemesini bilir",
        "Disiplin = Başarı, AI asla kuralları çiğnemez",
        "Agresif hedefler genellikle büyük kayıplara yol açar",
      ],
      riskLevel: "medium",
      difficulty: "advanced",
      practicalExample:
        "Günlük %5 zarar limitine ulaştığında AI otomatik olarak trading'i durdurur ve ertesi gün fresh başlar",
      aiInsight:
        "AI Psikoloji Avantajı: İnsanların aksine AI FOMO, korku, açgözlülük hissetmez. Bu da %300 daha objektif kararlar almasını sağlar. 2x hedefi yerine sürdürülebilir %20-30 aylık getiri hedefler.",
      profitPotential: "Disiplinli yaklaşım ile %20-30 aylık sürdürülebilir getiri",
      timeframe: "Sürekli psikolojik disiplin gerekli",
    },
  ]

  // AI öğrenme simülasyonu
  useEffect(() => {
    if (isLearning) {
      const learningInterval = setInterval(() => {
        setLearningProgress((prev) => {
          const newProgress = Math.min(prev.learningProgress + 1.5, 100)
          const newCompletedLessons = Math.floor((newProgress / 100) * prev.totalLessons)

          // Yeni kavramlar öğrenme
          const newConcepts = []
          const newSkills = []
          const newStrategies = []
          const newTechniques = []

          if (newCompletedLessons > prev.completedLessons) {
            const currentLessonData = futuresLessons[newCompletedLessons - 1]
            if (currentLessonData) {
              newConcepts.push(...currentLessonData.keyPoints.slice(0, 2))
              newSkills.push(currentLessonData.title)

              if (currentLessonData.id === "double_money_strategy") {
                newStrategies.push("2x Para Stratejisi", "Compound Interest", "Momentum Trading")
              }
              if (currentLessonData.id === "scalping_mastery") {
                newTechniques.push("High-Frequency Scalping", "Order Book Analysis")
              }
              if (currentLessonData.id === "advanced_leverage") {
                newTechniques.push("Dynamic Leverage", "Volatility-Based Leverage")
              }
            }
          }

          return {
            ...prev,
            learningProgress: newProgress,
            completedLessons: newCompletedLessons,
            keyConceptsLearned: [...prev.keyConceptsLearned, ...newConcepts],
            practicalSkills: [...prev.practicalSkills, ...newSkills],
            profitStrategies: [...prev.profitStrategies, ...newStrategies],
            advancedTechniques: [...prev.advancedTechniques, ...newTechniques],
            riskAwareness: Math.min(prev.riskAwareness + 2, 100),
          }
        })

        // Kar simülasyonu
        setProfitSimulation((prev) => {
          const dailyReturn = (Math.random() - 0.3) * 0.15 // -4.5% ile +10.5% arası günlük getiri
          const newValue = prev.currentValue * (1 + dailyReturn)
          const totalProfit = newValue - prev.initialCapital
          const profitPercentage = (totalProfit / prev.initialCapital) * 100
          const newTrades = prev.trades + Math.floor(Math.random() * 5) + 1
          const winRate = Math.min(85, 45 + (learningProgress.learningProgress / 100) * 40)

          return {
            ...prev,
            currentValue: Math.max(prev.initialCapital * 0.5, newValue), // En fazla %50 kayıp
            totalProfit,
            profitPercentage,
            trades: newTrades,
            winRate,
          }
        })

        // AI soruları üret
        if (Math.random() < 0.4) {
          const questions = [
            "2x kar hedefi gerçekçi mi, yoksa çok agresif mi?",
            "Bu leverage seviyesi portföy için uygun mu?",
            "Scalping stratejisi risk/reward oranı nasıl?",
            "Funding rate arbitrajı nasıl çalışır?",
            "Compound interest ile günlük %10 kar sürdürülebilir mi?",
            "Volatilite-based leverage nasıl hesaplanır?",
            "Grid trading bot kurulumu nasıl yapılır?",
            "Market psychology sentiment'i nasıl ölçülür?",
          ]
          const randomQuestion = questions[Math.floor(Math.random() * questions.length)]
          setAiQuestions((prev) => [randomQuestion, ...prev.slice(0, 4)])
        }
      }, 1500)

      return () => clearInterval(learningInterval)
    }
  }, [isLearning, learningProgress.learningProgress])

  const startLearning = () => {
    setIsLearning(true)
    setLearningProgress((prev) => ({
      ...prev,
      learningProgress: 0,
      completedLessons: 0,
      keyConceptsLearned: [],
      practicalSkills: [],
      profitStrategies: [],
      advancedTechniques: [],
      riskAwareness: 0,
    }))
    setProfitSimulation({
      initialCapital: 1000,
      currentValue: 1000,
      totalProfit: 0,
      profitPercentage: 0,
      trades: 0,
      winRate: 0,
    })
  }

  const stopLearning = () => {
    setIsLearning(false)
  }

  return (
    <div className="space-y-6">
      {/* YouTube Video Bilgisi ve Öğrenme Durumu */}
      <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Youtube className="h-6 w-6 text-red-600" />
            <div>
              <span className="text-xl">{learningProgress.videoTitle}</span>
              <p className="text-sm text-gray-600 font-normal">{learningProgress.channelName}</p>
            </div>
          </CardTitle>
          <CardDescription>AI bu videodan gelişmiş Binance Futures stratejilerini öğreniyor</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-5 gap-4 mb-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">{learningProgress.completedLessons}</p>
              <p className="text-sm text-gray-600">Tamamlanan Ders</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{learningProgress.learningProgress.toFixed(0)}%</p>
              <p className="text-sm text-gray-600">Öğrenme İlerlemesi</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">{learningProgress.profitStrategies.length}</p>
              <p className="text-sm text-gray-600">Kar Stratejisi</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">{learningProgress.riskAwareness.toFixed(0)}%</p>
              <p className="text-sm text-gray-600">Risk Farkındalığı</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">{learningProgress.advancedTechniques.length}</p>
              <p className="text-sm text-gray-600">İleri Teknik</p>
            </div>
          </div>

          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm">
              <span>Video Öğrenme İlerlemesi</span>
              <span>{learningProgress.learningProgress.toFixed(1)}%</span>
            </div>
            <Progress value={learningProgress.learningProgress} className="h-3" />
          </div>

          <div className="flex gap-3 mb-4">
            {!isLearning ? (
              <Button onClick={startLearning} className="bg-green-600 hover:bg-green-700">
                <Play className="h-4 w-4 mr-2" />
                AI Öğrenmeyi Başlat
              </Button>
            ) : (
              <Button onClick={stopLearning} variant="outline">
                <Brain className="h-4 w-4 mr-2" />
                Öğrenmeyi Durdur
              </Button>
            )}
            <Badge className="bg-red-100 text-red-800">
              <Youtube className="h-3 w-3 mr-1" />
              YouTube: 2x Para Stratejisi
            </Badge>
            <Badge className="bg-green-100 text-green-800">
              <DollarSign className="h-3 w-3 mr-1" />
              Gelişmiş Kaldıraç
            </Badge>
          </div>

          {/* Kar Simülasyonu */}
          <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-lg">AI Kar Simülasyonu</CardTitle>
              <CardDescription>Öğrenilen stratejilerle simüle edilen performans</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-xl font-bold text-green-600">${profitSimulation.currentValue.toFixed(2)}</p>
                  <p className="text-sm text-gray-600">Mevcut Değer</p>
                </div>
                <div className="text-center">
                  <p
                    className={`text-xl font-bold ${profitSimulation.profitPercentage >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    {profitSimulation.profitPercentage >= 0 ? "+" : ""}
                    {profitSimulation.profitPercentage.toFixed(1)}%
                  </p>
                  <p className="text-sm text-gray-600">Toplam Getiri</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-blue-600">{profitSimulation.trades}</p>
                  <p className="text-sm text-gray-600">Toplam İşlem</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-purple-600">{profitSimulation.winRate.toFixed(0)}%</p>
                  <p className="text-sm text-gray-600">Başarı Oranı</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Öğrenme Detayları */}
      <Tabs defaultValue="lessons" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="lessons">Dersler</TabsTrigger>
          <TabsTrigger value="strategies">Kar Stratejileri</TabsTrigger>
          <TabsTrigger value="techniques">İleri Teknikler</TabsTrigger>
          <TabsTrigger value="questions">AI Soruları</TabsTrigger>
          <TabsTrigger value="practice">Canlı Uygulama</TabsTrigger>
        </TabsList>

        <TabsContent value="lessons" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gelişmiş Futures Eğitim Müfredatı</CardTitle>
              <CardDescription>AI'nın öğrendiği 2x para stratejisi ve ileri seviye konular</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {futuresLessons.map((lesson, index) => (
                  <div
                    key={lesson.id}
                    className={`border rounded-lg p-4 ${
                      index < learningProgress.completedLessons
                        ? "bg-green-50 border-green-200"
                        : index === learningProgress.completedLessons && isLearning
                          ? "bg-blue-50 border-blue-200"
                          : "bg-gray-50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            index < learningProgress.completedLessons
                              ? "bg-green-600 text-white"
                              : index === learningProgress.completedLessons && isLearning
                                ? "bg-blue-600 text-white"
                                : "bg-gray-300 text-gray-600"
                          }`}
                        >
                          {index < learningProgress.completedLessons ? (
                            <CheckCircle className="h-4 w-4" />
                          ) : (
                            <span className="text-sm font-bold">{index + 1}</span>
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold">{lesson.title}</h3>
                          <div className="flex gap-2 mt-1">
                            <Badge
                              variant="outline"
                              className={
                                lesson.riskLevel === "extreme"
                                  ? "border-purple-300 text-purple-700"
                                  : lesson.riskLevel === "high"
                                    ? "border-red-300 text-red-700"
                                    : lesson.riskLevel === "medium"
                                      ? "border-yellow-300 text-yellow-700"
                                      : "border-green-300 text-green-700"
                              }
                            >
                              {lesson.riskLevel === "extreme"
                                ? "Aşırı Risk"
                                : lesson.riskLevel === "high"
                                  ? "Yüksek Risk"
                                  : lesson.riskLevel === "medium"
                                    ? "Orta Risk"
                                    : "Düşük Risk"}
                            </Badge>
                            <Badge variant="outline">{lesson.difficulty}</Badge>
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              {lesson.profitPotential}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      {index === learningProgress.completedLessons && isLearning && (
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-100"></div>
                          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-200"></div>
                        </div>
                      )}
                    </div>

                    {index < learningProgress.completedLessons && (
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-sm mb-2">Öğrenilen Konular:</h4>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {lesson.content.map((item, i) => (
                              <li key={i} className="flex items-start gap-2">
                                <CheckCircle className="h-3 w-3 text-green-600 mt-0.5 flex-shrink-0" />
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <h4 className="font-medium text-sm text-blue-800 mb-1">AI İçgörüsü:</h4>
                          <p className="text-sm text-blue-700">{lesson.aiInsight}</p>
                        </div>

                        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                          <h4 className="font-medium text-sm text-yellow-800 mb-1">Pratik Örnek:</h4>
                          <p className="text-sm text-yellow-700">{lesson.practicalExample}</p>
                        </div>

                        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                          <h4 className="font-medium text-sm text-green-800 mb-1">Kar Potansiyeli:</h4>
                          <p className="text-sm text-green-700">{lesson.profitPotential}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strategies" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI'nın Öğrendiği Kar Stratejileri</CardTitle>
              <CardDescription>2x para hedefi ve diğer gelişmiş stratejiler</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    Kar Stratejileri:
                  </h4>
                  <div className="space-y-2">
                    {learningProgress.profitStrategies.map((strategy, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <TrendingUp className="h-3 w-3 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{strategy}</span>
                      </div>
                    ))}
                    {learningProgress.profitStrategies.length === 0 && (
                      <p className="text-gray-500 text-sm">AI öğrenmeye başladığında stratejiler burada görünecek</p>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4 text-blue-600" />
                    Pratik Beceriler:
                  </h4>
                  <div className="space-y-2">
                    {learningProgress.practicalSkills.map((skill, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          {skill}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 2x Para Stratejisi Detayı */}
              <div className="mt-6 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 border border-orange-200 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">⚠️ 2x Para Stratejisi Gerçeği:</h4>
                <div className="text-sm text-orange-700 space-y-2">
                  <p>
                    • <strong>Teorik:</strong> Günlük %10 kar ile 7 günde 2x (1000$ → 1948$)
                  </p>
                  <p>
                    • <strong>Gerçek:</strong> Çok yüksek risk, %90 trader başarısız olur
                  </p>
                  <p>
                    • <strong>AI Önerisi:</strong> 1 ayda %50-70 kar daha sürdürülebilir
                  </p>
                  <p>
                    • <strong>Risk:</strong> Agresif hedefler genellikle büyük kayıplara yol açar
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="techniques" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>İleri Seviye Teknikler</CardTitle>
              <CardDescription>AI'nın öğrendiği gelişmiş trading teknikleri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {learningProgress.advancedTechniques.map((technique, index) => (
                  <div key={index} className="border rounded-lg p-3 bg-purple-50 border-purple-200">
                    <div className="flex items-start gap-2">
                      <Zap className="h-4 w-4 text-purple-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-purple-800">{technique}</p>
                        <p className="text-sm text-purple-600 mt-1">
                          {technique === "High-Frequency Scalping" && "1-5 dakikalık timeframe'lerde hızlı kar alma"}
                          {technique === "Order Book Analysis" && "Bid-ask spread ve market depth analizi"}
                          {technique === "Dynamic Leverage" && "Volatiliteye göre otomatik kaldıraç ayarlama"}
                          {technique === "Volatility-Based Leverage" && "Piyasa volatilitesine göre risk yönetimi"}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
                {learningProgress.advancedTechniques.length === 0 && (
                  <p className="text-center text-gray-500 py-8">AI öğrenmeye başladığında teknikler burada görünecek</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="questions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI'nın Sorduğu Sorular</CardTitle>
              <CardDescription>Öğrenme sürecinde oluşan kritik sorular</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {aiQuestions.map((question, index) => (
                  <div key={index} className="border rounded-lg p-3 bg-purple-50 border-purple-200">
                    <div className="flex items-start gap-2">
                      <Brain className="h-4 w-4 text-purple-600 mt-0.5" />
                      <p className="text-sm text-purple-800">{question}</p>
                    </div>
                  </div>
                ))}
                {aiQuestions.length === 0 && (
                  <p className="text-center text-gray-500 py-8">AI öğrenmeye başladığında sorular burada görünecek</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="practice" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Canlı Uygulama - AI Futures Analizi</CardTitle>
              <CardDescription>Öğrenilen stratejilerle gerçek zamanlı analiz</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Mevcut Piyasa Analizi:</h4>
                  <div className="space-y-3">
                    <div className="border rounded-lg p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">BTC/USDT Futures</span>
                        <Badge className="bg-green-100 text-green-800">LONG Sinyali</Badge>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>• Fiyat: $98,750 (Güçlü destek seviyesinde)</p>
                        <p>• Funding Rate: -0.02% (Negatif, bullish sinyal)</p>
                        <p>• Önerilen Leverage: 5x (Risk yönetimi)</p>
                        <p>• Stop-Loss: $95,200 (-%3.6)</p>
                        <p>• Take-Profit: $105,000 (+%6.3)</p>
                        <p>• 2x Hedef: Çok agresif, %50 kar daha gerçekçi</p>
                      </div>
                    </div>

                    <div className="border rounded-lg p-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">ETH/USDT Futures</span>
                        <Badge className="bg-green-100 text-green-800">SCALPING</Badge>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>• Fiyat: $3,850 (Volatilite yüksek)</p>
                        <p>• Scalping Fırsatı: 15x leverage</p>
                        <p>• Hedef: %0.3 kar, %0.2 stop-loss</p>
                        <p>• Günlük 10-20 işlem potansiyeli</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">AI Risk Yönetimi:</h4>
                  <div className="space-y-3">
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-red-800">2x Hedef Uyarısı</span>
                      </div>
                      <p className="text-sm text-red-700">
                        1 haftada 2x kar çok agresif bir hedef. %90 trader bu hedefi tutturamaz ve büyük kayıplar yaşar.
                      </p>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Calculator className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-800">Gerçekçi Hesaplama</span>
                      </div>
                      <div className="text-sm text-blue-700 space-y-1">
                        <p>• Portföy: $1,000</p>
                        <p>• Günlük Risk: %2 = $20</p>
                        <p>• Aylık Hedef: %30 = $300</p>
                        <p>• Yıllık Potansiyel: %360 (compound ile)</p>
                      </div>
                    </div>

                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-800">AI Öğrenme Durumu</span>
                      </div>
                      <p className="text-sm text-green-700">
                        Risk farkındalığı: %{learningProgress.riskAwareness.toFixed(0)} - AI sürdürülebilir stratejiler
                        öğrendi.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
