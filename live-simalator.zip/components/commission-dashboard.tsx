"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  TrendingUp,
  DollarSign,
  Award,
  Target,
  BarChart3,
  Users,
  Crown,
  Zap,
  CheckCircle,
  ArrowUp,
  ArrowDown,
} from "lucide-react"
import type { UserCommissionStats, TradeResult } from "@/lib/commission-system"

export default function CommissionDashboard() {
  const [userStats, setUserStats] = useState<UserCommissionStats | null>(null)
  const [recentTrades, setRecentTrades] = useState<TradeResult[]>([])
  const [selectedMonth, setSelectedMonth] = useState("2024-03")

  useEffect(() => {
    // Mock data yükleme
    loadUserData()
  }, [])

  const loadUserData = async () => {
    // Mock kullanıcı verileri
    const mockStats: UserCommissionStats = {
      userId: "user_123",
      totalTrades: 67,
      successfulTrades: 48,
      totalProfit: 8750,
      totalCommissionPaid: 875,
      currentTier: "Profesyonel",
      winRate: 0.716,
      averageProfit: 130.6,
      monthlyStats: [
        { month: "2024-01", trades: 22, profit: 2800, commission: 336 },
        { month: "2024-02", trades: 25, profit: 3200, commission: 384 },
        { month: "2024-03", trades: 20, profit: 2750, commission: 275 },
      ],
    }

    const mockTrades: TradeResult[] = [
      {
        id: "trade_001",
        userId: "user_123",
        signalId: "signal_001",
        symbol: "BTCUSDT",
        entryPrice: 43250,
        exitPrice: 44100,
        quantity: 0.1,
        tradeType: "BUY",
        profit: 85,
        profitPercent: 1.96,
        commissionRate: 0.1,
        commissionAmount: 8.5,
        executedAt: "2024-03-15T10:30:00Z",
        closedAt: "2024-03-15T14:20:00Z",
        status: "closed",
      },
      {
        id: "trade_002",
        userId: "user_123",
        signalId: "signal_002",
        symbol: "ETHUSDT",
        entryPrice: 3200,
        exitPrice: 3080,
        quantity: 1,
        tradeType: "BUY",
        profit: -120,
        profitPercent: -3.75,
        commissionRate: 0,
        commissionAmount: 0,
        executedAt: "2024-03-14T09:15:00Z",
        closedAt: "2024-03-14T11:45:00Z",
        status: "closed",
      },
      {
        id: "trade_003",
        userId: "user_123",
        signalId: "signal_003",
        symbol: "ADAUSDT",
        entryPrice: 0.65,
        exitPrice: 0.72,
        quantity: 1000,
        tradeType: "BUY",
        profit: 70,
        profitPercent: 10.77,
        commissionRate: 0.1,
        commissionAmount: 7,
        executedAt: "2024-03-13T16:00:00Z",
        closedAt: "2024-03-14T08:30:00Z",
        status: "closed",
      },
    ]

    setUserStats(mockStats)
    setRecentTrades(mockTrades)
  }

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "Başlangıç":
        return "bg-gray-100 text-gray-800"
      case "Gelişmiş":
        return "bg-blue-100 text-blue-800"
      case "Profesyonel":
        return "bg-purple-100 text-purple-800"
      case "VIP":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case "Başlangıç":
        return <Users className="h-4 w-4" />
      case "Gelişmiş":
        return <Target className="h-4 w-4" />
      case "Profesyonel":
        return <Award className="h-4 w-4" />
      case "VIP":
        return <Crown className="h-4 w-4" />
      default:
        return <Users className="h-4 w-4" />
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(amount)
  }

  const formatPercent = (value: number) => {
    return `${(value * 100).toFixed(1)}%`
  }

  if (!userStats) {
    return <div className="p-8 text-center">Yükleniyor...</div>
  }

  const currentMonthStats = userStats.monthlyStats.find((m) => m.month === selectedMonth)
  const nextTierThreshold = userStats.totalProfit < 1000 ? 1000 : userStats.totalProfit < 5000 ? 5000 : 20000
  const progressToNextTier = (userStats.totalProfit / nextTierThreshold) * 100

  return (
    <div className="space-y-6">
      {/* Kullanıcı Tier Durumu */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getTierIcon(userStats.currentTier)}
            Mevcut Seviyeniz: {userStats.currentTier}
          </CardTitle>
          <CardDescription>Başarılı işlemlerinize göre belirlenen komisyon oranınız</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">{formatPercent(userStats.winRate)}</p>
              <p className="text-sm text-gray-600">Başarı Oranı</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{formatCurrency(userStats.totalProfit)}</p>
              <p className="text-sm text-gray-600">Toplam Kar</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">{formatCurrency(userStats.totalCommissionPaid)}</p>
              <p className="text-sm text-gray-600">Ödenen Komisyon</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">
                {formatPercent(userStats.totalCommissionPaid / userStats.totalProfit)}
              </p>
              <p className="text-sm text-gray-600">Ortalama Komisyon</p>
            </div>
          </div>

          {userStats.currentTier !== "VIP" && (
            <div className="mt-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Sonraki seviyeye ilerleme</span>
                <span>
                  {formatCurrency(userStats.totalProfit)} / {formatCurrency(nextTierThreshold)}
                </span>
              </div>
              <Progress value={Math.min(progressToNextTier, 100)} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">
                Sonraki seviye için {formatCurrency(nextTierThreshold - userStats.totalProfit)} kar daha gerekli
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* İstatistik Kartları */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Toplam İşlem</p>
                <p className="text-xl font-bold">{userStats.totalTrades}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Başarılı İşlem</p>
                <p className="text-xl font-bold text-green-600">{userStats.successfulTrades}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Ortalama Kar</p>
                <p className="text-xl font-bold text-purple-600">{formatCurrency(userStats.averageProfit)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Bu Ay Komisyon</p>
                <p className="text-xl font-bold text-yellow-600">
                  {formatCurrency(currentMonthStats?.commission || 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detaylı Analiz */}
      <Tabs defaultValue="trades" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="trades">Son İşlemler</TabsTrigger>
          <TabsTrigger value="monthly">Aylık Rapor</TabsTrigger>
          <TabsTrigger value="tiers">Seviye Bilgileri</TabsTrigger>
        </TabsList>

        <TabsContent value="trades" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Son İşlemler ve Komisyonlar</CardTitle>
              <CardDescription>Gerçekleştirilen işlemler ve ödenen komisyon detayları</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTrades.map((trade) => (
                  <div key={trade.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">{trade.symbol}</Badge>
                        <Badge
                          className={trade.profit >= 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                        >
                          {trade.tradeType}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        {trade.profit >= 0 ? (
                          <ArrowUp className="h-4 w-4 text-green-600" />
                        ) : (
                          <ArrowDown className="h-4 w-4 text-red-600" />
                        )}
                        <span className={`font-semibold ${trade.profit >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {formatCurrency(trade.profit)}
                        </span>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Giriş: </span>
                        <span className="font-medium">{formatCurrency(trade.entryPrice)}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Çıkış: </span>
                        <span className="font-medium">{formatCurrency(trade.exitPrice)}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Kar %: </span>
                        <span className={`font-medium ${trade.profitPercent >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {trade.profitPercent.toFixed(2)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">Komisyon: </span>
                        <span className="font-medium text-blue-600">{formatCurrency(trade.commissionAmount)}</span>
                      </div>
                    </div>

                    <div className="mt-2 text-xs text-gray-500">
                      {new Date(trade.executedAt).toLocaleString("tr-TR")} -{" "}
                      {new Date(trade.closedAt).toLocaleString("tr-TR")}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Aylık Performans Raporu</CardTitle>
              <CardDescription>Aylık kar, komisyon ve işlem istatistikleri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userStats.monthlyStats.map((month) => (
                  <div key={month.month} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold">
                        {new Date(month.month + "-01").toLocaleDateString("tr-TR", {
                          year: "numeric",
                          month: "long",
                        })}
                      </h3>
                      <Badge className="bg-blue-100 text-blue-800">{month.trades} İşlem</Badge>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <p className="text-lg font-bold text-green-600">{formatCurrency(month.profit)}</p>
                        <p className="text-sm text-gray-600">Toplam Kar</p>
                      </div>
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <p className="text-lg font-bold text-blue-600">{formatCurrency(month.commission)}</p>
                        <p className="text-sm text-gray-600">Ödenen Komisyon</p>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <p className="text-lg font-bold text-purple-600">
                          {formatPercent(month.commission / month.profit)}
                        </p>
                        <p className="text-sm text-gray-600">Komisyon Oranı</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tiers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Seviye Sistemi ve Avantajlar</CardTitle>
              <CardDescription>Kar seviyenize göre komisyon oranları ve özel avantajlar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {[
                  {
                    name: "Başlangıç",
                    minProfit: 0,
                    maxProfit: 1000,
                    rate: 15,
                    features: ["Temel AI sinyalleri", "Günlük 5 sinyal", "Email desteği"],
                    color: "gray",
                  },
                  {
                    name: "Gelişmiş",
                    minProfit: 1000,
                    maxProfit: 5000,
                    rate: 12,
                    features: ["Gelişmiş AI sinyalleri", "Günlük 15 sinyal", "WhatsApp desteği", "Risk analizi"],
                    color: "blue",
                  },
                  {
                    name: "Profesyonel",
                    minProfit: 5000,
                    maxProfit: 20000,
                    rate: 10,
                    features: ["Premium AI sinyalleri", "Sınırsız sinyal", "1-1 danışmanlık", "Otomatik trading"],
                    color: "purple",
                  },
                  {
                    name: "VIP",
                    minProfit: 20000,
                    maxProfit: "∞",
                    rate: 8,
                    features: ["Özel AI modeli", "Kişisel analist", "Öncelikli destek", "Özel Telegram grubu"],
                    color: "yellow",
                  },
                ].map((tier) => (
                  <div
                    key={tier.name}
                    className={`border rounded-lg p-4 ${
                      tier.name === userStats.currentTier ? "border-blue-500 bg-blue-50" : ""
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Badge className={getTierColor(tier.name)}>{tier.name}</Badge>
                        {tier.name === userStats.currentTier && (
                          <Badge className="bg-green-100 text-green-800">Mevcut</Badge>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-red-600">%{tier.rate} Komisyon</p>
                        <p className="text-sm text-gray-600">
                          {formatCurrency(tier.minProfit)} -{" "}
                          {typeof tier.maxProfit === "number" ? formatCurrency(tier.maxProfit) : tier.maxProfit}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1">
                      {tier.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* CEO Motivasyon Mesajı */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Zap className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h3 className="font-bold text-green-800">CEO Mesajı</h3>
              <p className="text-green-700">
                {userStats.winRate > 0.7
                  ? `Mükemmel performans! %${(userStats.winRate * 100).toFixed(1)} başarı oranınız sizi ${userStats.currentTier} seviyesine taşıdı. Devam edin! 🚀`
                  : `%${(userStats.winRate * 100).toFixed(1)} başarı oranınız iyi, ancak daha da iyileştirebiliriz. Risk yönetimini gözden geçirin. 💪`}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
