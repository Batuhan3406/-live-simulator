"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Play, Pause, Brain, Eye, Users, Zap, Target, Activity } from "lucide-react"

interface LiveTradingSession {
  id: string
  title: string
  startCapital: number
  currentCapital: number
  profit: number
  profitPercent: number
  duration: number
  viewers: number
  trades: number
  winRate: number
  isLive: boolean
  aiModel: string
}

interface LiveTrade {
  id: string
  symbol: string
  type: "BUY" | "SELL"
  entryPrice: number
  currentPrice: number
  quantity: number
  profit: number
  profitPercent: number
  timestamp: string
  aiConfidence: number
  status: "open" | "closed" | "pending"
}

export default function YouTubeInspiredTrading() {
  const [liveSession, setLiveSession] = useState<LiveTradingSession>({
    id: "session_001",
    title: "500$ ile AI Bitcoin Trading - Canlı Kazanç Gösterimi",
    startCapital: 500,
    currentCapital: 847.5,
    profit: 347.5,
    profitPercent: 69.5,
    duration: 145, // dakika
    viewers: 1247,
    trades: 12,
    winRate: 83.3,
    isLive: true,
    aiModel: "GPT-4 Crypto Trader",
  })

  const [liveTrades, setLiveTrades] = useState<LiveTrade[]>([
    {
      id: "trade_001",
      symbol: "BTCUSDT",
      type: "BUY",
      entryPrice: 43250,
      currentPrice: 43890,
      quantity: 0.0115,
      profit: 7.36,
      profitPercent: 1.48,
      timestamp: "14:32:15",
      aiConfidence: 87,
      status: "open",
    },
    {
      id: "trade_002",
      symbol: "ETHUSDT",
      type: "SELL",
      entryPrice: 3200,
      currentPrice: 3180,
      quantity: 0.15,
      profit: 3.0,
      profitPercent: 0.63,
      timestamp: "14:28:42",
      aiConfidence: 92,
      status: "closed",
    },
  ])

  const [chatMessages, setChatMessages] = useState([
    { user: "CryptoFan23", message: "AI gerçekten bu kadar başarılı mı? 🤔", time: "14:35" },
    { user: "TraderAli", message: "Hangi indikatörleri kullanıyor AI?", time: "14:34" },
    { user: "BitcoinAdam", message: "500$'dan 847$ yapmış, helal olsun! 🚀", time: "14:33" },
    { user: "YeniBaslayan", message: "Ben de deneyebilir miyim?", time: "14:32" },
  ])

  const [isPlaying, setIsPlaying] = useState(true)

  // Simüle canlı veri güncellemeleri
  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      // Sermaye güncelleme
      setLiveSession((prev) => ({
        ...prev,
        currentCapital: prev.currentCapital + (Math.random() - 0.4) * 5,
        profit: prev.currentCapital - prev.startCapital,
        profitPercent: ((prev.currentCapital - prev.startCapital) / prev.startCapital) * 100,
        viewers: prev.viewers + Math.floor((Math.random() - 0.5) * 10),
        duration: prev.duration + 1,
      }))

      // Yeni chat mesajı
      if (Math.random() < 0.3) {
        const newMessage = {
          user: `User${Math.floor(Math.random() * 1000)}`,
          message: [
            "Bu AI sistemi nereden öğrenebilirim?",
            "Gerçek mi bu kazançlar?",
            "Risk yönetimi nasıl yapılıyor?",
            "Hangi borsayı kullanıyorsunuz?",
            "Başlangıç için ne kadar sermaye gerekli?",
          ][Math.floor(Math.random() * 5)],
          time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
        }

        setChatMessages((prev) => [newMessage, ...prev.slice(0, 9)])
      }
    }, 3000)

    return () => clearInterval(interval)
  }, [isPlaying])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(amount)
  }

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}:${mins.toString().padStart(2, "0")}`
  }

  return (
    <div className="space-y-6">
      {/* YouTube Tarzı Header */}
      <Card className="bg-gradient-to-r from-red-50 to-red-100 border-red-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
                <Play className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">{liveSession.title}</h2>
                <p className="text-sm text-gray-600">Live Simalotör AI Trading</p>
              </div>
            </div>
            <Badge className="bg-red-600 text-white animate-pulse">🔴 CANLI</Badge>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{formatCurrency(liveSession.currentCapital)}</p>
              <p className="text-sm text-gray-600">Mevcut Sermaye</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">+{formatCurrency(liveSession.profit)}</p>
              <p className="text-sm text-gray-600">Toplam Kar</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">%{liveSession.profitPercent.toFixed(1)}</p>
              <p className="text-sm text-gray-600">Kar Oranı</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">{formatDuration(liveSession.duration)}</p>
              <p className="text-sm text-gray-600">Canlı Süre</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Ana Trading Ekranı */}
        <div className="lg:col-span-2 space-y-6">
          {/* Kontrol Paneli */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-blue-600" />
                AI Trading Kontrolü
              </CardTitle>
              <CardDescription>{liveSession.aiModel} ile otomatik işlem yapılıyor</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <Button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className={isPlaying ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
                  >
                    {isPlaying ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                    {isPlaying ? "Durdur" : "Başlat"}
                  </Button>
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium">{liveSession.viewers.toLocaleString()} izleyici</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <span>İşlem: {liveSession.trades}</span>
                  <span>Başarı: %{liveSession.winRate}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Kar Hedefi: %100</span>
                    <span>%{liveSession.profitPercent.toFixed(1)}</span>
                  </div>
                  <Progress value={Math.min(liveSession.profitPercent, 100)} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Aktif İşlemler */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-green-600" />
                Canlı İşlemler
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {liveTrades.map((trade) => (
                  <div key={trade.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline">{trade.symbol}</Badge>
                        <Badge
                          className={trade.type === "BUY" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                        >
                          {trade.type}
                        </Badge>
                        <Badge
                          className={
                            trade.status === "open" ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"
                          }
                        >
                          {trade.status === "open" ? "AÇIK" : "KAPALI"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Brain className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium">%{trade.aiConfidence}</span>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Giriş: </span>
                        <span className="font-medium">${trade.entryPrice.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Güncel: </span>
                        <span className="font-medium">${trade.currentPrice.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Kar: </span>
                        <span className={`font-medium ${trade.profit >= 0 ? "text-green-600" : "text-red-600"}`}>
                          ${trade.profit.toFixed(2)} ({trade.profitPercent.toFixed(2)}%)
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">Zaman: </span>
                        <span className="font-medium">{trade.timestamp}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sağ Sidebar - Chat ve İstatistikler */}
        <div className="space-y-6">
          {/* İstatistikler */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-orange-600" />
                Performans
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-lg font-bold text-green-600">{liveSession.trades}</p>
                  <p className="text-xs text-gray-600">Toplam İşlem</p>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-lg font-bold text-blue-600">%{liveSession.winRate}</p>
                  <p className="text-xs text-gray-600">Başarı Oranı</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Günlük Hedef:</span>
                  <span className="font-medium">$1000</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Kalan Süre:</span>
                  <span className="font-medium">6s 15dk</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Risk Seviyesi:</span>
                  <span className="font-medium text-green-600">Düşük</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Canlı Chat */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-purple-600" />
                Canlı Chat
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {chatMessages.map((msg, index) => (
                  <div key={index} className="text-sm">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-blue-600">{msg.user}</span>
                      <span className="text-xs text-gray-500">{msg.time}</span>
                    </div>
                    <p className="text-gray-700 pl-2 border-l-2 border-gray-200">{msg.message}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <Zap className="h-4 w-4 inline mr-1" />
                  <strong>Canlı Demo:</strong> Bu gerçek bir trading seansıdır. Kendi sorumluluğunuzda yatırım yapın.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Hızlı Başlangıç */}
          <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-lg">Sen de Başla!</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-700">Aynı AI sistemi ile kendi trading'ine başla</p>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Minimum 100$ sermaye</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>Sadece kardan %10 komisyon</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span>7/24 AI desteği</span>
                  </div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Hemen Başla</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
