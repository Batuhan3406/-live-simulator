"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { TrendingUp, Brain, BarChart3, Clock, Bitcoin, Wallet, BookOpen } from "lucide-react"

const navigationItems = [
  {
    title: "Ana Sayfa",
    href: "/",
    icon: TrendingUp,
  },
  {
    title: "Portföyüm",
    href: "/portfoyum",
    icon: Wallet,
  },
  {
    title: "Yatırım Analizi",
    href: "/investment",
    icon: BarChart3,
  },
  {
    title: "AI Asistan",
    href: "/ai-assistant",
    icon: Brain,
  },
  {
    title: "AI Eğitimi",
    href: "/ai-training",
    icon: BookOpen,
  },
  {
    title: "Zaman Kontrolü",
    href: "/time-control",
    icon: Clock,
  },
  {
    title: "Kripto Canlı",
    href: "/crypto-live",
    icon: Bitcoin,
  },
]

export default function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="bg-slate-800 border-b border-slate-700">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-green-400" />
              <span className="text-xl font-bold text-white">Live Simalotör</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-1">
            {navigationItems.slice(0, 7).map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    pathname === item.href
                      ? "bg-slate-700 text-white"
                      : "text-gray-300 hover:bg-slate-700 hover:text-white",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.title}</span>
                </Link>
              )
            })}
          </div>

          <div className="md:hidden">
            <button className="text-gray-300 hover:text-white">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="md:hidden border-t border-slate-700">
        <div className="px-2 pt-2 pb-3 space-y-1">
          {navigationItems.map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center space-x-2 px-3 py-2 rounded-md text-base font-medium transition-colors",
                  pathname === item.href
                    ? "bg-slate-700 text-white"
                    : "text-gray-300 hover:bg-slate-700 hover:text-white",
                )}
              >
                <Icon className="h-5 w-5" />
                <span>{item.title}</span>
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
