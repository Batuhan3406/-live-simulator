"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Brain,
  Clock,
  Smartphone,
  Computer,
  DollarSign,
  CheckCircle,
  Star,
  Target,
  BookOpen,
  TrendingUp,
  Award,
  Zap,
  Heart,
} from "lucide-react"

interface UserProfile {
  availableHours: number
  hasPhone: boolean
  hasComputer: boolean
  usesSocialMedia: boolean
  platforms: string[]
  experience: string
  goals: string
}

interface Task {
  id: string
  title: string
  description: string
  estimatedTime: number
  difficulty: "kolay" | "orta" | "zor"
  potentialEarning: string
  category: string
  completed: boolean
  steps: string[]
}

interface Course {
  id: string
  title: string
  platform: string
  duration: string
  difficulty: "başlangıç" | "orta" | "ileri"
  lessons: {
    title: string
    content: string[]
    tips: string[]
  }[]
}

export default function MoneyAIAssistant() {
  const [currentView, setCurrentView] = useState<
    "welcome" | "questions" | "dashboard" | "tasks" | "courses" | "profile"
  >("welcome")
  const [questionStep, setQuestionStep] = useState(0)
  const [userProfile, setUserProfile] = useState<UserProfile>({
    availableHours: 0,
    hasPhone: false,
    hasComputer: false,
    usesSocialMedia: false,
    platforms: [],
    experience: "",
    goals: "",
  })
  const [dailyTasks, setDailyTasks] = useState<Task[]>([])
  const [completedTasks, setCompletedTasks] = useState<string[]>([])
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [dailyGoal] = useState(25) // TL
  const [currentEarnings, setCurrentEarnings] = useState(0)

  const questions = [
    {
      question: "Bugün kaç saatin boş?",
      type: "hours",
      options: ["1 saat", "2-3 saat", "4-6 saat", "6+ saat"],
    },
    {
      question: "Hangi cihazların var?",
      type: "devices",
      options: ["Sadece telefon", "Sadece bilgisayar", "Her ikisi de", "Hiçbiri"],
    },
    {
      question: "Sosyal medyayı aktif kullanıyor musun?",
      type: "social",
      options: ["Evet, çok aktifim", "Bazen kullanırım", "Nadiren", "Hiç kullanmam"],
    },
    {
      question: "Hangi platformları biliyorsun?",
      type: "platforms",
      options: ["Instagram", "TikTok", "YouTube", "Canva", "Hiçbiri"],
    },
    {
      question: "Online para kazanma deneyimin nasıl?",
      type: "experience",
      options: ["Hiç deneyimim yok", "Biraz denedim", "Orta seviye", "Deneyimliyim"],
    },
  ]

  const courses: Course[] = [
    {
      id: "canva",
      title: "Canva ile Tasarım",
      platform: "Canva",
      duration: "30 dk",
      difficulty: "başlangıç",
      lessons: [
        {
          title: "Canva'ya Başlangıç",
          content: [
            "Canva.com'a ücretsiz kayıt ol",
            "Türkçe dil seçeneğini aktifleştir",
            "Temel arayüzü keşfet",
            "Şablon kategorilerini incele",
          ],
          tips: ["Pro sürümü deneme süresini kullan", "Favori şablonlarını kaydet", "Marka kitini oluştur"],
        },
        {
          title: "İlk Tasarımını Yap",
          content: [
            "Instagram Post şablonu seç",
            "Kendi fotoğrafını yükle",
            "Yazı tiplerini değiştir",
            "Renk paletini ayarla",
            "Tasarımını indir",
          ],
          tips: ["Yüksek çözünürlük seç", "PNG formatını tercih et", "Telif hakkı olan görselleri kullanma"],
        },
      ],
    },
    {
      id: "tiktok",
      title: "TikTok İçerik Üretimi",
      platform: "TikTok",
      duration: "45 dk",
      difficulty: "başlangıç",
      lessons: [
        {
          title: "TikTok Algoritmasını Anla",
          content: [
            "Trend hashtag'leri takip et",
            "Popüler sesleri kullan",
            "İlk 3 saniyede dikkat çek",
            "Video süresini optimize et",
          ],
          tips: ["Sabah 6-10 ve akşam 19-22 arası paylaş", "Yorumlara hızlı cevap ver", "Düzenli içerik üret"],
        },
        {
          title: "Viral İçerik Stratejileri",
          content: [
            "Güncel olayları takip et",
            "Challenge'lara katıl",
            "Duet ve stitch kullan",
            "Kendi tarzını oluştur",
          ],
          tips: ["Özgün ol, kopya çekme", "Kaliteli ses kullan", "İyi aydınlatmaya dikkat et"],
        },
      ],
    },
    {
      id: "shopier",
      title: "Shopier ile E-ticaret",
      platform: "Shopier",
      duration: "60 dk",
      difficulty: "orta",
      lessons: [
        {
          title: "Mağaza Kurulumu",
          content: [
            "Shopier'a ücretsiz kayıt ol",
            "Mağaza adını ve logosunu ayarla",
            "Ödeme yöntemlerini aktifleştir",
            "Kargo seçeneklerini belirle",
          ],
          tips: ["Güvenilir bir mağaza adı seç", "Profesyonel logo kullan", "Müşteri hizmetleri bilgilerini ekle"],
        },
        {
          title: "Ürün Ekleme ve Satış",
          content: [
            "Ürün fotoğraflarını çek",
            "Detaylı açıklama yaz",
            "Fiyatlandırma stratejisi belirle",
            "SEO dostu başlık oluştur",
          ],
          tips: ["Çoklu açıdan fotoğraf çek", "Rakip analizi yap", "Müşteri yorumlarını takip et"],
        },
      ],
    },
  ]

  const generateTasks = (profile: UserProfile): Task[] => {
    const tasks: Task[] = []

    if (profile.hasPhone && profile.usesSocialMedia) {
      tasks.push({
        id: "tiktok-video",
        title: "TikTok Trend Video Çek",
        description: "Güncel trend ses kullanarak 15-30 saniyelik video çek ve paylaş",
        estimatedTime: 30,
        difficulty: "kolay",
        potentialEarning: "5-15 TL",
        category: "Sosyal Medya",
        completed: false,
        steps: [
          "TikTok'ta trend sesleri keşfet",
          "Yaratıcı bir konsept düşün",
          "Video çek (15-30 saniye)",
          "Trend hashtag'ler ekle",
          "Paylaş ve etkileşim bekle",
        ],
      })

      tasks.push({
        id: "instagram-story",
        title: "Instagram Story İçeriği",
        description: "Günlük yaşamından ilginç anları story olarak paylaş",
        estimatedTime: 15,
        difficulty: "kolay",
        potentialEarning: "3-8 TL",
        category: "Sosyal Medya",
        completed: false,
        steps: [
          "İlginç bir an yakala",
          "Story'e müzik ekle",
          "Etkileşimli sticker kullan",
          "Hashtag ve konum ekle",
          "Paylaş",
        ],
      })
    }

    if (profile.hasComputer) {
      tasks.push({
        id: "fiverr-gig",
        title: "Fiverr'da Hizmet Teklifi",
        description: "Fiverr'da yeni bir gig oluştur veya mevcut profilini güncelle",
        estimatedTime: 60,
        difficulty: "orta",
        potentialEarning: "50-200 TL",
        category: "Freelance",
        completed: false,
        steps: [
          "Fiverr hesabını kontrol et",
          "Yeteneklerini analiz et",
          "Yeni gig oluştur",
          "Çekici başlık ve açıklama yaz",
          "Portföy örnekleri ekle",
        ],
      })

      tasks.push({
        id: "canva-design",
        title: "Canva ile Tasarım Yap",
        description: "Sosyal medya için 5 farklı tasarım oluştur",
        estimatedTime: 45,
        difficulty: "kolay",
        potentialEarning: "10-25 TL",
        category: "Tasarım",
        completed: false,
        steps: [
          "Canva'ya giriş yap",
          "Instagram post şablonu seç",
          "5 farklı tasarım oluştur",
          "Yüksek kalitede indir",
          "Sosyal medyada paylaş",
        ],
      })
    }

    if (profile.availableHours >= 2) {
      tasks.push({
        id: "survey-complete",
        title: "Anket Doldur",
        description: "Güvenilir anket sitelerinde 3-5 anket doldur",
        estimatedTime: 90,
        difficulty: "kolay",
        potentialEarning: "8-20 TL",
        category: "Anket",
        completed: false,
        steps: [
          "Güvenilir anket sitelerine kayıt ol",
          "Profil bilgilerini tamamla",
          "Uygun anketleri bul",
          "Dikkatlice doldur",
          "Ödüllerini talep et",
        ],
      })
    }

    return tasks.slice(0, 4) // Günde maksimum 4 görev
  }

  const handleQuestionAnswer = (answer: string) => {
    const currentQuestion = questions[questionStep]
    const newProfile = { ...userProfile }

    switch (currentQuestion.type) {
      case "hours":
        newProfile.availableHours = answer.includes("1 saat")
          ? 1
          : answer.includes("2-3")
            ? 2.5
            : answer.includes("4-6")
              ? 5
              : 8
        break
      case "devices":
        newProfile.hasPhone = answer.includes("telefon") || answer.includes("Her ikisi")
        newProfile.hasComputer = answer.includes("bilgisayar") || answer.includes("Her ikisi")
        break
      case "social":
        newProfile.usesSocialMedia = !answer.includes("Hiç")
        break
      case "platforms":
        if (!newProfile.platforms.includes(answer)) {
          newProfile.platforms.push(answer)
        }
        break
      case "experience":
        newProfile.experience = answer
        break
    }

    setUserProfile(newProfile)

    if (questionStep < questions.length - 1) {
      setQuestionStep(questionStep + 1)
    } else {
      // Sorular bitti, görevleri oluştur
      const tasks = generateTasks(newProfile)
      setDailyTasks(tasks)
      setCurrentView("dashboard")
    }
  }

  const completeTask = (taskId: string) => {
    if (!completedTasks.includes(taskId)) {
      setCompletedTasks([...completedTasks, taskId])
      const task = dailyTasks.find((t) => t.id === taskId)
      if (task) {
        const earning = Math.floor(Math.random() * 10) + 5 // 5-15 TL arası
        setCurrentEarnings(currentEarnings + earning)
      }
    }
  }

  const motivationalMessages = [
    "Harika gidiyorsun! 🎉",
    "Bugün çok üretkensin! 💪",
    "Hedefine yaklaşıyorsun! 🎯",
    "Mükemmel bir başlangıç! ⭐",
    "Devam et, başarıyorsun! 🚀",
    "Bugünkü performansın süper! 🔥",
  ]

  const getRandomMotivation = () => {
    return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)]
  }

  if (currentView === "welcome") {
    return (
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        <Card className="text-center bg-gradient-to-br from-green-50 to-blue-50">
          <CardHeader>
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Brain className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-gray-900">Para Kazanma AI Asistanı</CardTitle>
            <CardDescription className="text-lg">
              Sıfır sermaye ile günlük para kazanmanın yollarını öğren
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4">
                <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <h3 className="font-semibold">Kişisel Görevler</h3>
                <p className="text-sm text-gray-600">Size özel günlük kazanç görevleri</p>
              </div>
              <div className="text-center p-4">
                <BookOpen className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <h3 className="font-semibold">Mikro Kurslar</h3>
                <p className="text-sm text-gray-600">Pratik beceri geliştirme dersleri</p>
              </div>
              <div className="text-center p-4">
                <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold">Gelir Takibi</h3>
                <p className="text-sm text-gray-600">Kazancınızı takip edin</p>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Star className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-yellow-800">Bugünkü Hedefin</span>
              </div>
              <p className="text-2xl font-bold text-yellow-800">{dailyGoal} TL kazanmak</p>
              <p className="text-sm text-yellow-700">Hadi başlayalım! 🚀</p>
            </div>

            <Button
              onClick={() => setCurrentView("questions")}
              size="lg"
              className="w-full bg-green-600 hover:bg-green-700"
            >
              Başlayalım! 🎯
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (currentView === "questions") {
    const currentQuestion = questions[questionStep]

    return (
      <div className="max-w-2xl mx-auto p-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline">
                {questionStep + 1} / {questions.length}
              </Badge>
              <Progress value={((questionStep + 1) / questions.length) * 100} className="w-32" />
            </div>
            <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
            <CardDescription>Size en uygun görevleri belirlemek için birkaç soru soracağım</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="justify-start h-auto p-4 text-left bg-transparent"
                  onClick={() => handleQuestionAnswer(option)}
                >
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (currentView === "dashboard") {
    const completionRate = (completedTasks.length / dailyTasks.length) * 100

    return (
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Günlük Kontrol Paneli</h1>
            <p className="text-gray-600">{getRandomMotivation()}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setCurrentView("courses")}>
              <BookOpen className="h-4 w-4 mr-2" />
              Kurslar
            </Button>
            <Button variant="outline" onClick={() => setCurrentView("profile")}>
              Profil
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600">Bugünkü Kazanç</p>
                  <p className="text-xl font-bold text-green-600">{currentEarnings} TL</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">Hedef</p>
                  <p className="text-xl font-bold text-blue-600">{dailyGoal} TL</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Tamamlanan</p>
                  <p className="text-xl font-bold text-purple-600">
                    {completedTasks.length}/{dailyTasks.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm text-gray-600">Boş Zaman</p>
                  <p className="text-xl font-bold text-orange-600">{userProfile.availableHours}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-yellow-600" />
              Günlük İlerleme
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Tamamlanma Oranı</span>
                <span>{Math.round(completionRate)}%</span>
              </div>
              <Progress value={completionRate} className="h-2" />
              <div className="flex justify-between text-sm">
                <span>Kazanç İlerlemesi</span>
                <span>{Math.round((currentEarnings / dailyGoal) * 100)}%</span>
              </div>
              <Progress value={(currentEarnings / dailyGoal) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Daily Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-blue-600" />
              Bugünkü Görevlerin
            </CardTitle>
            <CardDescription>Size özel hazırlanmış kazanç görevleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {dailyTasks.map((task) => (
                <div
                  key={task.id}
                  className={`border rounded-lg p-4 ${completedTasks.includes(task.id) ? "bg-green-50 border-green-200" : ""}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold">{task.title}</h3>
                        <Badge
                          variant={
                            task.difficulty === "kolay"
                              ? "default"
                              : task.difficulty === "orta"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {task.difficulty}
                        </Badge>
                        <Badge variant="outline">{task.category}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {task.estimatedTime} dk
                        </span>
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-3 w-3" />
                          {task.potentialEarning}
                        </span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant={completedTasks.includes(task.id) ? "default" : "outline"}
                      onClick={() => completeTask(task.id)}
                      disabled={completedTasks.includes(task.id)}
                    >
                      {completedTasks.includes(task.id) ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Tamamlandı
                        </>
                      ) : (
                        "Başla"
                      )}
                    </Button>
                  </div>

                  {/* Task Steps */}
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-sm font-medium mb-2">Adımlar:</p>
                    <ol className="text-sm text-gray-600 space-y-1">
                      {task.steps.map((step, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-blue-600 font-medium">{index + 1}.</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Motivation */}
        {completedTasks.length > 0 && (
          <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Heart className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-green-800">Tebrikler! 🎉</p>
                  <p className="text-sm text-green-700">
                    {completedTasks.length} görev tamamladın ve {currentEarnings} TL kazandın!
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    )
  }

  if (currentView === "courses") {
    if (selectedCourse) {
      return (
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="outline" onClick={() => setSelectedCourse(null)}>
              ← Geri
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{selectedCourse.title}</h1>
              <p className="text-gray-600">
                {selectedCourse.platform} • {selectedCourse.duration}
              </p>
            </div>
          </div>

          <div className="grid gap-6">
            {selectedCourse.lessons.map((lesson, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-blue-600">{index + 1}</span>
                    </div>
                    {lesson.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Adımlar:</h4>
                    <ol className="space-y-2">
                      {lesson.content.map((step, stepIndex) => (
                        <li key={stepIndex} className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span className="text-xs font-medium">{stepIndex + 1}</span>
                          </div>
                          <span className="text-gray-700">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
                      <Star className="h-4 w-4" />
                      İpuçları:
                    </h4>
                    <ul className="space-y-1">
                      {lesson.tips.map((tip, tipIndex) => (
                        <li key={tipIndex} className="text-sm text-yellow-700 flex items-start gap-2">
                          <span>•</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )
    }

    return (
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Mikro Kurslar</h1>
            <p className="text-gray-600">Pratik beceriler öğren, hemen kazanmaya başla</p>
          </div>
          <Button variant="outline" onClick={() => setCurrentView("dashboard")}>
            ← Panele Dön
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card
              key={course.id}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedCourse(course)}
            >
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{course.platform}</Badge>
                  <Badge
                    variant={
                      course.difficulty === "başlangıç"
                        ? "default"
                        : course.difficulty === "orta"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {course.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{course.title}</CardTitle>
                <CardDescription>
                  {course.duration} • {course.lessons.length} ders
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {course.lessons.slice(0, 2).map((lesson, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="h-3 w-3 text-green-500" />
                      {lesson.title}
                    </div>
                  ))}
                  {course.lessons.length > 2 && (
                    <p className="text-sm text-gray-500">+{course.lessons.length - 2} ders daha</p>
                  )}
                </div>
                <Button className="w-full mt-4 bg-transparent" variant="outline">
                  Kursa Başla →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (currentView === "profile") {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Profilim</h1>
          <Button variant="outline" onClick={() => setCurrentView("dashboard")}>
            ← Panele Dön
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Kişisel Bilgiler</CardTitle>
            <CardDescription>Görev önerilerinizi kişiselleştirmek için kullanılan bilgiler</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Günlük Boş Zaman</label>
                <p className="text-lg font-semibold text-blue-600">{userProfile.availableHours} saat</p>
              </div>
              <div>
                <label className="text-sm font-medium">Cihazlar</label>
                <div className="flex gap-2 mt-1">
                  {userProfile.hasPhone && (
                    <Badge>
                      <Smartphone className="h-3 w-3 mr-1" />
                      Telefon
                    </Badge>
                  )}
                  {userProfile.hasComputer && (
                    <Badge>
                      <Computer className="h-3 w-3 mr-1" />
                      Bilgisayar
                    </Badge>
                  )}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Sosyal Medya</label>
                <p className="text-lg font-semibold text-green-600">
                  {userProfile.usesSocialMedia ? "Aktif" : "Pasif"}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium">Deneyim</label>
                <p className="text-lg font-semibold text-purple-600">{userProfile.experience}</p>
              </div>
            </div>

            {userProfile.platforms.length > 0 && (
              <div>
                <label className="text-sm font-medium">Bildiğin Platformlar</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {userProfile.platforms.map((platform, index) => (
                    <Badge key={index} variant="outline">
                      {platform}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>İstatistikler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{currentEarnings} TL</p>
                <p className="text-sm text-gray-600">Toplam Kazanç</p>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{completedTasks.length}</p>
                <p className="text-sm text-gray-600">Tamamlanan Görev</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          onClick={() => {
            setCurrentView("questions")
            setQuestionStep(0)
            setUserProfile({
              availableHours: 0,
              hasPhone: false,
              hasComputer: false,
              usesSocialMedia: false,
              platforms: [],
              experience: "",
              goals: "",
            })
          }}
          variant="outline"
          className="w-full"
        >
          Profili Yeniden Oluştur
        </Button>
      </div>
    )
  }

  return null
}
