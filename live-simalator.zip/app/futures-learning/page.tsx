"use client"

import FuturesAILearning from "@/components/futures-ai-learning"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Youtube, Brain, TrendingUp, AlertTriangle } from "lucide-react"

export default function FuturesLearningPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Futures Öğrenme Merkezi</h1>
          <p className="text-gray-600">YouTube videolarından AI'nın Binance Futures öğrenme süreci</p>
        </div>

        {/* Video Entegrasyon Bilgisi */}
        <Card className="mb-8 bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Youtube className="h-5 w-5 text-red-600" />
              YouTube Video Entegrasyonu
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">Otomatik Öğrenme</h3>
                <p className="text-sm text-gray-600">Video içeriğinden AI otomatik öğreniyor</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <TrendingUp className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">Pratik Uygulama</h3>
                <p className="text-sm text-gray-600">Öğrenilen bilgiler gerçek analizde kullanılıyor</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">Risk Farkındalığı</h3>
                <p className="text-sm text-gray-600">Futures risklerini öğrenerek güvenli öneriler</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ana Öğrenme Interface */}
        <FuturesAILearning />

        {/* CEO Stratejik Değerlendirme */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <CardTitle>CEO Stratejik Analiz: YouTube Entegrasyonu</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-blue-800">Video Öğrenme Avantajları:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Uzman İçerik:</strong> Coin Engineer gibi uzmanlardan öğrenme
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Güncel Bilgi:</strong> En son piyasa koşulları ve stratejiler
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Pratik Örnekler:</strong> Gerçek trading senaryoları
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Risk Eğitimi:</strong> Futures'ın tehlikelerini öğrenme
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">AI Öğrenme Süreci:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🧠
                    </Badge>
                    <span>
                      <strong>İçerik Analizi:</strong> Video'dan anahtar kavramları çıkarma
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📊
                    </Badge>
                    <span>
                      <strong>Strateji Öğrenme:</strong> Trading stratejilerini anlama
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ⚠️
                    </Badge>
                    <span>
                      <strong>Risk Değerlendirme:</strong> Güvenlik önlemlerini öğrenme
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎯
                    </Badge>
                    <span>
                      <strong>Pratik Uygulama:</strong> Öğrenilenleri gerçek analizde kullanma
                    </span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-yellow-800">Önemli Uyarı</span>
              </div>
              <p className="text-sm text-yellow-700">
                <strong>Futures Trading Yüksek Risk İçerir:</strong> AI bu videodan risk yönetimi öğreniyor ve
                kullanıcıları korumak için güvenli öneriler sunuyor. Kaldıraçlı işlemler sermayenizi tamamen
                kaybetmenize neden olabilir.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
