"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Play, Pause, RotateCcw, Calendar, TrendingUp, AlertTriangle } from "lucide-react"
import Navigation from "@/components/navigation"

interface TimeState {
  currentDate: Date
  speed: number
  isRunning: boolean
  totalDays: number
}

export default function TimeControlPage() {
  const [timeState, setTimeState] = useState<TimeState>({
    currentDate: new Date("2025-01-09"),
    speed: 1,
    isRunning: false,
    totalDays: 0,
  })

  const economicEvents = [
    {
      id: "1",
      date: "2025-01-15",
      time: "21:00",
      event: "Fed Faiz Kararı",
      importance: "high",
      expected: "%5.25-5.50",
    },
    {
      id: "2",
      date: "2025-01-18",
      time: "16:30",
      event: "ABD Enflasyon Verisi",
      importance: "high",
      expected: "%2.8",
    },
    {
      id: "3",
      date: "2025-01-22",
      time: "14:00",
      event: "Bitcoin ETF Kararı",
      importance: "high",
    },
    {
      id: "4",
      date: "2025-02-01",
      time: "10:00",
      event: "İşsizlik Oranı",
      importance: "medium",
      expected: "%3.7",
    },
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (timeState.isRunning) {
      interval = setInterval(() => {
        setTimeState((prev) => {
          const newDate = new Date(prev.currentDate)
          newDate.setDate(newDate.getDate() + prev.speed)

          return {
            ...prev,
            currentDate: newDate,
            totalDays: prev.totalDays + prev.speed,
          }
        })
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [timeState.isRunning, timeState.speed])

  const handlePlayPause = () => {
    setTimeState((prev) => ({ ...prev, isRunning: !prev.isRunning }))
  }

  const handleReset = () => {
    setTimeState({
      currentDate: new Date("2025-01-09"),
      speed: 1,
      isRunning: false,
      totalDays: 0,
    })
  }

  const handleSpeedChange = (newSpeed: number) => {
    setTimeState((prev) => ({ ...prev, speed: newSpeed }))
  }

  const advanceTime = (days: number) => {
    setTimeState((prev) => {
      const newDate = new Date(prev.currentDate)
      newDate.setDate(newDate.getDate() + days)
      return {
        ...prev,
        currentDate: newDate,
        totalDays: prev.totalDays + days,
      }
    })
  }

  const getSpeedLabel = (speed: number) => {
    switch (speed) {
      case 1:
        return "Normal (1 gün/saniye)"
      case 7:
        return "Hızlı (1 hafta/saniye)"
      case 30:
        return "Çok Hızlı (1 ay/saniye)"
      default:
        return `${speed}x Hız`
    }
  }

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const upcomingEvents = economicEvents.filter((event) => {
    const eventDate = new Date(event.date)
    const currentDate = timeState.currentDate
    const diffTime = eventDate.getTime() - currentDate.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays >= 0 && diffDays <= 30
  })

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("tr-TR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "long",
    })
  }

  const calculateDaysUntil = (eventDate: string) => {
    const event = new Date(eventDate)
    const current = timeState.currentDate
    const diffTime = event.getTime() - current.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Clock className="h-8 w-8 text-blue-400 mr-3" />
            <h1 className="text-3xl font-bold">Zaman Kontrolü</h1>
          </div>
          <p className="text-gray-400">
            Simülasyon zamanını kontrol edin ve gelecekteki piyasa olaylarını önceden görün
          </p>
        </div>

        {/* Current Time Display */}
        <Card className="mb-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Calendar className="h-5 w-5" />
              Mevcut Simülasyon Tarihi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400 mb-2">{formatDate(timeState.currentDate)}</div>
              <div className="flex items-center justify-center gap-4 text-sm text-gray-400">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>Hız: {getSpeedLabel(timeState.speed)}</span>
                </div>
                <div>Toplam: {timeState.totalDays} gün</div>
                <Badge variant={timeState.isRunning ? "default" : "secondary"}>
                  {timeState.isRunning ? "Çalışıyor" : "Durduruldu"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Time Control Panel */}
          <div className="lg:col-span-1">
            <Card className="mb-6 bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Zaman Kontrolü</CardTitle>
                <CardDescription className="text-gray-400">Simülasyon zamanını yönetin</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Manual Time Advance */}
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-white">Manuel İlerleme</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => advanceTime(1)}
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-slate-600 text-white hover:bg-slate-700"
                    >
                      +1 Gün
                    </Button>
                    <Button
                      onClick={() => advanceTime(7)}
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-slate-600 text-white hover:bg-slate-700"
                    >
                      +1 Hafta
                    </Button>
                    <Button
                      onClick={() => advanceTime(30)}
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-slate-600 text-white hover:bg-slate-700"
                    >
                      +1 Ay
                    </Button>
                    <Button
                      onClick={() => advanceTime(90)}
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-slate-600 text-white hover:bg-slate-700"
                    >
                      +3 Ay
                    </Button>
                  </div>
                </div>

                {/* Speed Control */}
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-white">Otomatik Hız</h4>
                  <div className="space-y-2">
                    {[1, 7, 30].map((speed) => (
                      <Button
                        key={speed}
                        onClick={() => handleSpeedChange(speed)}
                        variant={timeState.speed === speed ? "default" : "outline"}
                        size="sm"
                        className={`w-full ${timeState.speed === speed ? "" : "bg-transparent border-slate-600 text-white hover:bg-slate-700"}`}
                        disabled={timeState.isRunning}
                      >
                        {getSpeedLabel(speed)}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Control Buttons */}
                <div className="space-y-2">
                  <Button
                    onClick={handlePlayPause}
                    className={`w-full ${
                      timeState.isRunning ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"
                    }`}
                  >
                    {timeState.isRunning ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Duraklat
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Başlat
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    className="w-full bg-transparent border-slate-600 text-white hover:bg-slate-700"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Sıfırla
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Market Impact */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  Piyasa Etkisi
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-3 bg-slate-700 rounded-lg">
                    <div className="text-xl font-bold text-green-400">+₺2,450</div>
                    <div className="text-sm text-gray-400">Tahmini Kazanç</div>
                  </div>
                  <div className="text-center p-3 bg-slate-700 rounded-lg">
                    <div className="text-xl font-bold text-blue-400">%1.8</div>
                    <div className="text-sm text-gray-400">Günlük Getiri</div>
                  </div>
                  <div className="text-center p-3 bg-slate-700 rounded-lg">
                    <div className="text-xl font-bold text-purple-400">87%</div>
                    <div className="text-sm text-gray-400">AI Güven</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Economic Calendar */}
          <div className="lg:col-span-2">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <AlertTriangle className="h-5 w-5 text-orange-400" />
                  Ekonomik Takvim
                </CardTitle>
                <CardDescription className="text-gray-400">Yaklaşan önemli olaylar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingEvents.length > 0 ? (
                    upcomingEvents.map((event) => {
                      const daysUntil = calculateDaysUntil(event.date)
                      return (
                        <div key={event.id} className="border border-slate-600 rounded-lg p-4 bg-slate-700">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-white">
                                {new Date(event.date).toLocaleDateString("tr-TR")}
                              </span>
                              <span className="text-xs text-gray-400">{event.time}</span>
                            </div>
                            <Badge className={`text-xs ${getImportanceColor(event.importance)}`}>
                              {event.importance === "high"
                                ? "Yüksek"
                                : event.importance === "medium"
                                  ? "Orta"
                                  : "Düşük"}
                            </Badge>
                          </div>
                          <h4 className="font-semibold text-sm mb-1 text-white">{event.event}</h4>
                          {event.expected && (
                            <div className="text-xs text-gray-400 mb-1">Beklenen: {event.expected}</div>
                          )}
                          <div className="mt-2">
                            <span
                              className={`text-xs font-medium px-2 py-1 rounded ${
                                daysUntil <= 3
                                  ? "bg-red-900/50 text-red-300"
                                  : daysUntil <= 7
                                    ? "bg-yellow-900/50 text-yellow-300"
                                    : "bg-green-900/50 text-green-300"
                              }`}
                            >
                              {daysUntil === 0 ? "Bugün" : daysUntil === 1 ? "Yarın" : `${daysUntil} gün kaldı`}
                            </span>
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-600" />
                      <p className="text-sm">Önümüzdeki 30 gün içinde önemli olay yok</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* AI Recommendation */}
        <Card className="mt-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">🤖 AI Zaman Analizi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-700 rounded-lg p-4">
              <h4 className="font-medium text-blue-400 mb-2">💡 Akıllı Öneri</h4>
              <p className="text-sm text-gray-300 leading-relaxed">
                Mevcut zaman hızında ({getSpeedLabel(timeState.speed)}), önümüzdeki{" "}
                {upcomingEvents.length > 0 && calculateDaysUntil(upcomingEvents[0].date)} gün içinde{" "}
                <strong>{upcomingEvents[0]?.event}</strong> gerçekleşecek. Bu olay portföyünüzde{" "}
                <span className="text-green-400 font-medium">%8-12 pozitif etki</span> yaratabilir. Bitcoin ağırlığınızı
                %15 artırmanızı öneriyorum.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <Badge className="bg-green-900/50 text-green-300">Güven: %87</Badge>
                <Badge className="bg-blue-900/50 text-blue-300">Risk: Düşük</Badge>
                <Badge className="bg-purple-900/50 text-purple-300">Getiri: Yüksek</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
