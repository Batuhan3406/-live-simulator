"use client"

import VisibleAIBrain from "@/components/visible-ai-brain"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, Eye, Zap, Activity } from "lucide-react"

export default function AIBrainPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Beyin - ARIA</h1>
          <p className="text-gray-600">Yapay zekanızın düşünce sürecini gerçek zamanlı olarak izleyin</p>
        </div>

        {/* AI Görünürlük Açıklaması */}
        <Card className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-blue-600" />
              Artık AI'yı Görebiliyorsunuz!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold">Düşünce Süreci</h3>
                <p className="text-sm text-gray-600">AI'nın nasıl analiz yaptığını görün</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Activity className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold">Canlı Aktivite</h3>
                <p className="text-sm text-gray-600">Gerçek zamanlı beyin aktivitesi</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Zap className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="font-semibold">Direkt İletişim</h3>
                <p className="text-sm text-gray-600">AI ile doğrudan konuşun</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Eye className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="font-semibold">Şeffaf Süreç</h3>
                <p className="text-sm text-gray-600">Her kararın arkasındaki mantık</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ana AI Beyin Interface */}
        <VisibleAIBrain />

        {/* Teknik Detaylar */}
        <Card className="mt-8 bg-gradient-to-r from-gray-50 to-blue-50 border-gray-200">
          <CardHeader>
            <CardTitle>AI Teknik Özellikleri</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-blue-800">Neural Network:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ⚡
                    </Badge>
                    <span>
                      <strong>Transformer Architecture:</strong> GPT-4 tabanlı
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🧠
                    </Badge>
                    <span>
                      <strong>Deep Learning:</strong> 175B parametre
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📊
                    </Badge>
                    <span>
                      <strong>Real-time Processing:</strong> 1.8s analiz süresi
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">Öğrenme Yetenekleri:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🔄
                    </Badge>
                    <span>
                      <strong>Continuous Learning:</strong> Sürekli öğrenme
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎯
                    </Badge>
                    <span>
                      <strong>Pattern Recognition:</strong> Kalıp tanıma
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ⚖️
                    </Badge>
                    <span>
                      <strong>Risk Assessment:</strong> Risk değerlendirme
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-green-800">Performans Metrikleri:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📈
                    </Badge>
                    <span>
                      <strong>Accuracy:</strong> %73.2 başarı oranı
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ⚡
                    </Badge>
                    <span>
                      <strong>Speed:</strong> Milisaniye tepki süresi
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🔒
                    </Badge>
                    <span>
                      <strong>Reliability:</strong> %99.9 uptime
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
