"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Brain, Play, Pause, BookOpen, Target, CheckCircle, TrendingUp, AlertTriangle } from "lucide-react"
import Navigation from "@/components/navigation"

interface TrainingModule {
  id: string
  title: string
  description: string
  progress: number
  status: "completed" | "in-progress" | "locked"
  difficulty: "Başlangıç" | "Orta" | "İleri"
  estimatedTime: string
}

export default function AITrainingPage() {
  const [isTraining, setIsTraining] = useState(false)
  const [overallProgress, setOverallProgress] = useState(45)
  const [selectedModule, setSelectedModule] = useState<string | null>(null)

  const trainingModules: TrainingModule[] = [
    {
      id: "basics",
      title: "Yatırım Temelleri",
      description: "Temel yatırım kavramları ve piyasa analizi",
      progress: 100,
      status: "completed",
      difficulty: "Başlangıç",
      estimatedTime: "2 saat",
    },
    {
      id: "technical",
      title: "Teknik Analiz",
      description: "Grafik okuma, indikatörler ve trend analizi",
      progress: 75,
      status: "in-progress",
      difficulty: "Orta",
      estimatedTime: "4 saat",
    },
    {
      id: "risk",
      title: "Risk Yönetimi",
      description: "Portföy çeşitlendirme ve risk kontrolü",
      progress: 60,
      status: "in-progress",
      difficulty: "Orta",
      estimatedTime: "3 saat",
    },
    {
      id: "psychology",
      title: "Yatırım Psikolojisi",
      description: "Duygusal karar verme ve davranışsal finans",
      progress: 30,
      status: "in-progress",
      difficulty: "İleri",
      estimatedTime: "5 saat",
    },
    {
      id: "advanced",
      title: "İleri Stratejiler",
      description: "Türev araçlar ve karmaşık yatırım stratejileri",
      progress: 0,
      status: "locked",
      difficulty: "İleri",
      estimatedTime: "6 saat",
    },
    {
      id: "ai-integration",
      title: "AI Entegrasyonu",
      description: "Yapay zeka araçları ile yatırım optimizasyonu",
      progress: 0,
      status: "locked",
      difficulty: "İleri",
      estimatedTime: "4 saat",
    },
  ]

  const [modules, setModules] = useState(trainingModules)

  useEffect(() => {
    if (isTraining) {
      const interval = setInterval(() => {
        setModules((prev) =>
          prev.map((module) => {
            if (module.status === "in-progress") {
              const newProgress = Math.min(module.progress + Math.random() * 2, 100)
              return {
                ...module,
                progress: newProgress,
                status: newProgress >= 100 ? "completed" : "in-progress",
              }
            }
            return module
          }),
        )

        setOverallProgress((prev) => Math.min(prev + 0.1, 100))
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [isTraining])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500 text-white"
      case "in-progress":
        return "bg-blue-500 text-white"
      case "locked":
        return "bg-gray-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Başlangıç":
        return "text-green-400"
      case "Orta":
        return "text-yellow-400"
      case "İleri":
        return "text-red-400"
      default:
        return "text-gray-400"
    }
  }

  const completedModules = modules.filter((m) => m.status === "completed").length
  const inProgressModules = modules.filter((m) => m.status === "in-progress").length

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Brain className="h-8 w-8 text-purple-400 mr-3" />
            <h1 className="text-3xl font-bold">AI Eğitim Merkezi</h1>
          </div>
          <p className="text-gray-400">
            Yapay zeka destekli kişiselleştirilmiş yatırım eğitimi. AI asistanınız öğrenme sürecinizi optimize eder.
          </p>
        </div>

        {/* Progress Overview */}
        <Card className="mb-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Target className="h-5 w-5 mr-2" />
              Eğitim İlerlemesi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-1">{completedModules}</div>
                <div className="text-sm text-gray-400">Tamamlanan</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400 mb-1">{inProgressModules}</div>
                <div className="text-sm text-gray-400">Devam Eden</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400 mb-1">{overallProgress.toFixed(0)}%</div>
                <div className="text-sm text-gray-400">Genel İlerleme</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400 mb-1">24h</div>
                <div className="text-sm text-gray-400">Toplam Süre</div>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span>Genel İlerleme</span>
                <span>{overallProgress.toFixed(1)}%</span>
              </div>
              <Progress value={overallProgress} className="h-3" />
            </div>

            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setIsTraining(!isTraining)}
                className={isTraining ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
              >
                {isTraining ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Eğitimi Duraklat
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Eğitimi Başlat
                  </>
                )}
              </Button>
              {isTraining && <Badge className="bg-green-100 text-green-800 animate-pulse">🧠 AI Öğreniyor...</Badge>}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="modules" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="modules">Eğitim Modülleri</TabsTrigger>
            <TabsTrigger value="progress">Detaylı İlerleme</TabsTrigger>
            <TabsTrigger value="ai-insights">AI İçgörüleri</TabsTrigger>
          </TabsList>

          <TabsContent value="modules" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modules.map((module) => (
                <Card
                  key={module.id}
                  className={`bg-slate-800 border-slate-700 cursor-pointer transition-all hover:bg-slate-700/50 ${
                    selectedModule === module.id ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => setSelectedModule(module.id)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={getStatusColor(module.status)}>
                        {module.status === "completed"
                          ? "Tamamlandı"
                          : module.status === "in-progress"
                            ? "Devam Ediyor"
                            : "Kilitli"}
                      </Badge>
                      <span className={`text-sm ${getDifficultyColor(module.difficulty)}`}>{module.difficulty}</span>
                    </div>
                    <CardTitle className="text-white text-lg">{module.title}</CardTitle>
                    <CardDescription className="text-gray-400">{module.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>İlerleme</span>
                          <span>{module.progress.toFixed(0)}%</span>
                        </div>
                        <Progress value={module.progress} className="h-2" />
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 mr-1" />
                          {module.estimatedTime}
                        </div>
                        {module.status === "completed" && <CheckCircle className="h-4 w-4 text-green-400" />}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Detaylı İlerleme Raporu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {modules.map((module) => (
                    <div key={module.id} className="border-b border-slate-700 pb-4 last:border-b-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-white">{module.title}</h3>
                        <Badge className={getStatusColor(module.status)}>
                          {module.status === "completed"
                            ? "✓ Tamamlandı"
                            : module.status === "in-progress"
                              ? "⏳ Devam Ediyor"
                              : "🔒 Kilitli"}
                        </Badge>
                      </div>
                      <div className="mb-2">
                        <Progress value={module.progress} className="h-2" />
                      </div>
                      <div className="flex justify-between text-sm text-gray-400">
                        <span>İlerleme: %{module.progress.toFixed(0)}</span>
                        <span>Süre: {module.estimatedTime}</span>
                        <span>Seviye: {module.difficulty}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-insights" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-purple-400" />
                    AI Öğrenme Analizi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg">
                      <div className="flex items-center mb-2">
                        <TrendingUp className="h-4 w-4 text-green-400 mr-2" />
                        <span className="font-medium text-green-400">Güçlü Yönler</span>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Teknik analiz konusunda hızlı öğrenme</li>
                        <li>• Risk yönetimi prensiplerini iyi kavrama</li>
                        <li>• Piyasa trendlerini doğru yorumlama</li>
                      </ul>
                    </div>

                    <div className="p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg">
                      <div className="flex items-center mb-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-400 mr-2" />
                        <span className="font-medium text-yellow-400">Gelişim Alanları</span>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Duygusal karar verme kontrolü</li>
                        <li>• Karmaşık türev araçlar</li>
                        <li>• Makroekonomik faktör analizi</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Kişiselleştirilmiş Öneriler</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                      <h4 className="font-medium text-blue-400 mb-2">Öncelikli Konular</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>1. Yatırım psikolojisi modülünü tamamlayın</li>
                        <li>2. Risk yönetimi pratik uygulamaları</li>
                        <li>3. Portföy optimizasyon teknikleri</li>
                      </ul>
                    </div>

                    <div className="p-3 bg-purple-900/20 border border-purple-800 rounded-lg">
                      <h4 className="font-medium text-purple-400 mb-2">AI Önerileri</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Günlük 30 dakika eğitim optimal</li>
                        <li>• Pratik uygulamalarla pekiştirin</li>
                        <li>• Gerçek piyasa verileriyle test edin</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
