"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Brain, Clock, DollarSign, BarChart3, Zap, Target, Activity } from "lucide-react"
import Link from "next/link"
import Navigation from "@/components/navigation"

export default function HomePage() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const features = [
    {
      title: "Portföy Yönetimi",
      description: "AI destekli kişisel yatırım portföyü",
      icon: DollarSign,
      href: "/portfoyum",
      color: "text-green-400",
      bgColor: "bg-green-400/10",
    },
    {
      title: "Yatırım Analizi",
      description: "2025 güncel piyasa verileri",
      icon: BarChart3,
      href: "/investment",
      color: "text-blue-400",
      bgColor: "bg-blue-400/10",
    },
    {
      title: "AI Asistan",
      description: "Akıllı yatırım danışmanı",
      icon: Brain,
      href: "/ai-assistant",
      color: "text-purple-400",
      bgColor: "bg-purple-400/10",
    },
    {
      title: "AI Eğitimi",
      description: "Yapay zeka öğrenme merkezi",
      icon: Target,
      href: "/ai-training",
      color: "text-orange-400",
      bgColor: "bg-orange-400/10",
    },
    {
      title: "Zaman Kontrolü",
      description: "Simülasyon zaman yönetimi",
      icon: Clock,
      href: "/time-control",
      color: "text-red-400",
      bgColor: "bg-red-400/10",
    },
    {
      title: "Kripto Canlı",
      description: "Gerçek zamanlı kripto verileri",
      icon: Activity,
      href: "/crypto-live",
      color: "text-cyan-400",
      bgColor: "bg-cyan-400/10",
    },
  ]

  const stats = [
    { label: "Aktif Kullanıcı", value: "12,543", change: "+15%" },
    { label: "Toplam Portföy", value: "₺2.1M", change: "+8.2%" },
    { label: "AI Analiz", value: "1,247", change: "+23%" },
    { label: "Başarı Oranı", value: "%87.3", change: "+2.1%" },
  ]

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:60px_60px]" />
        <div className="relative max-w-7xl mx-auto px-4 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center mb-6">
              <TrendingUp className="h-16 w-16 text-green-400 mr-4" />
              <h1 className="text-6xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                Live Simalotör
              </h1>
            </div>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Yapay zeka destekli yatırım simülasyonu ve portföy yönetimi platformu. Gerçek piyasa verileriyle
              stratejilerinizi test edin, AI asistanınızla birlikte başarılı yatırımlar yapın.
            </p>
            <div className="flex items-center justify-center space-x-4 mb-12">
              <Link href="/portfoyum">
                <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-3">
                  <DollarSign className="h-5 w-5 mr-2" />
                  Portföyümü Görüntüle
                </Button>
              </Link>
              <Link href="/investment">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-slate-600 text-white hover:bg-slate-700 bg-transparent px-8 py-3"
                >
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Piyasa Analizi
                </Button>
              </Link>
            </div>

            {/* Real-time Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {stats.map((stat, index) => (
                <Card key={index} className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-sm text-gray-400 mb-2">{stat.label}</div>
                    <Badge className="bg-green-500/20 text-green-400 text-xs">{stat.change}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Platform Özellikleri</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            AI destekli araçlarımızla yatırım stratejilerinizi geliştirin ve piyasada öne geçin
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Link key={index} href={feature.href}>
                <Card className="bg-slate-800 border-slate-700 hover:bg-slate-700/50 transition-all duration-300 cursor-pointer group">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg ${feature.bgColor} flex items-center justify-center mb-4`}>
                      <Icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <CardTitle className="text-white group-hover:text-green-400 transition-colors">
                      {feature.title}
                    </CardTitle>
                    <CardDescription className="text-gray-400">{feature.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            )
          })}
        </div>
      </div>

      {/* AI Features Highlight */}
      <div className="bg-slate-800/50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">AI Destekli Yatırım Analizi</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Brain className="h-6 w-6 text-purple-400 mt-1" />
                  <div>
                    <h3 className="font-semibold text-white">Akıllı Portföy Yönetimi</h3>
                    <p className="text-gray-400">
                      AI asistanınız portföyünüzü sürekli analiz eder ve kişiselleştirilmiş öneriler sunar
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <TrendingUp className="h-6 w-6 text-green-400 mt-1" />
                  <div>
                    <h3 className="font-semibold text-white">Gerçek Zamanlı Analiz</h3>
                    <p className="text-gray-400">2025 güncel piyasa verileriyle anlık analiz ve trend tahminleri</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Zap className="h-6 w-6 text-yellow-400 mt-1" />
                  <div>
                    <h3 className="font-semibold text-white">Psikolojik Üstünlük</h3>
                    <p className="text-gray-400">AI'nın duygusuz karar verme yeteneği ile %400 daha objektif trading</p>
                  </div>
                </div>
              </div>
            </div>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-blue-400" />
                  Sistem Durumu
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">AI Analiz Motoru</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-green-400">Aktif</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Piyasa Veri Akışı</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-green-400">Canlı</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Portföy Senkronizasyonu</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-green-400">Güncel</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Son Güncelleme</span>
                    <span className="text-white">{currentTime.toLocaleTimeString("tr-TR")}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Hemen Başlayın</h2>
        <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
          Demo hesabınızla platformu keşfedin ve AI destekli yatırım deneyimini yaşayın
        </p>
        <div className="flex items-center justify-center space-x-4">
          <Link href="/portfoyum">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
              Demo Hesabı Dene
            </Button>
          </Link>
          <Link href="/investment">
            <Button
              size="lg"
              variant="outline"
              className="border-slate-600 text-white hover:bg-slate-700 bg-transparent px-8 py-3"
            >
              Piyasa Verilerini İncele
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
