"use client"

import CommissionDashboard from "@/components/commission-dashboard"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Award, Users, Shield } from "lucide-react"

export default function CommissionPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Komisyon Sistemi</h1>
          <p className="text-gray-600">Başarı odaklı komisyon modeli - Siz kazandıkça biz kazanırız</p>
        </div>

        {/* Sistem Avantajları */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="text-center">
            <CardHeader>
              <Shield className="h-12 w-12 mx-auto text-green-600 mb-2" />
              <CardTitle className="text-lg">Sadece Kardan Komisyon</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Zarar ettiğiniz işlemlerden komisyon almıyoruz. Risk bizimle paylaşılıyor.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <TrendingUp className="h-12 w-12 mx-auto text-blue-600 mb-2" />
              <CardTitle className="text-lg">Performans Odaklı</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Başarı oranınız arttıkça komisyon oranınız düşüyor. Karşılıklı kazanç modeli.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Award className="h-12 w-12 mx-auto text-purple-600 mb-2" />
              <CardTitle className="text-lg">Seviye Avantajları</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Kar seviyeniz arttıkça özel avantajlar ve düşük komisyon oranları kazanırsınız.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Ana Dashboard */}
        <CommissionDashboard />

        {/* CEO Stratejik Açıklama */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              Neden Commission-Based Model?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-blue-800">Kullanıcı Avantajları:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Zarar durumunda komisyon ödemezsiniz</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Başarı oranınız arttıkça komisyon düşer</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Yüksek kar seviyelerinde özel avantajlar</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Şeffaf ve adil fiyatlandırma</span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">Platform Avantajları:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Kullanıcı başarısı = Platform başarısı</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Sürekli AI geliştirme motivasyonu</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Uzun vadeli kullanıcı bağlılığı</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>Sürdürülebilir büyüme modeli</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
