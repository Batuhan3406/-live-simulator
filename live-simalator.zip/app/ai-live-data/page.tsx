import AILiveDataDashboard from "@/components/ai-live-data-dashboard"

export default function AILiveDataPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AI Destekli Canlı Veri Merkezi</h1>
        <p className="text-gray-600">Yapay zeka ile sürekli güncellenen piyasa verileri ve analiz sistemi - 2025+</p>
      </div>
      <AILiveDataDashboard />
    </div>
  )
}
