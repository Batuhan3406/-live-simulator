"use client"

import AIPsychologyMaster from "@/components/ai-psychology-master"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, Shield, Target, Zap } from "lucide-react"

export default function AIPsychologyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Psikoloji Üstünlüğü</h1>
          <p className="text-gray-600">YouTube'dan öğrenen duygusuz AI ile mükemmel trading psikolojisi</p>
        </div>

        {/* Psikoloji Avantajları */}
        <Card className="mb-8 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-600" />
              AI'nın Psikolojik Süper Güçleri
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Shield className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="font-semibold">Duygusal İmmünity</h3>
                <p className="text-sm text-gray-600">%0 FOMO, korku, açgözlülük</p>
                <Badge className="mt-2 bg-purple-100 text-purple-800">%95 Kontrol</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Target className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold">Sınırsız Sabır</h3>
                <p className="text-sm text-gray-600">Mükemmel setup için günlerce bekler</p>
                <Badge className="mt-2 bg-blue-100 text-blue-800">∞ Sabır</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold">Matematiksel Objektiflik</h3>
                <p className="text-sm text-gray-600">Sadece data ile karar verir</p>
                <Badge className="mt-2 bg-green-100 text-green-800">%99 Objektif</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Zap className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="font-semibold">Mükemmel Disiplin</h3>
                <p className="text-sm text-gray-600">Plana %100 sadık kalır</p>
                <Badge className="mt-2 bg-orange-100 text-orange-800">%98 Disiplin</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ana AI Psikoloji Komponenti */}
        <AIPsychologyMaster />

        {/* CEO Stratejik Değerlendirme */}
        <Card className="mt-8 bg-gradient-to-r from-green-50 to-purple-50 border-green-200">
          <CardHeader>
            <CardTitle>CEO Stratejik Psikoloji Analizi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-green-800">Rekabet Avantajımız:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎯
                    </Badge>
                    <span>
                      <strong>Diğer Platformlar:</strong> İnsan trader'ların duygusal önerileri (%75 duygusal)
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🚀
                    </Badge>
                    <span>
                      <strong>Live Simalotör:</strong> YouTube'dan öğrenen duygusuz AI (%0 duygusal)
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      💰
                    </Badge>
                    <span>
                      <strong>Sonuç:</strong> %400 daha objektif, %200 daha karlı trading
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">Psikoloji Performans Metrikleri:</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Duygusal Kontrol:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">AI %95</span>
                      <span className="text-sm text-gray-500">vs</span>
                      <span className="text-sm font-medium">İnsan %25</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">FOMO Direnci:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">AI %92</span>
                      <span className="text-sm text-gray-500">vs</span>
                      <span className="text-sm font-medium">İnsan %15</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Sabır Skoru:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">AI %96</span>
                      <span className="text-sm text-gray-500">vs</span>
                      <span className="text-sm font-medium">İnsan %20</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Objektiflik:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">AI %99</span>
                      <span className="text-sm text-gray-500">vs</span>
                      <span className="text-sm font-medium">İnsan %35</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
