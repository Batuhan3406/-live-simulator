"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Brain, Send, TrendingUp, AlertTriangle, MessageSquare, Zap } from "lucide-react"
import Navigation from "@/components/navigation"

interface ChatMessage {
  id: string
  type: "user" | "ai"
  content: string
  timestamp: Date
  confidence?: number
  recommendation?: string
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      type: "ai",
      content:
        "Merhaba! Ben ARIA, sizin AI yatırım asistanınızım. Portföyünüz hakkında sorularınızı yanıtlayabilir, piyasa analizi yapabilir ve yatırım önerileri sunabilirim. Size nasıl yardımcı olabilirim?",
      timestamp: new Date(),
      confidence: 100,
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const aiResponses = [
    {
      trigger: ["bitcoin", "btc"],
      response:
        "Bitcoin şu anda 98.750$ seviyesinde işlem görüyor. Teknik analizime göre 102K direncini test edecek. ETF girişleri devam ediyor ve kurumsal talep güçlü. %85 güvenle ALIN öneriyorum.",
      confidence: 85,
      recommendation: "ALIN",
    },
    {
      trigger: ["ethereum", "eth"],
      response:
        "Ethereum 3.850$ seviyesinde. Staking oranları artıyor ve DeFi sektörü canlanıyor. Shanghai upgrade sonrası likidite artışı fiyatı destekliyor. %82 güvenle pozisyon alabilirsiniz.",
      confidence: 82,
      recommendation: "ALIN",
    },
    {
      trigger: ["portföy", "portfolio"],
      response:
        "Portföyünüzü analiz ettim. Toplam değer ₺165.072 (+₺72). Bitcoin pozisyonunuzu %10 artırmanızı, altın pozisyonunu %20 azaltmanızı öneriyorum. Risk dağılımınız dengeli görünüyor.",
      confidence: 78,
      recommendation: "OPTIMIZE",
    },
    {
      trigger: ["risk", "zarar"],
      response:
        "Risk yönetimi çok önemli. Portföyünüzün %5'inden fazlasını tek bir varlığa yatırmayın. Stop-loss kullanın ve duygusal kararlardan kaçının. AI olarak ben hiç duygusal karar vermem.",
      confidence: 95,
      recommendation: "DIKKAT",
    },
    {
      trigger: ["altın", "gold"],
      response:
        "Altın 2.650$ seviyesinde. Fed faiz kararı öncesi volatilite artabilir. Güçlü dolar altını baskılayabilir. %65 güvenle BEKLE pozisyonu öneriyorum.",
      confidence: 65,
      recommendation: "BEKLE",
    },
  ]

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: inputMessage,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsTyping(true)

    // Simulate AI thinking time
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Find matching response
    const lowerInput = inputMessage.toLowerCase()
    const matchedResponse = aiResponses.find((response) =>
      response.trigger.some((trigger) => lowerInput.includes(trigger)),
    )

    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      type: "ai",
      content:
        matchedResponse?.response ||
        "Bu konuda size yardımcı olmaya çalışıyorum. Daha spesifik sorular sorabilirsiniz: Bitcoin, Ethereum, portföy analizi, risk yönetimi gibi konularda uzmanım.",
      timestamp: new Date(),
      confidence: matchedResponse?.confidence || 70,
      recommendation: matchedResponse?.recommendation,
    }

    setMessages((prev) => [...prev, aiMessage])
    setIsTyping(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const getRecommendationColor = (rec?: string) => {
    switch (rec) {
      case "ALIN":
        return "bg-green-500 text-white"
      case "BEKLE":
        return "bg-yellow-500 text-black"
      case "OPTIMIZE":
        return "bg-blue-500 text-white"
      case "DIKKAT":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const quickQuestions = [
    "Bitcoin analizi yap",
    "Portföyümü değerlendir",
    "Risk yönetimi önerileri",
    "Ethereum hakkında ne düşünüyorsun?",
    "Altın yatırımı mantıklı mı?",
  ]

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Brain className="h-8 w-8 text-purple-400 mr-3" />
            <h1 className="text-3xl font-bold">AI Yatırım Asistanı</h1>
          </div>
          <p className="text-gray-400">
            ARIA ile sohbet edin, portföy analizi yapın ve kişiselleştirilmiş yatırım önerileri alın
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Chat Area */}
          <Card className="lg:col-span-3 bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <MessageSquare className="h-5 w-5 mr-2" />
                ARIA ile Sohbet
              </CardTitle>
              <CardDescription className="text-gray-400">AI asistanınızla gerçek zamanlı sohbet edin</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Messages */}
              <div className="h-96 overflow-y-auto mb-4 space-y-4 p-4 bg-slate-900 rounded-lg">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.type === "user"
                          ? "bg-blue-600 text-white"
                          : "bg-slate-700 text-white border border-slate-600"
                      }`}
                    >
                      {message.type === "ai" && (
                        <div className="flex items-center mb-2">
                          <Brain className="h-4 w-4 text-purple-400 mr-2" />
                          <span className="text-xs text-purple-400 font-medium">ARIA</span>
                          {message.confidence && (
                            <Badge className="ml-2 bg-purple-500/20 text-purple-300 text-xs">
                              %{message.confidence} güven
                            </Badge>
                          )}
                        </div>
                      )}
                      <p className="text-sm leading-relaxed">{message.content}</p>
                      {message.recommendation && (
                        <div className="mt-2">
                          <Badge className={`${getRecommendationColor(message.recommendation)} text-xs`}>
                            {message.recommendation}
                          </Badge>
                        </div>
                      )}
                      <div className="text-xs text-gray-400 mt-1">{message.timestamp.toLocaleTimeString("tr-TR")}</div>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-700 text-white border border-slate-600 px-4 py-2 rounded-lg">
                      <div className="flex items-center">
                        <Brain className="h-4 w-4 text-purple-400 mr-2" />
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100"></div>
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="flex space-x-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="ARIA'ya sorunuzu yazın..."
                  className="flex-1 bg-slate-700 border-slate-600 text-white placeholder-gray-400"
                  disabled={isTyping}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isTyping}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>

              {/* Quick Questions */}
              <div className="mt-4">
                <p className="text-sm text-gray-400 mb-2">Hızlı sorular:</p>
                <div className="flex flex-wrap gap-2">
                  {quickQuestions.map((question, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => setInputMessage(question)}
                      className="text-xs border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
                    >
                      {question}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Status & Features */}
          <div className="space-y-6">
            {/* AI Status */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-sm">AI Durumu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">ARIA Sistemi</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-green-400 text-sm">Aktif</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">Piyasa Analizi</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-green-400 text-sm">Canlı</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">Öğrenme</span>
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-blue-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-blue-400 text-sm">Sürekli</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Capabilities */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-sm">AI Yetenekleri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <TrendingUp className="h-4 w-4 text-green-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">Piyasa Analizi</p>
                      <p className="text-xs text-gray-400">Gerçek zamanlı veri analizi</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Brain className="h-4 w-4 text-purple-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">Portföy Optimizasyonu</p>
                      <p className="text-xs text-gray-400">Kişiselleştirilmiş öneriler</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">Risk Yönetimi</p>
                      <p className="text-xs text-gray-400">Proaktif uyarı sistemi</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Zap className="h-4 w-4 text-blue-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">Hızlı Yanıt</p>
                      <p className="text-xs text-gray-400">Anlık analiz ve öneriler</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Analysis */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-sm">Son Analizler</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-2 bg-slate-700 rounded text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-white font-medium">Bitcoin</span>
                      <Badge className="bg-green-500 text-white text-xs">ALIN</Badge>
                    </div>
                    <p className="text-gray-400">100K hedefi yaklaşıyor</p>
                  </div>
                  <div className="p-2 bg-slate-700 rounded text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-white font-medium">Ethereum</span>
                      <Badge className="bg-green-500 text-white text-xs">ALIN</Badge>
                    </div>
                    <p className="text-gray-400">Staking büyümesi devam ediyor</p>
                  </div>
                  <div className="p-2 bg-slate-700 rounded text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-white font-medium">Altın</span>
                      <Badge className="bg-yellow-500 text-black text-xs">BEKLE</Badge>
                    </div>
                    <p className="text-gray-400">Fed kararı öncesi volatilite</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
