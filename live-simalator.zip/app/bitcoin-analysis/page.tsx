"use client"

import TurkishBitcoinAnalyst from "@/components/turkish-bitcoin-analyst"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, Target, Shield, Zap } from "lucide-react"

export default function BitcoinAnalysisPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Bitcoin Kaldıraçlı İşlem Analizi</h1>
          <p className="text-gray-600">Türkçe konuşan AI finansal analist ile Bitcoin leverage trading rehberi</p>
        </div>

        {/* AI Analist Özellikleri */}
        <Card className="mb-8 bg-gradient-to-r from-yellow-50 to-red-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-yellow-600" />
              Türkçe AI Analist Özellikleri
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Target className="h-6 w-6 text-yellow-600" />
                </div>
                <h3 className="font-semibold">Fiyat Bölgesi Analizi</h3>
                <p className="text-sm text-gray-600">Destek/direnç seviyelerini tespit eder</p>
                <Badge className="mt-2 bg-yellow-100 text-yellow-800">Otomatik</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Shield className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold">Risk Skoru</h3>
                <p className="text-sm text-gray-600">0-10 arası risk değerlendirmesi</p>
                <Badge className="mt-2 bg-green-100 text-green-800">Güvenli</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Zap className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="font-semibold">Canlı Sinyaller</h3>
                <p className="text-sm text-gray-600">AL/SAT/BEKLE önerileri</p>
                <Badge className="mt-2 bg-blue-100 text-blue-800">Gerçek Zamanlı</Badge>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="font-semibold">Türkçe Açıklama</h3>
                <p className="text-sm text-gray-600">Net ve anlaşılır öneriler</p>
                <Badge className="mt-2 bg-purple-100 text-purple-800">Türkçe</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ana AI Analist Komponenti */}
        <TurkishBitcoinAnalyst />

        {/* CEO Stratejik Not */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <CardTitle>CEO Stratejik Değerlendirme</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-blue-800">Türkçe AI Analist Avantajları:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎯
                    </Badge>
                    <span>
                      <strong>Yerel Dil Desteği:</strong> Türkçe açıklamalar, net öneriler
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📊
                    </Badge>
                    <span>
                      <strong>Detaylı Tablo:</strong> Fiyat bölgesi, kaldıraç, risk skoru
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ⚡
                    </Badge>
                    <span>
                      <strong>Canlı Analiz:</strong> Gerçek zamanlı piyasa takibi
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🛡️
                    </Badge>
                    <span>
                      <strong>Risk Yönetimi:</strong> Stop-loss ve hedef fiyat önerileri
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">Pazar Fırsatı:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🇹🇷
                    </Badge>
                    <span>
                      <strong>Türk Yatırımcılar:</strong> Türkçe AI analist eksikliği var
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      💰
                    </Badge>
                    <span>
                      <strong>Kaldıraçlı İşlemler:</strong> Yüksek kar potansiyeli, yüksek risk
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎓
                    </Badge>
                    <span>
                      <strong>Eğitim Odaklı:</strong> Öğreterek güven kazanma
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📱
                    </Badge>
                    <span>
                      <strong>Mobil Uyumlu:</strong> Her yerden erişim imkanı
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
