"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bitcoin, TrendingUp, TrendingDown, RefreshCw, Activity } from "lucide-react"
import Navigation from "@/components/navigation"

interface CryptoData {
  symbol: string
  name: string
  price: number
  change24h: number
  change7d: number
  volume: number
  marketCap: number
  rank: number
  lastUpdate: string
}

export default function CryptoLivePage() {
  const [cryptoData, setCryptoData] = useState<CryptoData[]>([
    {
      symbol: "BTC",
      name: "Bitcoin",
      price: 98750,
      change24h: 3.7,
      change7d: -1.2,
      volume: 45200000000,
      marketCap: 1950000000000,
      rank: 1,
      lastUpdate: new Date().toISOString(),
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      price: 3850,
      change24h: 5.2,
      change7d: 4.2,
      volume: 18500000000,
      marketCap: 463000000000,
      rank: 2,
      lastUpdate: new Date().toISOString(),
    },
    {
      symbol: "SOL",
      name: "Solana",
      price: 245,
      change24h: 8.9,
      change7d: 12.3,
      volume: 3200000000,
      marketCap: 115000000000,
      rank: 3,
      lastUpdate: new Date().toISOString(),
    },
    {
      symbol: "ADA",
      name: "Cardano",
      price: 1.85,
      change24h: -2.1,
      change7d: 8.4,
      volume: 1800000000,
      marketCap: 65000000000,
      rank: 4,
      lastUpdate: new Date().toISOString(),
    },
    {
      symbol: "DOT",
      name: "Polkadot",
      price: 28.5,
      change24h: 4.1,
      change7d: 15.2,
      volume: 950000000,
      marketCap: 42000000000,
      rank: 5,
      lastUpdate: new Date().toISOString(),
    },
  ])

  const [isLive, setIsLive] = useState(false)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Canlı veri simülasyonu
  useEffect(() => {
    if (!isLive) return

    const interval = setInterval(() => {
      setCryptoData((prev) =>
        prev.map((crypto) => ({
          ...crypto,
          price: crypto.price * (1 + (Math.random() - 0.5) * 0.02), // %2 volatilite
          change24h: crypto.change24h + (Math.random() - 0.5) * 2,
          volume: crypto.volume * (1 + (Math.random() - 0.5) * 0.1),
          lastUpdate: new Date().toISOString(),
        })),
      )
      setLastUpdate(new Date())
    }, 2000)

    return () => clearInterval(interval)
  }, [isLive])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 6,
    }).format(price)
  }

  const formatVolume = (volume: number) => {
    return new Intl.NumberFormat("en-US", {
      notation: "compact",
      compactDisplay: "short",
    }).format(volume)
  }

  const formatMarketCap = (marketCap: number) => {
    return new Intl.NumberFormat("en-US", {
      notation: "compact",
      compactDisplay: "short",
      style: "currency",
      currency: "USD",
    }).format(marketCap)
  }

  const getChangeColor = (change: number) => {
    return change >= 0 ? "text-green-400" : "text-red-400"
  }

  const getChangeIcon = (change: number) => {
    return change >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Bitcoin className="h-8 w-8 text-orange-400 mr-3" />
            <div>
              <h1 className="text-3xl font-bold">Kripto Canlı Veriler</h1>
              <p className="text-gray-400">Gerçek zamanlı kripto para piyasa verileri</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right text-sm text-gray-400">
              <p>Son Güncelleme</p>
              <p>{lastUpdate.toLocaleTimeString("tr-TR")}</p>
            </div>
            <Button
              onClick={() => setIsLive(!isLive)}
              className={isLive ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
            >
              {isLive ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Canlı Durdur
                </>
              ) : (
                <>
                  <Activity className="h-4 w-4 mr-2" />
                  Canlı Başlat
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Live Status */}
        {isLive && (
          <div className="mb-6 text-center">
            <Badge className="bg-green-100 text-green-800 animate-pulse">
              🔴 CANLI VERİ - Her 2 saniyede güncelleniyor
            </Badge>
          </div>
        )}

        {/* Crypto Table */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Top Kripto Paralar</CardTitle>
            <CardDescription className="text-gray-400">
              Piyasa değerine göre sıralanmış kripto para verileri
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-600">
                    <th className="text-left py-3 px-2 text-gray-400 font-medium">Sıra</th>
                    <th className="text-left py-3 px-2 text-gray-400 font-medium">Coin</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Fiyat</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">24h</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">7d</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Hacim</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Piyasa Değeri</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">Durum</th>
                  </tr>
                </thead>
                <tbody>
                  {cryptoData.map((crypto) => (
                    <tr key={crypto.symbol} className="border-b border-slate-700 hover:bg-slate-700/50">
                      <td className="py-4 px-2 text-white font-medium">#{crypto.rank}</td>
                      <td className="py-4 px-2">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white text-xs font-bold">{crypto.symbol[0]}</span>
                          </div>
                          <div>
                            <div className="font-medium text-white">{crypto.name}</div>
                            <div className="text-sm text-gray-400">{crypto.symbol}</div>
                          </div>
                        </div>
                      </td>
                      <td className="text-right py-4 px-2 text-white font-medium">{formatPrice(crypto.price)}</td>
                      <td className={`text-right py-4 px-2 ${getChangeColor(crypto.change24h)}`}>
                        <div className="flex items-center justify-end">
                          {getChangeIcon(crypto.change24h)}
                          <span className="ml-1">
                            {crypto.change24h >= 0 ? "+" : ""}
                            {crypto.change24h.toFixed(2)}%
                          </span>
                        </div>
                      </td>
                      <td className={`text-right py-4 px-2 ${getChangeColor(crypto.change7d)}`}>
                        <div className="flex items-center justify-end">
                          {getChangeIcon(crypto.change7d)}
                          <span className="ml-1">
                            {crypto.change7d >= 0 ? "+" : ""}
                            {crypto.change7d.toFixed(2)}%
                          </span>
                        </div>
                      </td>
                      <td className="text-right py-4 px-2 text-white">${formatVolume(crypto.volume)}</td>
                      <td className="text-right py-4 px-2 text-white">{formatMarketCap(crypto.marketCap)}</td>
                      <td className="text-center py-4 px-2">
                        {isLive ? (
                          <Badge className="bg-green-100 text-green-800 animate-pulse">CANLI</Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800">DURDURULDU</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-green-400 mb-2">$2.95T</div>
              <div className="text-sm text-gray-400">Toplam Piyasa Değeri</div>
              <div className="text-xs text-green-400 mt-1">+2.1% (24h)</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-blue-400 mb-2">$125B</div>
              <div className="text-sm text-gray-400">24h İşlem Hacmi</div>
              <div className="text-xs text-blue-400 mt-1">+8.5% (24h)</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-orange-400 mb-2">52.3%</div>
              <div className="text-sm text-gray-400">Bitcoin Dominansı</div>
              <div className="text-xs text-red-400 mt-1">-0.2% (7d)</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-purple-400 mb-2">68</div>
              <div className="text-sm text-gray-400">Fear & Greed Index</div>
              <div className="text-xs text-orange-400 mt-1">Açgözlülük</div>
            </CardContent>
          </Card>
        </div>

        {/* AI Analysis */}
        <Card className="mt-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">🤖 AI Piyasa Analizi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-700 rounded-lg p-4">
              <h4 className="font-medium text-blue-400 mb-2">💡 Anlık Piyasa Değerlendirmesi</h4>
              <p className="text-sm text-gray-300 leading-relaxed mb-3">
                Bitcoin 98.750$ seviyesinde güçlü destek buluyor. Ethereum'da DeFi aktivitesi artıyor. Solana ekosistemi
                hızla büyüyor ve NFT hacmi rekor seviyede. Genel piyasa trendi pozitif, ancak Fed kararı öncesi
                volatilite artabilir.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-slate-600 rounded">
                  <div className="text-lg font-bold text-green-400">YÜKSELIŞ</div>
                  <div className="text-xs text-gray-400">Genel Trend</div>
                </div>
                <div className="text-center p-3 bg-slate-600 rounded">
                  <div className="text-lg font-bold text-yellow-400">ORTA</div>
                  <div className="text-xs text-gray-400">Risk Seviyesi</div>
                </div>
                <div className="text-center p-3 bg-slate-600 rounded">
                  <div className="text-lg font-bold text-blue-400">%87</div>
                  <div className="text-xs text-gray-400">AI Güven</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
