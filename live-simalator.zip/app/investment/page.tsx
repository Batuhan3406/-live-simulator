"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, AlertTriangle, CheckCircle, RefreshCw, Brain, ArrowUpRight, ArrowDownRight } from "lucide-react"
import Navigation from "@/components/navigation"

// 2025 güncel piyasa verileri
const marketData = [
  {
    symbol: "BTC",
    name: "Bitcoin",
    price: 98750,
    change24h: 3.7,
    change7d: -1.2,
    marketCap: 1950000000000,
    volume: 45200000000,
    category: "Kripto",
    recommendation: "GÜÇLÜ ALIN",
    aiScore: 87,
    riskLevel: "Orta",
  },
  {
    symbol: "ETH",
    name: "Ethereum",
    price: 3850,
    change24h: 5.2,
    change7d: 4.2,
    marketCap: 463000000000,
    volume: 18500000000,
    category: "Kripto",
    recommendation: "ALIN",
    aiScore: 82,
    riskLevel: "Orta",
  },
  {
    symbol: "SOL",
    name: "Solana",
    price: 245,
    change24h: 8.9,
    change7d: 12.3,
    marketCap: 115000000000,
    volume: 3200000000,
    category: "Kripto",
    recommendation: "GÜÇLÜ ALIN",
    aiScore: 91,
    riskLevel: "Yüksek",
  },
  {
    symbol: "GOLD",
    name: "Altın (Ons)",
    price: 2650,
    change24h: -0.5,
    change7d: 2.1,
    marketCap: 0,
    volume: 0,
    category: "Emtia",
    recommendation: "BEKLE",
    aiScore: 65,
    riskLevel: "Düşük",
  },
]

// AI analiz verileri
const aiAnalyses = [
  {
    id: 1,
    title: "Bitcoin 100K Hedefi Yaklaşıyor",
    description:
      "Bitcoin 98.750$ seviyesinde güçlü destek buldu. ETF girişleri devam ediyor. 102K direncini kırması halinde 105K-110K seviyeleri hedeflenebilir.",
    recommendation: "GÜÇLÜ ALIN",
    confidence: 87,
    timeframe: "1-2 hafta",
    riskLevel: "Orta",
    priority: "Yüksek",
  },
  {
    id: 2,
    title: "Ethereum Staking Büyümesi",
    description:
      "Ethereum staking oranları artmaya devam ediyor. Shanghai upgrade sonrası likidite artışı fiyatı destekliyor. DeFi sektörü canlanıyor.",
    recommendation: "ALIN",
    confidence: 82,
    timeframe: "2-4 hafta",
    riskLevel: "Orta",
    priority: "Orta",
  },
  {
    id: 3,
    title: "Solana Ekosistemi Patlaması",
    description:
      "Solana NFT ve DeFi ekosistemi hızla büyüyor. Phantom wallet kullanıcıları rekor seviyede. Teknik analiz güçlü yükseliş sinyali veriyor.",
    recommendation: "GÜÇLÜ ALIN",
    confidence: 91,
    timeframe: "1-3 hafta",
    riskLevel: "Yüksek",
    priority: "Yüksek",
  },
]

export default function InvestmentPage() {
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [loading, setLoading] = useState(false)

  // Otomatik güncelleme (5 dakikada bir)
  useEffect(() => {
    const interval = setInterval(
      () => {
        setLastUpdate(new Date())
      },
      5 * 60 * 1000,
    )

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = () => {
    setLoading(true)
    setTimeout(() => {
      setLastUpdate(new Date())
      setLoading(false)
    }, 1000)
  }

  const formatCurrency = (amount: number, currency = "USD") => {
    if (currency === "TRY") {
      return new Intl.NumberFormat("tr-TR", {
        style: "currency",
        currency: "TRY",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(amount)
    }
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatPercent = (percent: number) => {
    return `${percent >= 0 ? "+" : ""}${percent.toFixed(2)}%`
  }

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case "GÜÇLÜ ALIN":
        return "bg-green-600 text-white"
      case "ALIN":
        return "bg-green-500 text-white"
      case "BEKLE":
        return "bg-yellow-500 text-black"
      case "SAT":
        return "bg-red-500 text-white"
      case "GÜÇLÜ SAT":
        return "bg-red-600 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "Düşük":
        return "text-green-400"
      case "Orta":
        return "text-yellow-400"
      case "Yüksek":
        return "text-red-400"
      default:
        return "text-gray-400"
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Kripto":
        return "bg-orange-500"
      case "Altın":
      case "Emtia":
        return "bg-yellow-500"
      case "Borsa":
        return "bg-blue-500"
      case "Döviz":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatLargeNumber = (num: number) => {
    return new Intl.NumberFormat("en-US", {
      notation: "compact",
      compactDisplay: "short",
    }).format(num)
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Navigation />

      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center">
              <TrendingUp className="h-8 w-8 mr-3 text-green-400" />
              Yatırım Analizi
            </h1>
            <p className="text-gray-400 mt-1">2025 güncel piyasa verileri ve AI önerileri</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right text-sm text-gray-400">
              <p>Son Güncelleme</p>
              <p>{lastUpdate.toLocaleTimeString("tr-TR")}</p>
            </div>
            <Button
              onClick={handleRefresh}
              variant="outline"
              size="sm"
              className="border-slate-600 text-white hover:bg-slate-700 bg-transparent"
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Yenile
            </Button>
          </div>
        </div>

        {/* Piyasa Özeti */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Bitcoin Fiyatı</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{formatCurrency(98750)}</div>
              <p className="text-green-400 text-sm flex items-center">
                <ArrowUpRight className="h-4 w-4 mr-1" />
                +3.7% (24h)
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Toplam Piyasa Değeri</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">$2.95T</div>
              <p className="text-green-400 text-sm flex items-center">
                <ArrowUpRight className="h-4 w-4 mr-1" />
                +2.1% (24h)
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Bitcoin Dominansı</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">52.3%</div>
              <p className="text-yellow-400 text-sm flex items-center">
                <ArrowDownRight className="h-4 w-4 mr-1" />
                -0.2% (7d)
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Fear & Greed Index</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-400">68</div>
              <p className="text-orange-400 text-sm">Açgözlülük</p>
            </CardContent>
          </Card>
        </div>

        {/* AI Analizleri */}
        <Card className="mb-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Brain className="h-5 w-5 mr-2 text-purple-400" />
              AI Piyasa Analizleri
            </CardTitle>
            <CardDescription className="text-gray-400">
              Yapay zeka destekli piyasa değerlendirmeleri ve öneriler
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {aiAnalyses.map((analysis) => (
                <div key={analysis.id} className="bg-slate-700 rounded-lg p-4 border border-slate-600">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-white mb-2">{analysis.title}</h3>
                      <p className="text-gray-300 text-sm leading-relaxed mb-3">{analysis.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <Badge className={`${getRecommendationColor(analysis.recommendation)} font-medium`}>
                      {analysis.recommendation}
                    </Badge>
                    <div className="flex items-center text-xs text-gray-400">
                      <CheckCircle className="h-3 w-3 mr-1" />%{analysis.confidence} güven
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs text-gray-400">
                    <div>
                      <span className="block">Zaman Dilimi:</span>
                      <span className="text-white">{analysis.timeframe}</span>
                    </div>
                    <div>
                      <span className="block">Risk Seviyesi:</span>
                      <span className={getRiskColor(analysis.riskLevel)}>{analysis.riskLevel}</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-600">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2">
                        {analysis.priority === "Yüksek" && <AlertTriangle className="h-3 w-3 text-red-400" />}
                        <span className="text-gray-400">{analysis.priority} Öncelik</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Piyasa Verileri Tablosu */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">2025 Piyasa Verileri</CardTitle>
            <CardDescription className="text-gray-400">Güncel fiyatlar, değişimler ve AI önerileri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-600">
                    <th className="text-left py-3 px-2 text-gray-400 font-medium">Varlık</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Fiyat</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">24h</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">7d</th>
                    <th className="text-right py-3 px-2 text-gray-400 font-medium">Hacim</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">AI Skoru</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">Öneri</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">Risk</th>
                  </tr>
                </thead>
                <tbody>
                  {marketData.map((item) => (
                    <tr key={item.symbol} className="border-b border-slate-700 hover:bg-slate-700/50">
                      <td className="py-4 px-2">
                        <div className="flex items-center">
                          <div
                            className="w-3 h-3 rounded-full mr-3"
                            style={{ backgroundColor: getCategoryColor(item.category) }}
                          />
                          <div>
                            <div className="font-medium text-white">{item.name}</div>
                            <div className="text-sm text-gray-400">{item.symbol}</div>
                          </div>
                        </div>
                      </td>
                      <td className="text-right py-4 px-2 text-white font-medium">{formatCurrency(item.price)}</td>
                      <td className={`text-right py-4 px-2 ${item.change24h >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {formatPercent(item.change24h)}
                      </td>
                      <td className={`text-right py-4 px-2 ${item.change7d >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {formatPercent(item.change7d)}
                      </td>
                      <td className="text-right py-4 px-2 text-white">
                        {item.volume > 0 ? `$${formatLargeNumber(item.volume)}` : "-"}
                      </td>
                      <td className="text-center py-4 px-2">
                        <div className="flex items-center justify-center">
                          <div className="w-12 h-2 bg-slate-600 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
                              style={{ width: `${item.aiScore}%` }}
                            />
                          </div>
                          <span className="ml-2 text-sm text-white">{item.aiScore}</span>
                        </div>
                      </td>
                      <td className="text-center py-4 px-2">
                        <Badge className={`${getRecommendationColor(item.recommendation)} text-xs`}>
                          {item.recommendation}
                        </Badge>
                      </td>
                      <td className={`text-center py-4 px-2 ${getRiskColor(item.riskLevel)}`}>{item.riskLevel}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
