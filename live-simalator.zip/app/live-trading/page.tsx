"use client"

import YouTubeInspiredTrading from "@/components/youtube-inspired-trading"
import Navigation from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Users, TrendingUp, Brain } from "lucide-react"

export default function LiveTradingPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Canlı AI Trading</h1>
          <p className="text-gray-600">YouTube tarzı canlı trading deneyimi - Gerçek zamanlı AI ile kazanç</p>
        </div>

        {/* YouTube Video Referansı */}
        <Card className="mb-8 bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play className="h-5 w-5 text-red-600" />
              İlham Kaynağı: YouTube Trading Videoları
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <TrendingUp className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">Canlı Kazanç Gösterimi</h3>
                <p className="text-sm text-gray-600">500$'dan başlayarak gerçek zamanlı kar</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">AI Destekli İşlemler</h3>
                <p className="text-sm text-gray-600">Yapay zeka ile otomatik sinyal üretimi</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Users className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-semibold">Eğitim Odaklı</h3>
                <p className="text-sm text-gray-600">Basit anlatımla öğrenme fırsatı</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ana Trading Interface */}
        <YouTubeInspiredTrading />

        {/* CEO Stratejik Not */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <CardTitle>CEO Stratejik Analiz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-blue-800">YouTube Video Insights:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>500$ Başlangıç:</strong> Küçük sermaye, büyük hedefler
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Canlı Demo:</strong> Şeffaflık ve güven inşası
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>AI Vurgusu:</strong> Teknoloji odaklı yaklaşım
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      ✓
                    </Badge>
                    <span>
                      <strong>Türkçe İçerik:</strong> Yerel pazar odaklı
                    </span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3 text-purple-800">Live Simalotör Avantajları:</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🚀
                    </Badge>
                    <span>
                      <strong>Interaktif Platform:</strong> Sadece izlemek değil, katılmak
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      🎯
                    </Badge>
                    <span>
                      <strong>Kişisel AI:</strong> Herkesin kendi AI asistanı
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      💰
                    </Badge>
                    <span>
                      <strong>Commission Model:</strong> Sadece kardan pay
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">
                      📚
                    </Badge>
                    <span>
                      <strong>Eğitim + Uygulama:</strong> Öğren ve kazan
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
