"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TrendingUp, Mail, Lock, LogIn, Wallet } from "lucide-react"
import { AuthService } from "@/lib/auth"
import Navigation from "@/components/navigation"

export default function PortfoyumPage() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loginLoading, setLoginLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    const checkAuth = async () => {
      const currentUser = await AuthService.getCurrentUser()
      setUser(currentUser)
      setLoading(false)
    }

    checkAuth()
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginLoading(true)
    setError("")

    try {
      const userData = await AuthService.login(email, password)
      if (userData) {
        setUser(userData)
      } else {
        setError("Geçersiz email veya şifre. Demo hesabı: demo@example.com / demo123")
      }
    } catch (err) {
      setError("Giriş yapılırken bir hata oluştu. Lütfen tekrar deneyin.")
    } finally {
      setLoginLoading(false)
    }
  }

  const handleDemoLogin = async () => {
    setLoginLoading(true)
    setError("")

    try {
      const userData = await AuthService.login("demo@example.com", "demo123")
      if (userData) {
        setUser(userData)
      }
    } catch (err) {
      setError("Demo hesabı yüklenirken hata oluştu.")
    } finally {
      setLoginLoading(false)
    }
  }

  const handleLogout = () => {
    AuthService.logout()
    setUser(null)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900">
        <Navigation />
        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-white">Yükleniyor...</div>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-900">
        <Navigation />
        <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-4">
                <Wallet className="h-12 w-12 text-green-400" />
              </div>
              <CardTitle className="text-2xl font-bold text-white">Portföy Yöneticisi</CardTitle>
              <CardDescription className="text-gray-400">AI destekli yatırım portföyünüze giriş yapın</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && (
                <Alert className="bg-red-900/20 border-red-800 text-red-400">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-300">
                    Email Adresi
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="demo@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-gray-400 focus:border-blue-500"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-300">
                    Şifre
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="demo123"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-gray-400 focus:border-blue-500"
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={loginLoading}
                >
                  {loginLoading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Giriş yapılıyor...
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <LogIn className="h-4 w-4 mr-2" />
                      Giriş Yap
                    </div>
                  )}
                </Button>
              </form>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-600" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-800 px-2 text-gray-400">veya</span>
                </div>
              </div>

              <Button
                onClick={handleDemoLogin}
                variant="outline"
                className="w-full border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
                disabled={loginLoading}
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                Demo Hesabı Kullan
              </Button>

              <div className="text-center text-sm text-gray-400 space-y-1">
                <p>
                  <strong>Demo Hesap Bilgileri:</strong>
                </p>
                <p>Email: demo@example.com</p>
                <p>Şifre: demo123</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <Navigation />
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Portföyüm</h1>
            <p className="text-gray-400">Hoş geldin, {user.name}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white bg-transparent"
          >
            Çıkış Yap
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Toplam Değer</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-400">₺165,072</div>
              <div className="text-sm text-gray-400">+₺72 (%0.04)</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Günlük Değişim</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-400">+%1.2</div>
              <div className="text-sm text-gray-400">Son 24 saat</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">AI Skoru</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">87/100</div>
              <div className="text-sm text-gray-400">Portföy optimizasyonu</div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8 bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Yatırım Dağılımı</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
                  <span className="text-white">Bitcoin (BTC)</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">₺49,970</div>
                  <div className="text-green-400 text-sm">+2.3%</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                  <span className="text-white">Ethereum (ETH)</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">₺29,992</div>
                  <div className="text-green-400 text-sm">+1.8%</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                  <span className="text-white">Altın</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">₺24,990</div>
                  <div className="text-red-400 text-sm">-0.5%</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-white">BIST 100</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">₺40,050</div>
                  <div className="text-green-400 text-sm">+0.8%</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-700 rounded">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                  <span className="text-white">USD/TRY</span>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">₺20,030</div>
                  <div className="text-green-400 text-sm">+0.3%</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
